package com.pearson.mytest.test;

import static org.springframework.test.util.AssertionErrors.fail;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;



import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultMatcher;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.util.ObjectUtils;

import com.google.gson.Gson;
import com.pearson.mytest.bean.ExtMetadata;
import com.pearson.mytest.bean.Metadata;
import com.pearson.mytest.bean.QuestionEnvelop;
import com.pearson.mytest.controller.QuestionsController;
import com.pearson.mytest.util.PIHelper;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "file:src/main/webapp/WEB-INF/appServlet-servlet.xml" })
public class QuestionsControllerTest {

	@Autowired
	QuestionsController questionController;

	private MockMvc mockMvc;
	private String token;
	private String  bookId ;
	private String  nodeId;

	@Before
	public void setUp() throws Exception {
		mockMvc = MockMvcBuilders.standaloneSetup(questionController).build();
		String username = TestData.UserToken.username;
		String password = TestData.UserToken.password;
		token = (new PIHelper()).getPIToken(username, password);
	    bookId = TestData.QuestionsController.bookId;
	    nodeId = TestData.QuestionsController.nodeId;
	}

	/**
	 * Testing the given chapter, questions existance  
	 * PassCriteria : output should give http status 200
	 * 
	 * @throws Exception
	 */
	@Test
	public void testGetQuestionsByContainer() throws Exception {
		

		

		mockMvc.perform(
				get("/books/"+bookId+"/nodes/"+nodeId+"/questions").header(
						"x-authorization", token)).andExpect(status().isOk()) ;
	}	
	
	/**
	 * Testing the given chapter questions with question filter Criteria 
	 * PassCriteria : output should give http status 200
	 * 
	 * @throws Exception
	 */
	/*@Test
	public void testGetQuestionsByContainerWithFilter() throws Exception {

		mockMvc.perform(
				get("/books/118132/nodes/835078310/questions?difficulty=medium&topic=maths").header(
						"x-authorization", token)).andExpect(status().isOk());
	}*/
	
	/**
	 * Testing the given question availability 
	 * PassCriteria : output should give http status 200
	 * 
	 * @throws Exception
	 */
	@Test
	public void testgetQuestionById() throws Exception {
	 String questionId = TestData.QuestionsController.questionId;

		mockMvc.perform(
				get("/questions/"+questionId).header(
						"x-authorization", token)).andExpect(status().isOk());
	}
	
	/**
	 * Testing the given question not found 
	 * PassCriteria : output should give http status 404
	 * 
	 * @throws Exception
	 */
	@Test
	public void testgetQuestionByIdNotFound() throws Exception {

		mockMvc.perform(
				get("/questions/fec4fd7b-c753-41a1-a5ec-notavailable").header(
						"x-authorization", token)).andExpect(status().isNotFound());
	}
	
	@Test
	public void testGetUserQuestions() throws Exception {
		
		mockMvc.perform(
				get("/my/questions").header("x-authorization", token)).andExpect(isOK_Or_NotFound());
	}
	
	public ResultMatcher isOK_Or_NotFound(){
	
		return new ResultMatcher() {
			public void match(MvcResult result) throws Exception {
				if(!(ObjectUtils.nullSafeEquals(HttpStatus.OK.value(), result.getResponse().getStatus()) || ObjectUtils.nullSafeEquals(HttpStatus.NOT_FOUND.value(), result.getResponse().getStatus())))
					fail("GetUserQuestions test get failed...");
			}
		};
	}
	
	/**
	 * Testing the question authoring
	 * @throws Exception
	 */
	@Test
	public void testSaveQuestions() throws Exception{
		
		Metadata questionMetadata = new Metadata();
		questionMetadata.setTitle("Junit Test Question");
		questionMetadata.setSubject(Arrays.asList("Education"));
		questionMetadata.setCrawlable("true");
		
		ExtMetadata extMeta = new ExtMetadata();
		extMeta.setName("Difficulty");
		extMeta.setValue("Low");
		
		List<ExtMetadata> extmetalist = new ArrayList<ExtMetadata>();
		extmetalist.add(extMeta);
		
		questionMetadata.setExtendedMetadata(extmetalist);
		
		QuestionEnvelop envelop = new QuestionEnvelop();
		envelop.setmetadata(questionMetadata);
		envelop.setBody("<?xml version=\"1.0\" encoding=\"utf-8\"?><assessmentItem xmlns=\"http://www.imsglobal.org/xsd/imsqti_v2p1\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"http://www.imsglobal.org/xsd/imsqti_v2p1 http://www.imsglobal.org/xsd/qti/qtiv2p1/imsqti_v2p1.xsd\" title=\"12323\" identifier=\"QUESTION-1000001217598209\" label=\"CE 2.1\" toolName=\"pegasus\" toolVersion=\"5.152.49.2\" adaptive=\"false\" timeDependent=\"false\"><responseDeclaration identifier=\"RESPONSE\" cardinality=\"single\" baseType=\"identifier\"/><outcomeDeclaration identifier=\"FEEDBACK\" cardinality=\"single\" baseType=\"identifier\"/><outcomeDeclaration identifier=\"ITEMSCORE\" cardinality=\"single\" baseType=\"float\"/><outcomeDeclaration identifier=\"SCORE\" cardinality=\"single\" baseType=\"float\" normalMaximum=\"1.00\"><defaultValue><value>0</value></defaultValue></outcomeDeclaration><outcomeDeclaration identifier=\"MAXSCORE\" cardinality=\"single\" baseType=\"float\"><defaultValue><value>1.00</value></defaultValue></outcomeDeclaration><itemBody><p>_________ focuses on the biological bases of psychological processes, behavior, and learning.</p><choiceInteraction shuffle=\"true\" responseIdentifier=\"RESPONSE\" maxChoices=\"1\" minChoices=\"1\"><simpleChoice identifier=\"RESPONSE_1\" fixed=\"false\">Psychoanalysis</simpleChoice><simpleChoice identifier=\"RESPONSE_2\" fixed=\"false\">Operant conditioning</simpleChoice><simpleChoice identifier=\"RESPONSE_3\" fixed=\"false\">Evolutionary psychology</simpleChoice><simpleChoice identifier=\"RESPONSE_4\" fixed=\"false\">Behavioral neuroscience</simpleChoice></choiceInteraction></itemBody><responseProcessing><responseCondition><responseIf><match><variable identifier=\"RESPONSE\"/><baseValue baseType=\"identifier\">RESPONSE_1</baseValue></match><setOutcomeValue identifier=\"SCORE\"><baseValue baseType=\"float\">0</baseValue></setOutcomeValue><setOutcomeValue identifier=\"FEEDBACK\"><baseValue baseType=\"identifier\">FEEDBACK_1</baseValue></setOutcomeValue></responseIf><responseElseIf><match><variable identifier=\"RESPONSE\"/><baseValue baseType=\"identifier\">RESPONSE_2</baseValue></match><setOutcomeValue identifier=\"SCORE\"><baseValue baseType=\"float\">0</baseValue></setOutcomeValue><setOutcomeValue identifier=\"FEEDBACK\"><baseValue baseType=\"identifier\">FEEDBACK_2</baseValue></setOutcomeValue></responseElseIf><responseElseIf><match><variable identifier=\"RESPONSE\"/><baseValue baseType=\"identifier\">RESPONSE_3</baseValue></match><setOutcomeValue identifier=\"SCORE\"><baseValue baseType=\"float\">0</baseValue></setOutcomeValue><setOutcomeValue identifier=\"FEEDBACK\"><baseValue baseType=\"identifier\">FEEDBACK_3</baseValue></setOutcomeValue></responseElseIf><responseElseIf><match><variable identifier=\"RESPONSE\"/><baseValue baseType=\"identifier\">RESPONSE_4</baseValue></match><setOutcomeValue identifier=\"SCORE\"><baseValue baseType=\"float\">1</baseValue></setOutcomeValue><setOutcomeValue identifier=\"FEEDBACK\"><baseValue baseType=\"identifier\">FEEDBACK_4</baseValue></setOutcomeValue></responseElseIf></responseCondition></responseProcessing><modalFeedback identifier=\"FEEDBACK_1\" outcomeIdentifier=\"FEEDBACK\" showHide=\"show\"><div>Neurons and Nerves: Building the Network, p. 47</div></modalFeedback><modalFeedback identifier=\"FEEDBACK_2\" outcomeIdentifier=\"FEEDBACK\" showHide=\"show\"><div>Neurons and Nerves: Building the Network, p. 47</div></modalFeedback><modalFeedback identifier=\"FEEDBACK_3\" outcomeIdentifier=\"FEEDBACK\" showHide=\"show\"><div>Neurons and Nerves: Building the Network, p. 47</div></modalFeedback><modalFeedback identifier=\"FEEDBACK_4\" outcomeIdentifier=\"FEEDBACK\" showHide=\"show\"><div>Neurons and Nerves: Building the Network, p. 47</div></modalFeedback></assessmentItem>");
		
		List<QuestionEnvelop> envelops = new ArrayList<QuestionEnvelop>();
		envelops.add(envelop);
		
		String jsonQuestion = (new Gson()).toJson(envelops);	
		mockMvc.perform(
				post("/my/questions")
				.header("x-authorization", token)
				.contentType(MediaType.APPLICATION_JSON)
				.content(jsonQuestion))
				.andExpect(status().isCreated());
	}
	
	/**
	 * Test to get all questions for the given node including questions inside the subfolder...
	 * This is positive test case. Http status 200 is expected
	 * @throws Exception
	 */
	@Test
	public void testGetAllQuestionsByRootContainer() throws Exception {

		mockMvc.perform(
				get("/books/"+bookId+"/nodes/"+nodeId+"/questions?includeInnerContainer=1").header(
						"x-authorization", token)).andExpect(status().isOk());
	}	
	
	/**
	 * Test to get all questions for the given node including questions inside the sub folder with filter meta data..
	 * This is positive use case. Http status 200 is expected.
	 * @throws Exception
	 */
	@Test
	public void testGetAllQuestionsByRootContainerWithFilter() throws Exception {
		mockMvc.perform(get("/books/"+bookId+"/nodes/"+nodeId+"/questions?includeInnerContainer=1&difficulty=medium&topic=maths").header("x-authorization", token))
		.andExpect(status().isOk());
	}
}
