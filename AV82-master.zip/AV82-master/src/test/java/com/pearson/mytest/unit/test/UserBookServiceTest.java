package com.pearson.mytest.unit.test;

import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;

import com.pearson.mytest.bean.QuestionBinding;
import com.pearson.mytest.bean.UserBook;
import com.pearson.mytest.bean.UserQuestionsFolder;
import com.pearson.mytest.proxy.UserBookDelegate;
import com.pearson.mytest.service.UserBookService;
import com.pearson.mytest.service.UserFolderService;

@RunWith(MockitoJUnitRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "file:src/main/webapp/WEB-INF/appServlet-servlet.xml" })
public class UserBookServiceTest {

	@Mock
	private UserBookDelegate userBookRepo;

	@Mock
	private UserFolderService userFolderService;
	
	@InjectMocks
	UserBookService userBookService;

	// to hold Fake objects
	List<UserBook> userBooksFake;
	UserQuestionsFolder userQuestionsFolderFake;
	
	@Before
	public void setUp() throws Exception {

		// prepare fake objects
		userBooksFake = generateFakeUserBooks();	
		userQuestionsFolderFake = FakeObjectHelper.generateFakeUserQuestionsFolder();
	}

	@Test
	public void testGetUserBooks() throws Exception {

		when(userBookRepo.getUserBooks(anyString())).thenReturn(userBooksFake);

		List<UserBook> userBooksResult = userBookService.getUserBooks("ffffffff54b3faa6e4b0f10ebd0747ce");

		Assert.assertEquals(userBooksFake, userBooksResult);
	}
	
	@Test
	public void testImportUserBooks() throws Exception {

		when(userFolderService.getMyQuestionsFolder(anyString())).thenReturn(userQuestionsFolderFake);
		when(userBookRepo.getUserBook(anyString())).thenReturn(userBooksFake.get(0));
		
		ArrayList<String> userBookIds = new ArrayList<String>();
		Collections.addAll(userBookIds, "ddffgghh");
		userBookService.importUserBooks(userBookIds, "ffffffff54b3faa6e4b0f10ebd0747ce");
	}	

	private List<UserBook> generateFakeUserBooks() {
		List<UserBook> userBooksFake = new ArrayList<UserBook>();
		UserBook userBook = new UserBook();
		userBook.setGuid("ddffgghh");
		userBook.setUserId("ffffffff54b3faa6e4b0f10ebd0747ce");
		
		List<String> questionBindings = new ArrayList<String>();
		questionBindings.add("Question1");
		userBook.setQuestionBindings(questionBindings);
		
		List<String> testBindings = new ArrayList<String>();
		testBindings.add("Test1");
		userBook.setTestBindings(testBindings);
		
		userBook.setTitle("title");
		userBook.setIsImported(false);
		userBooksFake.add(userBook);

		return userBooksFake;
	}	

}
