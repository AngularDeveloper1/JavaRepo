package com.pearson.mytest.test;

import static org.springframework.test.util.AssertionErrors.fail;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.List;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mongodb.morphia.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultMatcher;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.util.ObjectUtils;

import com.google.gson.Gson;
import com.pearson.mytest.bean.ArchiveItem;
import com.pearson.mytest.bean.ArchivedFolder;
import com.pearson.mytest.bean.UserFolder;
import com.pearson.mytest.bean.UserQuestionsFolder;
import com.pearson.mytest.controller.ArchiveController;
import com.pearson.mytest.dataaccess.DataAccessHelper;
import com.pearson.mytest.proxy.mytest.repo.ArchiveRepo;
import com.pearson.mytest.proxy.mytest.repo.UserFoldersRepo;
import com.pearson.mytest.unit.test.FakeObjectHelper;
import com.pearson.mytest.util.PIHelper;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "file:src/main/webapp/WEB-INF/appServlet-servlet.xml" })
public class ArchiveControllerTest {

	@Autowired
	ArchiveController archiveController;	
	
	private MockMvc mockMvc;
	private String token;

	private static UserFolder fakeUserFolder, fakeChildUserFolder;
	private static DataAccessHelper<UserFolder> userFolderAccessor;
	private static DataAccessHelper<ArchivedFolder> archivedFolderAccessor;
	
	
	
	/*public ArchiveControllerTest(){
		accessor = new DataAccessHelper<UserFolder>(UserFolder.class);
		//accessorUserQuestionsFolder = new DataAccessHelper<UserQuestionsFolder>(UserQuestionsFolder.class);
	}*/
	@Before
	public void setUp() throws Exception {
		mockMvc = MockMvcBuilders.standaloneSetup(archiveController).build();

        String username = TestData.UserToken.username;
        String password = TestData.UserToken.password;

		token = (new PIHelper()).getPIToken(username, password);
		
		fakeUserFolder = FakeObjectHelper.generateFakeUserFolder();
		
		fakeChildUserFolder = FakeObjectHelper.generateFakeChildUserFolder();		
        
		UserFoldersRepo userFoldersRepo = new UserFoldersRepo();
		userFoldersRepo.saveFolder(fakeUserFolder);
		userFoldersRepo.saveFolder(fakeChildUserFolder);
	}
	
	@After
	public void tearDown() throws Exception {
		UserFoldersRepo userFoldersRepo = new UserFoldersRepo();
		userFoldersRepo.deleteFolder(fakeUserFolder.getGuid());
		userFoldersRepo.deleteFolder(fakeChildUserFolder.getGuid());
	}
	
	@AfterClass
	public static void cleanUp() throws Exception {
		UserFoldersRepo userFoldersRepo = new UserFoldersRepo();
		List<UserFolder> userFolders = getFakeUserFolders();
		for(UserFolder folder :userFolders ){
			userFoldersRepo.deleteFolder(folder.getGuid());
		}

		List<ArchivedFolder> archivedFolders = getFakeArchivedFolders();
		ArchiveRepo archivedFoldersRepo = new ArchiveRepo();
		for(ArchivedFolder folder :archivedFolders ){
			archivedFoldersRepo.deleteFolder(folder.getGuid());
		}
	}
	
	
	@Test
	public void testArchiveFolder() throws Exception {		
						
		ArchiveItem archiveItem = new ArchiveItem();
		archiveItem.setId(fakeUserFolder.getGuid());
		
		String json = (new Gson()).toJson(archiveItem);
		
		mockMvc.perform(
				post("/my/archive/folders")
				.header("x-authorization", token)
				.contentType(MediaType.APPLICATION_JSON)
				.content(json))
				.andExpect(status().isOk());
	}	
	
	@Test
	public void testRestoreFolder() throws Exception {			
		
			
			testArchiveFolder();
						
		ArchiveRepo archiveRepo = new ArchiveRepo();
		ArchivedFolder archivedFolder = archiveRepo.getFolder(fakeUserFolder.getTitle(), null, fakeUserFolder.getUserID());				
		
		ArchiveItem archiveItem = new ArchiveItem();
		archiveItem.setId(archivedFolder.getGuid());
		
		String json = (new Gson()).toJson(archiveItem);
		
		mockMvc.perform(
				post("/my/restore/folders")
				.header("x-authorization", token)
				.contentType(MediaType.APPLICATION_JSON)
				.content(json))
				.andExpect(isOK_Or_Conflict());
		
	}	
	
	@Test
	public void testDeleteFolder() throws Exception {
		
		testArchiveFolder();
		
		ArchiveRepo archiveRepo = new ArchiveRepo();
		ArchivedFolder archivedFolder = archiveRepo.getFolder(fakeUserFolder.getTitle(), null, fakeUserFolder.getUserID());				
		
		ArchiveItem archiveItem = new ArchiveItem();
		archiveItem.setId(archivedFolder.getGuid());
		
		String json = (new Gson()).toJson(archiveItem);
		
		mockMvc.perform(
				delete("/my/delete/folders/" + archivedFolder.getGuid())
				.header("x-authorization", token)
				.contentType(MediaType.APPLICATION_JSON)
				.content(json))
				.andExpect(isOK_Or_Forbidden());
	}
	
	@Test
	public void testArchiveTest() throws Exception {		
						
		ArchiveItem archiveItem = new ArchiveItem();
		archiveItem.setId(fakeUserFolder.getTestBindings().get(0).getTestId() );
		archiveItem.setFolderId(fakeUserFolder.getGuid());
		
		String json = (new Gson()).toJson(archiveItem);
		
		mockMvc.perform(
				post("/my/archive/tests")
				.header("x-authorization", token)
				.contentType(MediaType.APPLICATION_JSON)
				.content(json))
				.andExpect(status().isOk());
	}
	
	@Test
	public void testRestoreTest() throws Exception {			
		
		testArchiveTest();
						
		ArchiveRepo archiveRepo = new ArchiveRepo();
		ArchivedFolder archivedFolder = archiveRepo.getFolder(fakeUserFolder.getTitle(), null, fakeUserFolder.getUserID());				
		
		ArchiveItem archiveItem = new ArchiveItem();
		archiveItem.setId(archivedFolder.getTestBindings().get(0).getTestId());
		archiveItem.setFolderId(archivedFolder.getGuid());
		
		String json = (new Gson()).toJson(archiveItem);
		
		mockMvc.perform(
				post("/my/restore/tests")
				.header("x-authorization", token)
				.contentType(MediaType.APPLICATION_JSON)
				.content(json))
				.andExpect(isOK_Or_Conflict());
	}
	
	@Test
	public void testDeleteTest() throws Exception {
		
		testArchiveTest();
		
		ArchiveRepo archiveRepo = new ArchiveRepo();
		ArchivedFolder archivedFolder = archiveRepo.getFolder(fakeUserFolder.getTitle(), null, fakeUserFolder.getUserID());				
		
		ArchiveItem archiveItem = new ArchiveItem();
		archiveItem.setId(archivedFolder.getTestBindings().get(0).getTestId());
		archiveItem.setFolderId(archivedFolder.getGuid());
		
		String json = (new Gson()).toJson(archiveItem);
		
		mockMvc.perform(
				delete("/my/delete/folders/"+archivedFolder.getGuid()+"/tests/"+archivedFolder.getTestBindings().get(0).getTestId())
				.header("x-authorization", token)
				.contentType(MediaType.APPLICATION_JSON)
				.content(json))
				.andExpect(isOK_Or_Forbidden());
	}		
	

		
    @Test
    public void testGetFolder() throws Exception {
        String folderId = TestData.ArchiveController.folderId;
                
        mockMvc.perform(get("/my/archive/folders/"+folderId+"/folders").header("x-authorization", token))
        .andExpect(status().isOk());
    }
    
    @Test
    public void testGetRootFolders() throws Exception {    
                
        mockMvc.perform(get("/my/archive/folders").header("x-authorization", token))
        .andExpect(status().isOk());
    }
    
    @Test
    public void testGetTests() throws Exception {      
    	
    	testArchiveFolder();
    	
		ArchiveRepo archiveRepo = new ArchiveRepo();
		ArchivedFolder archivedParentFolder = archiveRepo.getFolder(fakeUserFolder.getTitle(), null, fakeUserFolder.getUserID());
		
        mockMvc.perform(get("/my/archive/folders/"+ archivedParentFolder.getGuid() +"/tests").header("x-authorization", token))
        .andExpect(status().isOk());
    }   
    
	public ResultMatcher isOK_Or_Conflict(){
			
			return new ResultMatcher() {
				public void match(MvcResult result) throws Exception {
					if(!(ObjectUtils.nullSafeEquals(HttpStatus.OK.value(), result.getResponse().getStatus()) || ObjectUtils.nullSafeEquals(HttpStatus.CONFLICT.value(), result.getResponse().getStatus())))
						fail("A test with this title already exists...");
				}
			};
		}
  
	public ResultMatcher isOK_Or_Forbidden(){
		
		return new ResultMatcher() {
			public void match(MvcResult result) throws Exception {
				if(!(ObjectUtils.nullSafeEquals(HttpStatus.OK.value(), result.getResponse().getStatus()) || ObjectUtils.nullSafeEquals(HttpStatus.BAD_REQUEST.value(), result.getResponse().getStatus())))
					fail("Unable to delete test...");
			}
		};
	}

	public static List<UserFolder> getFakeUserFolders(){
		userFolderAccessor = new DataAccessHelper<UserFolder>(UserFolder.class);
		Query<UserFolder> query = userFolderAccessor.getDataQuery();
		List<UserFolder> folders = query
				.filter("userId", "ffffffff54b3faa6e4b0f10ebd0747ce")
				.filter("title", "Fake User Folder").asList();
		return folders;
	}
	
	
	public static List<ArchivedFolder> getFakeArchivedFolders(){
		archivedFolderAccessor = new DataAccessHelper<ArchivedFolder>(ArchivedFolder.class);
		Query<ArchivedFolder> query = archivedFolderAccessor.getDataQuery();
		List<ArchivedFolder> folders = query
				.filter("userId", "ffffffff54b3faa6e4b0f10ebd0747ce")
				.filter("title", "Fake User Folder").asList();
		return folders;
	}

}
