package com.pearson.mytest.test;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.pearson.mytest.controller.UserFoldersController;
import com.pearson.mytest.util.PIHelper;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "file:src/main/webapp/WEB-INF/appServlet-servlet.xml" })
public class UserFoldersControllerTest {
	@Autowired
	UserFoldersController userFoldersController;

	private MockMvc mockMvc;
	private String token;
	private String  parentId;

	@Before
	public void setUp() throws Exception {
		mockMvc = MockMvcBuilders.standaloneSetup(userFoldersController).build();
		String username = TestData.UserToken.username;
		String password = TestData.UserToken.password;
		token = (new PIHelper()).getPIToken(username, password);
		parentId = TestData.UserFolderController.parentId;
	}

	@Test
	public void testGetRootFolders() throws Exception {
		
        String userFolders = "{\"title\":\"JUnit test case root fodler\",\"sequence\":1.0,\"parentId\":null}";		
			mockMvc.perform(
				post("/my/folders").header("x-authorization", token)
						.contentType(MediaType.APPLICATION_JSON)
						.content(userFolders)).andExpect(status().isCreated());
		
		mockMvc.perform(get("/my/folders").header("x-authorization", token))
				.andExpect(status().isOk());
	}

	@Test
	public void testGetUserFolders() throws Exception {
		mockMvc.perform(
				get("/my/folders/1ad3a614-451c-4ed0-9caa-257857ad6e81/folders").header(
						"x-authorization", token)).andExpect(
				status().isOk());
	}

	@Test
	public void testSaveFolders() throws Exception {
        String userFolders = "{\"title\":\"JUnit test case fodler\",\"sequence\":1.0,\"parentId\":\"b6ab2013-4e49-463b-b66a-0d28cfe4ab30\"}";

		mockMvc.perform(
				post("/my/folders").header("x-authorization", token)
						.contentType(MediaType.APPLICATION_JSON)
						.content(userFolders)).andExpect(status().isCreated());
	}

	@Test
	public void testSaveFoldersBadRequest() throws Exception {
		String userFolders = "{\"title\":null,\"sequence\":-1.0,\"parentId\":"+parentId+",\"editable\":true}";
		mockMvc.perform(
				post("/my/folders").header("x-authorization", token)
						.contentType(MediaType.APPLICATION_JSON)
						.content(userFolders)).andExpect(
				status().isBadRequest());
	}
	
	@Test
	public void testGetUserQuestionFolders() throws Exception {
		mockMvc.perform(
				get("/my/questionfolders").header(
						"x-authorization", token)).andExpect(
				status().isOk());
	}
	
	@Test
	public void testGetMyTestRoot() throws Exception {
		mockMvc.perform(
				get("/my/testroot").header(
						"x-authorization", token)).andExpect(
				status().isOk());
	}
	
	@Test
	public void testSaveUserQuestionFolder() throws Exception {
        String folder = "{\"title\":\"JUnit test case fodler\",\"sequence\":1.0,\"parentId\":\"b6ab2013-4e49-463b-b66a-0d28cfe4ab30\"}";

		mockMvc.perform(
				post("/my/questionfolders").header("x-authorization", token)
						.contentType(MediaType.APPLICATION_JSON)
						.content(folder)).andExpect(status().isCreated());
	}
	
	@Test
	public void testGetQuestionFoldersRoot() throws Exception {
		mockMvc.perform(
				get("/my/questionfoldersroot").header(
						"x-authorization", token)).andExpect(
				status().isOk());
	}

}
