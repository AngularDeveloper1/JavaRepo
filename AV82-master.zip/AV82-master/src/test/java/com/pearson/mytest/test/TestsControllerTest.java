package com.pearson.mytest.test;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.pearson.mytest.controller.TestsController;
import com.pearson.mytest.util.PIHelper;


@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "file:src/main/webapp/WEB-INF/appServlet-servlet.xml" })
public class TestsControllerTest {
	
	@Autowired
	TestsController testController;
	
	private MockMvc mockMvc;
	private String token;
	private String testId;
	private String bookId;
	@Before
	public void setUp() throws Exception {
		mockMvc = MockMvcBuilders.standaloneSetup(testController).build();
		String username = TestData.UserToken.username;
		String password = TestData.UserToken.password;
		token = (new PIHelper()).getPIToken(username, password);
		testId = TestData.TestController.testId;
		bookId = TestData.TestController.bookId;
		
		
	}
	
	@Test
	public void testGetTestbyId() throws Exception {
		mockMvc.perform(
				get("/tests/"+testId).header("x-authorization", token))
				.andExpect(status().isOk());
		
	}
	
	@Test
	public void testGetPublisherTestsByBookId() throws Exception {
		mockMvc.perform(
				get("/books/"+bookId+"/tests").header("x-authorization", token))
				.andExpect(status().isOk());
	}
	
	@Test
	public void testGetTestQuestions() throws Exception {
		mockMvc.perform(
				get("/test/"+testId+"/questions").header("x-authorization", token))
				.andExpect(status().isOk());
	}
	
	@Test
	public void testGetTestMetadata() throws Exception {
		mockMvc.perform(
				get("/test/"+testId+"/metadata").header("x-authorization", token))
				.andExpect(status().isOk());
	}

}
