package com.pearson.mytest.unit.test;

import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;

import com.pearson.mytest.bean.TestEnvelop;
import com.pearson.mytest.bean.TestMetadata;
import com.pearson.mytest.bean.TestResult;
import com.pearson.mytest.bean.UserFolder;
import com.pearson.mytest.framework.exception.BadDataException;
import com.pearson.mytest.framework.exception.NotFoundException;
import com.pearson.mytest.proxy.MetadataDelegate;
import com.pearson.mytest.proxy.MyTestDelegate;
import com.pearson.mytest.service.MetadataService;
import com.pearson.mytest.service.MyTestService;
import com.pearson.mytest.service.UserFolderService;

@RunWith(MockitoJUnitRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "file:src/main/webapp/WEB-INF/appServlet-servlet.xml" })
public class MyTestServiceTest {

	@Mock
	private MyTestDelegate myTestsRepo;

	@Mock
	private UserFolderService userFolderService;

	@Mock
	private MetadataDelegate metadataRepo;
	
	@Mock
	private MetadataService metadataService;

	@InjectMocks
	MyTestService myTestService;

	// to hold Fake objects
	UserFolder userFolderFake;
	TestEnvelop testEnvelopFake;
	TestResult testResultFake;
	List<TestMetadata> testsFake;
	TestMetadata testMetadataFake;	

	@Before
	public void setUp() throws Exception {

		// prepare fake objects
		userFolderFake = FakeObjectHelper.generateFakeUserFolder();
		testEnvelopFake = FakeObjectHelper.generateFakeTestEnvelop();
		testResultFake = FakeObjectHelper.generateFakeTestResult();
		testsFake = FakeObjectHelper.generateFakeTestMetadataList();
		testMetadataFake = FakeObjectHelper.generateFakeTestMetadata();
		this.stubbingMock();
	}

	private void stubbingMock() {
		when(userFolderService.getFolder("validUser", "invalidFolder"))
				.thenThrow(new BadDataException("Folder not found") );
		when(userFolderService.getMyTestRoot("validUser"))
				.thenReturn(userFolderFake);
		when(userFolderService.getFolder("validUser", "validFolder"))
				.thenReturn(userFolderFake);
		when(myTestsRepo.create(testEnvelopFake)).thenReturn(
				testResultFake);
		when(myTestsRepo.update(testEnvelopFake)).thenReturn(
				testResultFake);
		when(metadataRepo.getMetadata(userFolderFake.getTestBindings().get(0).getTestId())).thenReturn(
				testMetadataFake);
		when(metadataService.getMetadata(userFolderFake.getTestBindings().get(0).getTestId())).thenReturn(
				testMetadataFake);	
	}

	@Test(expected = BadDataException.class)
	public void testSaveTestForFolderNotFound() throws Exception {

		testEnvelopFake.getmetadata().setGuid(null);
		myTestService.saveTest(testEnvelopFake, "validUser", "invalidFolder");

	}

	@Test
	public void testSaveTestForCreate() throws Exception {

		testEnvelopFake.getmetadata().setGuid(null);
		testEnvelopFake.getmetadata().setExtendedMetadata(null);

		TestResult testResult = myTestService.saveTest(testEnvelopFake,
				"validUser", "validFolder");

		Assert.assertEquals(testResultFake, testResult);
	}

	@Test
	public void testSaveTestAtBottomOfFolder() throws Exception {
		testEnvelopFake.getmetadata().setGuid(null);
		testEnvelopFake.getmetadata().setExtendedMetadata(null);

		TestResult testResult = myTestService.saveTest(testEnvelopFake,
				"validUser", "validFolder");

		Assert.assertEquals(testResultFake, testResult);

	}

	@Test
	public void testSaveTestWithSequence() throws Exception {
		testEnvelopFake.getmetadata().setGuid(null);
		testEnvelopFake.getmetadata().addExtendedMetadata(
				FakeObjectHelper.getSequenceExtendedMetadata());
		TestResult testResult = myTestService.saveTest(testEnvelopFake,
				"validUser", "validFolder");

		Assert.assertEquals(testResultFake, testResult);
	}

	@Test
	public void testSaveTestForUpdate() throws Exception {

		TestResult testResult = myTestService.saveTest(testEnvelopFake,
				"validUser", "validFolder");

		Assert.assertEquals(testResultFake, testResult);
	}

	@Test
	public void testGetMyFolderTests() throws Exception {

		List<TestMetadata> tests = myTestService.getMyFolderTests("validUser",
				"validFolder", true);
		Assert.assertEquals(testsFake.get(0).getGuid(), tests.get(0).getGuid());
	}

	@Test
		public void testGetMyFolderTestsByFolder() throws Exception {

			List<TestMetadata> tests = myTestService.getMyFolderTests(userFolderFake);		
			
			Assert.assertEquals(testMetadataFake.getGuid(), tests.get(0).getGuid());
		}
		
	@Test
				
				public void testGetFolderTestsMaxExtMetadataSequence() throws Exception {
					double valueInDouble = 1.0;

					double tests = myTestService.getFolderTestsMaxExtMetadataSequence(userFolderFake);
					Assert.assertEquals(Double.toString(valueInDouble), Double.toString(tests));
				}
	
	@Test
	public void testGetMyFolderTestsByFolderForFolderIdNull() throws Exception {
		List<TestMetadata> tests = myTestService.getMyFolderTests("validUser",null, false);
		Assert.assertEquals(testsFake.get(0).getGuid(), tests.get(0).getGuid());
		
	}
	
	@Test
	public void testSaveTest() throws Exception {
		testEnvelopFake.getmetadata().setGuid("123456");
		testResultFake.setGuid("123456");
		
		TestResult testResult = myTestService.saveTest(testEnvelopFake,"validUser", "validFolder");
		Assert.assertEquals(testResultFake.getGuid(), testResult.getGuid());
		
	}
	

}
