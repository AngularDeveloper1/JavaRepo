package com.pearson.mytest.test;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.pearson.mytest.controller.BooksController;
import com.pearson.mytest.util.PIHelper;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "file:src/main/webapp/WEB-INF/appServlet-servlet.xml" })
public class BooksControllerTest {

	@Autowired
	BooksController booksController;

	private MockMvc mockMvc;
	private String token;
	private String bookId;
	private String bookTitle;

	@Before
	public void setUp() throws Exception {
		mockMvc = MockMvcBuilders.standaloneSetup(booksController).build();
		String username = TestData.UserToken.username;
		String password = TestData.UserToken.password;
		token = (new PIHelper()).getPIToken(username, password);
		bookId = TestData.BookController.bookId;
		bookTitle =TestData.ContainerController.bookTitle;
	}

	/**
	 * Testing status for the api mytest/books PassCriteria : 200
	 * 
	 * @throws Exception
	 */
	@Test
	public void testGetAllBooks() throws Exception {
		mockMvc.perform(get("/books").header("x-authorization", token))
				.andExpect(status().isOk());
	}

	/**
	 * Testing the content type of the response of the api mytest/books
	 * PassCriteria : json
	 * 
	 * @throws Exception
	 */
	@Test
	public void testBooksContentType() throws Exception {
		mockMvc.perform(get("/books").header("x-authorization", token))
				.andExpect(
						content().contentType("application/json;charset=UTF-8"));
	}

	/**
	 * Testing the status for the api mytest/books/{id} PassCriteria : 200
	 * 
	 * @throws Exception
	 */
	@Test
	public void testGetBookById() throws Exception {
		mockMvc.perform(get("/books/"+bookId).header("x-authorization", token))
				.andExpect(status().isOk());
	}
	
	/**
	 * Testing the status for the api mytest/books/{id} PassCriteria : 200
	 * 
	 * @throws Exception
	 */
	@Test
	public void testGetDisciplines() throws Exception {
		mockMvc.perform(get("/disciplines").header("x-authorization", token))
				.andExpect(status().isOk());
	}

	/**
	 * Testing the presence of book for the api mytest/books/{id} PassCriteria :
	 * File not found (http status code 404)
	 * 
	 * @throws Exception
	 */
	@Test
	public void testBookNotFound() throws Exception {
		mockMvc.perform(get("/books/0").header("x-authorization", token))
				.andExpect(status().isNotFound());
	}

	/**
	 * Validating the out put book for the api mytest/books/{id} PassCriteria :
	 * output json should contain title property with value
	 * "MyTest for Limmer, Emergency Care, 12e"
	 * 
	 * @throws Exception
	 */
	@Test
	public void testBookValidate() throws Exception {
		
		String bookTitle =TestData.ContainerController.bookTitle;
		mockMvc.perform(get("/books/"+bookId).header("x-authorization", token))
				.andExpect(
						jsonPath("$.title").value(bookTitle));
	}
	
	/**
	 * Testing the search books on certain Criteria :
	 * output JSON should contain publisher property with value
	 * "Pearson"
	 * 
	 * @throws Exception
	 */
	@Test
	public void testSearchBooks() throws Exception {
		String publisher = TestData.ContainerController.publisher;

		mockMvc.perform(get("/books?title="+bookTitle+"&publisher="+publisher).header("x-authorization", token))
		.andExpect(
				jsonPath("$[0].publisher").value(publisher));
	}
	
	/**
	 * Testing the search books on certain Criteria :
	 * output should give http status 404(Books not found)
	 * 
	 * @throws Exception
	 */
	@Test
	public void testSearchBooksNotFound() throws Exception {
		mockMvc.perform(get("/books?title=Psychology&author=222222&publisher=11111").header("x-authorization", token))
		.andExpect(status().isNotFound());
	}
	
	/**
	 * Testing the search books for give value in (id, title, publisher, discipline, authors, or isbn )
	 * PassCriteria : 200 http status code
	 * 
	 * @throws Exception
	 */
	@Test
	public void testSearchBooksWithOrCriteria() throws Exception {
		mockMvc.perform(get("/books?s=Health").header("x-authorization", token))
		.andExpect(status().isOk());
	} 

}
