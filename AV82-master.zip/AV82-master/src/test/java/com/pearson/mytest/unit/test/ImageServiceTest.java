package com.pearson.mytest.unit.test;

import static org.mockito.Mockito.when;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;

import com.pearson.mytest.proxy.eps.ImageRepo;
import com.pearson.mytest.service.ImageService;



@RunWith(MockitoJUnitRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "file:src/main/webapp/WEB-INF/appServlet-servlet.xml" })
public class ImageServiceTest {
	
	@Mock
	private  ImageRepo imageRepo;
	
	@InjectMocks
	ImageService imageService;
	
	//Generate Fake Image
	MockMultipartFile fakeMultipartFile;
	String fakeImageUrl;
	
	@Before
	public void setUp() throws Exception {
		
		// prepare fake object
		fakeMultipartFile = generateFackMultipartFile();
		fakeImageUrl = generatefackImageUrl();
		
	}	

	@Test
	public void testUploadImage() {
	
		
		when(imageRepo.uploadImage(fakeMultipartFile)).thenReturn(fakeImageUrl);
		String imageUrl = imageService.uploadImage(fakeMultipartFile);
		Assert.assertEquals(fakeImageUrl, imageUrl);
		
	}
	
	private MockMultipartFile generateFackMultipartFile() {
		MockMultipartFile fakeImage = new MockMultipartFile( "file", "Test Content".getBytes());		
		return fakeImage;
	}

	private String generatefackImageUrl() {
		String fakeUrl ="\\abc\\image";		
		return fakeUrl;
	}
}
