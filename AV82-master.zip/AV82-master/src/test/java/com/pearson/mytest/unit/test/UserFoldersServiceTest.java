package com.pearson.mytest.unit.test;

import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;

import com.pearson.mytest.bean.UserFolder;
import com.pearson.mytest.bean.UserQuestionsFolder;
import com.pearson.mytest.framework.exception.BadDataException;
import com.pearson.mytest.framework.exception.NotFoundException;
import com.pearson.mytest.proxy.UserFoldersDelegate;
import com.pearson.mytest.service.UserFolderService;
import com.pearson.mytest.util.UserHelper;

@RunWith(MockitoJUnitRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "file:src/main/webapp/WEB-INF/appServlet-servlet.xml" })
public class UserFoldersServiceTest {

	@Mock
	private UserFoldersDelegate UserFoldersRepo;
	


	@InjectMocks
	UserFolderService userFolderService;

	// to hold Fake objects
	List<UserFolder> userFoldersFake;

	@Before
	public void setUp() throws Exception {

		// prepare fake objects
		userFoldersFake = generateFakeUserFolders();
	}

	@Test
	public void testGetFoldersForFoldersFound() throws Exception {

		when(UserFoldersRepo.getChildFolders(anyString(), anyString())).thenReturn(userFoldersFake);

		List<UserFolder> userFoldersResult = userFolderService.getFolders("userId", "folderId");

		Assert.assertEquals(userFoldersFake, userFoldersResult);
	}

	@Test(expected = NotFoundException.class)
	public void testGetFoldersForFoldersNotFound() throws Exception {

		//when(UserFoldersRepo.getChildFolders(anyString())).thenReturn(new ArrayList<UserFolder>());
		when(UserFoldersRepo.getChildFolders(anyString(), anyString())).thenThrow(
				new NotFoundException("Folder not found"));

		userFolderService.getFolders("userId", "folderId");
	}

	@Test
	public void testGetFolderForFolderFound() throws Exception {

		when(UserFoldersRepo.getFolder(anyString())).thenReturn(
				userFoldersFake.get(0));

		UserFolder userFolderResult = userFolderService.getFolder("userId", "folderId");

		Assert.assertEquals(userFoldersFake.get(0), userFolderResult);
	}

	@Test(expected = NotFoundException.class)
	public void testGetFolderForFolderNotFound() throws Exception {

		when(UserFoldersRepo.getFolder(anyString())).thenThrow(
				new NotFoundException("Folder not found"));

		userFolderService.getFolder("userId", "folderId");
	}

	@Test
	public void testSaveFolder() throws Exception {
		UserFolder userFolder = userFoldersFake.get(0);
		Mockito.doNothing().when(UserFoldersRepo).saveFolders(userFoldersFake);
		UserFolder userFolderResult = userFolderService.saveFolder(userFolder,
				"userID");

		Assert.assertEquals(userFolder, userFolderResult);
	}
	
	@Test
	public void testSaveUserQuestionFolder() throws Exception {
		UserQuestionsFolder folder = generateFakeUserQuestionFolders().get(0);
		Mockito.doNothing().when(UserFoldersRepo).saveFolders(userFoldersFake);
		UserFolder userFolderResult = userFolderService.saveUserQuestionFolder(folder, "userID");

		Assert.assertEquals(folder, userFolderResult);
	}

	@Test(expected = BadDataException.class)
	public void testSaveFolderForUserIdNull() throws Exception {
		String userId = null;
		userFolderService.saveFolder(userFoldersFake.get(0), userId);
	}

	@Test
	public void testSaveFolderForGuidNull() throws Exception {
		UserFolder userFolder = userFoldersFake.get(0);
		userFolder.setGuid(null);
		Mockito.doNothing().when(UserFoldersRepo).saveFolders(userFoldersFake);
		UserFolder userFolderResult = userFolderService.saveFolder(userFolder,
				"userID");

		Assert.assertEquals(userFolder, userFolderResult);
	}
	
	@Test
	public void testGetMyTestRoot(){
		
		userFolderService.getMyTestRoot(UserHelper.getUserId(null));
	}
	
	@Test
	public void testGetQuestionFoldersRoot(){
		
		userFolderService.getQuestionFoldersRoot(UserHelper.getUserId(null));
	}
	
	@Test
	public void testGetMyQuestionsFolder(){
		
		userFolderService.getMyQuestionsFolder(UserHelper.getUserId(null));
	}
	
	@Test
	public void testGetTestFolder() {

		userFolderService.getTestFolder("testId");		 
	}
	
	@Test
	public void testGetFolders() {
		
		when(UserFoldersRepo.getChildFolders(anyString())).thenReturn(userFoldersFake);

		List<UserFolder> userFoldersResult = userFolderService.getFolders("parentFolderId");	
		Assert.assertEquals(userFoldersFake.get(0).getGuid(), userFoldersResult.get(0).getGuid());
	}

	private List<UserQuestionsFolder> generateFakeUserQuestionFolders() {
		List<UserQuestionsFolder> userFoldersFake = new ArrayList<UserQuestionsFolder>();

		UserQuestionsFolder userFolder = new UserQuestionsFolder();
		userFolder.setParentId("parentId");
		userFolder.setSequence(1);
		userFolder.setTitle("title");
		userFoldersFake.add(userFolder);

		return userFoldersFake;
	}
	
	private List<UserFolder> generateFakeUserFolders() {
		List<UserFolder> userFoldersFake = new ArrayList<UserFolder>();

		UserFolder userFolder = new UserFolder();
		String guid = "123";
		userFolder.setParentId("parentId");
		userFolder.setGuid(guid);
		userFolder.setSequence(1);
		userFolder.setTitle("title");
		userFolder.setUserID("userId");
		userFoldersFake.add(userFolder);

		return userFoldersFake;
	}

}
