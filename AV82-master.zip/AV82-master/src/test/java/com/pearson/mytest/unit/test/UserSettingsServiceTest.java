package com.pearson.mytest.unit.test;

import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;

import com.pearson.mytest.bean.PrintSettings;
import com.pearson.mytest.bean.UserSettings;
import com.pearson.mytest.proxy.UserSettingsDelegate;
import com.pearson.mytest.service.UserSettingsService;

@RunWith(MockitoJUnitRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "file:src/main/webapp/WEB-INF/appServlet-servlet.xml" })
public class UserSettingsServiceTest {

	@Mock
	private UserSettingsDelegate userSettingsRepo;

	@InjectMocks
	UserSettingsService userSettingsService;

	// to hold Fake objects
	UserSettings userSettingsFake;
	List<String> disciplinesFake;
	List<String> booksFake;
	List<String> questionMetadataFake;
	PrintSettings printSettings;

	String userid = "userid";

	@Before
	public void setUp() throws Exception {

		// prepare fake objects
		userSettingsFake = generateFakeUserSettings();
		disciplinesFake = generateFakeDisciplines();
		booksFake = generateFakeBooks();
		questionMetadataFake = generateFakeQuestionMetadata();
		printSettings = generateFakePrintSettings();
	}

	@Test
	public void testGetUserSettings() throws Exception {

		when(userSettingsRepo.getUserSettings(anyString())).thenReturn(
				userSettingsFake);

		UserSettings userSettingsResult = userSettingsService
				.getUserSettings(anyString());

		Assert.assertEquals(userSettingsFake, userSettingsResult);
	}

	@Test
	public void testSaveUserSettings() throws Exception {

		Mockito.doNothing().when(userSettingsRepo)
				.saveUserSettings(userSettingsFake);

		userSettingsService.saveUserSettings(userSettingsFake);

		Mockito.verify(userSettingsRepo, Mockito.atLeastOnce())
				.saveUserSettings(userSettingsFake);

	}

	@Test
	public void testGetUserDisciplines() throws Exception {

		when(userSettingsRepo.getUserDisciplines(anyString())).thenReturn(
				disciplinesFake);

		List<String> disciplinesResult = userSettingsService
				.getUserDisciplines(anyString());

		Assert.assertEquals(disciplinesFake, disciplinesResult);
	}

	@Test
	public void testSaveUserDisciplines() throws Exception {

		Mockito.doNothing().when(userSettingsRepo)
				.saveUserDisciplines(userid, disciplinesFake);

		userSettingsService.saveUserDisciplines(userid, disciplinesFake);

		Mockito.verify(userSettingsRepo, Mockito.atLeastOnce())
				.saveUserDisciplines(userid, disciplinesFake);
	}

	@Test
	public void testSaveUserBooks() throws Exception {

		Mockito.doNothing().when(userSettingsRepo)
				.saveUserBooks(userid, booksFake);

		userSettingsService.saveUserBooks(userid, booksFake);

		Mockito.verify(userSettingsRepo, Mockito.atLeastOnce()).saveUserBooks(
				userid, booksFake);

	}

	@Test
	public void testGetUserBooks() throws Exception {

		when(userSettingsRepo.getUserBooks(anyString())).thenReturn(booksFake);

		List<String> userBookResult = userSettingsService
				.getUserBooks(anyString());

		Assert.assertEquals(booksFake, userBookResult);
	}

	@Test
	public void testSaveQuestionMetadata() throws Exception {

		Mockito.doNothing().when(userSettingsRepo)
				.saveQuestionMetadata(userid, questionMetadataFake);

		userSettingsService.saveQuestionMetadata(userid, questionMetadataFake);

		Mockito.verify(userSettingsRepo, Mockito.atLeastOnce())
				.saveQuestionMetadata(userid, questionMetadataFake);

	}

	@Test
	public void testGetQuestionMetadata() throws Exception {

		when(userSettingsRepo.getQuestionMetadata(anyString())).thenReturn(
				questionMetadataFake);

		List<String> questionMetadataResult = userSettingsService
				.getQuestionMetadata(anyString());

		Assert.assertEquals(questionMetadataFake, questionMetadataResult);
	}

	@Test
	public void testSavePrintSettings() throws Exception {

		Mockito.doNothing().when(userSettingsRepo)
				.savePrintSettings(userid, printSettings);

		userSettingsService.savePrintSettings(userid, printSettings);

		Mockito.verify(userSettingsRepo, Mockito.atLeastOnce())
				.savePrintSettings(userid, printSettings);

	}

	@Test
	public void testGetPrintSettings() throws Exception {

		when(userSettingsRepo.getPrintSettings(anyString())).thenReturn(
				printSettings);

		PrintSettings printSettingsResult = userSettingsService
				.getPrintSettings(anyString());

		Assert.assertEquals(printSettings, printSettingsResult);
	}

	private UserSettings generateFakeUserSettings() {

		UserSettings usersettings = new UserSettings();

		usersettings.setUserid(userid);
		PrintSettings printsettings = new PrintSettings();
		usersettings.setPrintSettings(printsettings);
		usersettings.setCreated(new Date());

		return usersettings;
	}

	private List<String> generateFakeDisciplines() {
		List<String> disciplines = new ArrayList<String>();
		disciplines.add("discipline");
		return disciplines;
	}

	private List<String> generateFakeBooks() {
		List<String> books = new ArrayList<String>();
		books.add("bookid");
		return books;
	}

	private List<String> generateFakeQuestionMetadata() {
		List<String> questionMetadata = new ArrayList<String>();
		questionMetadata.add("metadata");
		return questionMetadata;
	}

	private PrintSettings generateFakePrintSettings() {
		PrintSettings printSettings = new PrintSettings();
		printSettings.setFont("font");
		printSettings.setHeaderSpace("headerSpace");
		return printSettings;
	}
}
