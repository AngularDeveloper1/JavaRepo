package com.pearson.mytest.test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.google.gson.Gson;
import com.pearson.mytest.bean.Books;
import com.pearson.mytest.bean.Containers;
import com.pearson.mytest.controller.ImportController;
import com.pearson.mytest.util.PIHelper;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "file:src/main/webapp/WEB-INF/appServlet-servlet.xml" })
public class ImportControllerTest {

	@Autowired
	ImportController booksController;

	private MockMvc mockMvc;
	private String token;

	@Before
	public void setUp() throws Exception {
		mockMvc = MockMvcBuilders.standaloneSetup(booksController).build();
		String username = TestData.UserToken.username;
		String password = TestData.UserToken.password;
		token = (new PIHelper()).getPIToken(username, password);
	}
	
	/**
	 * Testing the import books
	 * @throws Exception
	 */
	@Test
	public void importBooks() throws Exception{
		
		Containers containers =new Containers();
		containers.setGuid("8350785119");
		containers.setTitle("Chapter 1: The Science of Psychology_8350785116");

		List<String> questionBindings=new ArrayList<String>();
		questionBindings.add("fec4fd7b-c753-41a1-a5ec-e5699a439930");
		questionBindings.add("893c6b23-30a9-4e1a-b864-dfe220646264");	
		containers.setQuestionBindings(questionBindings);
		 
		List<Containers> containersList=new   ArrayList<Containers>();
		containersList.add(containers);
		
		Books books = new Books();
		books.setGuid("Book_ID9121");		
		books.setTitle("Psychology, 3e_No_Chapters & Book9_Book_ID9116");
		
		List<String> authors=new ArrayList<String>();
		authors.add("Saundra");
		
		List<String> keywords = new ArrayList<String>();
		keywords.add("MyTest");
		
		Map<String, String> metadata = new HashMap<String, String>();
		metadata.put("bookmark", "enabled");
		
		books.setAuthors(authors);		
		books.setKeywords(keywords);
		books.setMetadata(metadata);
		books.setFormat("application/vnd.pearson.paf.v1.activity.sample+json");
		books.setIsbn10("");
		books.setIsbn13("");
		books.setEditionNumber("1");
		books.setContainers(containersList);
		books.setDiscipline("Law"); 
		books.setIsbn("9780205832888");
		books.setType("MyTest");
		books.setPublisher("Allyn & Bacon");
		
		String jsonBooks = (new Gson()).toJson(books);

		mockMvc.perform(
				post("/books/import")
				.header("x-authorization", token)
				.contentType(MediaType.APPLICATION_JSON)
				.content(jsonBooks))
				.andExpect(status().isCreated());
	}

}
