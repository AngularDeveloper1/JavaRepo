package com.pearson.mytest.unit.test;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.exceptions.base.MockitoException;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;

import com.pearson.mytest.bean.Book;
import com.pearson.mytest.bean.Books;
import com.pearson.mytest.bean.Container;
import com.pearson.mytest.bean.Containers;
import com.pearson.mytest.framework.exception.BadDataException;
import com.pearson.mytest.proxy.BookDelegate;
import com.pearson.mytest.proxy.ContainerDelegate;
import com.pearson.mytest.service.ImportService;

@RunWith(MockitoJUnitRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "file:src/main/webapp/WEB-INF/appServlet-servlet.xml" })
public class ImportServiceTest {

	@Mock
	private BookDelegate bookRepo;

	@Mock
	private ContainerDelegate containerRepo;

	@InjectMocks
	ImportService importService;

	// to hold Fake objects
	Book bookFake;
	Books booksFake;
	List<Container> containersFake;

	@Before
	public void setUp() throws Exception {
		// prepare fake objects
		bookFake = generateFakeBook();
		containersFake = generateFakeContainers();
		booksFake = generateFakeBooks();
		
	}

	@Test
	public void testImportBooks() throws Exception {

		Mockito.doThrow(new MockitoException("bookRepo")).doNothing()
				.when(bookRepo).save(bookFake);

		Mockito.doThrow(new MockitoException("containerRepo")).doNothing()
				.when(containerRepo).save(containersFake);

		importService.importBooks(booksFake);

	}

	@Test(expected = BadDataException.class)
	public void testImportBooksForInvalidBookTitle() throws Exception {
		booksFake.setTitle(null);
		importService.importBooks(booksFake);
	}

	@Test(expected = BadDataException.class)
	public void testImportBooksForInvalidContainerTitle() throws Exception {

		booksFake.getContainers().get(0).setTitle(null);

		importService.importBooks(booksFake);
	}

	private Books generateFakeBooks() {
		Books booksFake = new Books();

		List<String> author = new ArrayList<String>();
		author.add("author");

		Containers containers = new Containers();
		containers.setGuid("8350785119");
		containers.setTitle("Chapter 1: The Science of Psychology_8350785116");

		List<Containers> containersList = new ArrayList<Containers>();
		containersList.add(containers);

		booksFake.setGuid("Book_ID9121");
		booksFake.setTitle("Psychology, 3e_No_Chapters & Book9_Book_ID9116");

		String guid = java.util.UUID.randomUUID().toString();
		booksFake.setGuid(guid);
		booksFake.setTitle("title");
		booksFake
				.setFormat("application/vnd.pearson.paf.v1.activity.sample+json");
		booksFake.setIsbn10("");
		booksFake.setIsbn13("");
		booksFake.setEditionNumber("1");
		booksFake.setDiscipline("Law");
		booksFake.setIsbn("9780205832888");
		booksFake.setType("MyTest");
		booksFake.setAuthors(author);
		booksFake.setPublisher("Allyn & Bacon");
		booksFake.setContainers(containersList);

		return booksFake;
	}

	private List<Container> generateFakeContainers() {
		List<Container> containersFake = new ArrayList<Container>();
		Container container = new Container();
		container.setParentId("parentId");
		container.setBookid("bookId");
		container.setTitle("title");
		containersFake.add(container);

		return containersFake;
	}

	private Book generateFakeBook() {
		Book bookFake = new Book();

		String guid = java.util.UUID.randomUUID().toString();
		bookFake.setGuid(guid);
		bookFake.setTitle("title");

		return bookFake;
	}

}
