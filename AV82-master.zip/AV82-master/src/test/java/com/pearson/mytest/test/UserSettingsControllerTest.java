package com.pearson.mytest.test;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.google.gson.Gson;
import com.pearson.mytest.bean.PrintSettings;
import com.pearson.mytest.bean.UserSettings;
import com.pearson.mytest.controller.UserSettingsController;
import com.pearson.mytest.util.PIHelper;
import com.pearson.mytest.util.UserHelper;


@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "file:src/main/webapp/WEB-INF/appServlet-servlet.xml" })
public class UserSettingsControllerTest {

	@Autowired
	UserSettingsController userSettingsController; 
	
	private MockMvc mockMvc;
	private String token;
	private UserSettings userSettings;

	@Before
	public void setUp() throws Exception {
		mockMvc = MockMvcBuilders.standaloneSetup(userSettingsController).build();
		String username = TestData.UserToken.username;
		String password = TestData.UserToken.password;
		token = (new PIHelper()).getPIToken(username, password);
		userSettings = UserHelper.getDefaultSettings("ffffffff53a1cb46e4b0f6166bbd825b");
		List<String> disciplines =  new ArrayList<String>();
		disciplines.add("Law");
		disciplines.add("Art");
		userSettings.setDisciplines(disciplines);
	}
	
	/**
	 * Testing status for the api mytest/settings PassCriteria : 200
	 * 
	 * @throws Exception
	 */
	@Test
	public void testGetUserSettings() throws Exception {
		mockMvc.perform(get("/settings").header("x-authorization", token))
				.andExpect(status().isOk());
	}
	
	/**
	 * Testing status for the api mytest/settings/printsettings PassCriteria : 200
	 * 
	 * @throws Exception
	 */
	@Test
	public void testGetPrintSettings() throws Exception {
		mockMvc.perform(get("/settings/printsettings").header("x-authorization", token))
				.andExpect(status().isOk());
	}
	
	/**
	 * Testing status for the api mytest/settings/questionmetadata PassCriteria : 200
	 * 
	 * @throws Exception
	 */
	@Test
	public void testGetQuestionMetadata() throws Exception {
		mockMvc.perform(get("/settings/questionmetadata").header("x-authorization", token))
				.andExpect(status().isOk());
	}
	
	/**
	 * Testing status for the api mytest/settings/disciplines PassCriteria : 200
	 * 
	 * @throws Exception
	 */
	@Test
	public void testGetUserDisciplines() throws Exception {
		
		testSaveUserDisciplines();
		
		mockMvc.perform(get("/settings/disciplines").header("x-authorization", token))
				.andExpect(status().isOk());
	}
	
	/**
	 * Testing status for the api mytest/settings/books PassCriteria : 200
	 * 
	 * @throws Exception
	 */
	@Test
	public void testGetUserBooks() throws Exception {
		mockMvc.perform(get("/settings/books").header("x-authorization", token))
				.andExpect(status().isOk());
	}
	
	/**
	 * Testing status for the api mytest/settings/disciplines PassCriteria : 201
	 * 
	 * @throws Exception
	 */
	@Test
	public void testSaveUserDisciplines() throws Exception {
			
		List<String> disciplines = userSettings.getDisciplines();
		
		String jsonDisciplines = (new Gson()).toJson(disciplines);		
		
		mockMvc.perform(post("/settings/disciplines")
				.header("x-authorization", token)
				.contentType(MediaType.APPLICATION_JSON)
				.content(jsonDisciplines) )
				.andExpect(status().isCreated());
	}
	
	/**
	 * Testing status for the api mytest/settings/books PassCriteria : 201
	 * 
	 * @throws Exception
	 */
	@Test
	public void testSaveUserBooks() throws Exception {
				
		List<String> books = userSettings.getBooks();
		
		String jsonBooks = (new Gson()).toJson(books);		
		
		mockMvc.perform(post("/settings/books")
				.header("x-authorization", token)
				.contentType(MediaType.APPLICATION_JSON)
				.content(jsonBooks) )
				.andExpect(status().isCreated());
	}
	
	/**
	 * Testing status for the api mytest/settings/questionmetadata PassCriteria : 201
	 * 
	 * @throws Exception
	 */
	@Test
	public void testSaveUserQuestionMetadata() throws Exception {
				
		List<String> questionMetadata = userSettings.getQuestionMetadata();
		
		String jsonQuestionMetadata = (new Gson()).toJson(questionMetadata);		
		
		mockMvc.perform(post("/settings/questionmetadata")
				.header("x-authorization", token)
				.contentType(MediaType.APPLICATION_JSON)
				.content(jsonQuestionMetadata) )
				.andExpect(status().isCreated());
	}

	/**
	 * Testing status for the api mytest/settings PassCriteria : 201
	 * 
	 * @throws Exception
	 */
	@Test
	public void testSaveUserSettings() throws Exception {				
		
		String jsonUserSettings = (new Gson()).toJson(userSettings);		
		
		mockMvc.perform(post("/settings")
				.header("x-authorization", token)
				.contentType(MediaType.APPLICATION_JSON)
				.content(jsonUserSettings) )
				.andExpect(status().isCreated());
	}
	
	/**
	 * Testing status for the api mytest/settings PassCriteria : 201
	 * 
	 * @throws Exception
	 */
	@Test
	public void testSavePrintSettings() throws Exception {
				
		PrintSettings printSettings = new PrintSettings();
		printSettings = userSettings.getPrintSettings();
		
		String jsonPrintSettings = (new Gson()).toJson(printSettings);		
		
		mockMvc.perform(post("/settings/printsettings")
				.header("x-authorization", token)
				.contentType(MediaType.APPLICATION_JSON)
				.content(jsonPrintSettings) )
				.andExpect(status().isCreated());
	}
	
	/**
	 * Testing status for the api mytest/settings PassCriteria : 400
	 * 
	 * @throws Exception
	 */
	@Test
	public void testSaveUserSettingsWithInvalidNumberOfVersions() throws Exception {			
		
		String jsonUserSettings = (new Gson()).toJson(userSettings);		
		String invalidatedUserSettings = jsonUserSettings.replace("\"numberOfVersions\":3", "\"numberOfVersions\":\"a\"");
		
		mockMvc.perform(post("/settings/printsettings")
				.header("x-authorization", token)
				.contentType(MediaType.APPLICATION_JSON)
				.content(invalidatedUserSettings) )
				.andExpect(status().isBadRequest());
	}
	
	/**
	 * Testing status for the api mytest/settings/printsettings PassCriteria : 400
	 * 
	 * @throws Exception
	 */
	@Test
	public void testSaveUserSettingsValidateNumberOfVersionsInRange() throws Exception {			
		
		String jsonUserSettings = (new Gson()).toJson(userSettings);		
		String invalidatedUserSettings = jsonUserSettings.replace("\"numberOfVersions\":3", "\"numberOfVersions\":0");
		
		mockMvc.perform(post("/settings/printsettings")
				.header("x-authorization", token)
				.contentType(MediaType.APPLICATION_JSON)
				.content(invalidatedUserSettings) )
				.andExpect(status().isBadRequest());
	}
	
	/**
	 * Testing status for the api mytest/settings/printsettings PassCriteria : 400
	 * 
	 * @throws Exception
	 */
	@Test
	public void testSaveUserSettingsValidateScrambleOrder() throws Exception {
				
		String jsonUserSettings = (new Gson()).toJson(userSettings);		
		String invalidatedUserSettings = jsonUserSettings.replace("\"Scramble question order\"", "\"Scramble\"");
		
		mockMvc.perform(post("/settings/printsettings")
				.header("x-authorization", token)
				.contentType(MediaType.APPLICATION_JSON)
				.content(invalidatedUserSettings) )
				.andExpect(status().isBadRequest());
	}

	/**
	 * Testing status for the api mytest/settings/printsettings PassCriteria : 400
	 * 
	 * @throws Exception
	 */
	@Test
	public void testSaveUserSettingsValidateIncludeAreaForStudentResponse() throws Exception {	
		
		String jsonUserSettings = (new Gson()).toJson(userSettings);		
		String invalidatedUserSettings = jsonUserSettings.replace("\"lastPage\":true", "\"lastPage\":false");
		
		mockMvc.perform(post("/settings/printsettings")
				.header("x-authorization", token)
				.contentType(MediaType.APPLICATION_JSON)
				.content(invalidatedUserSettings) )
				.andExpect(status().isBadRequest());
	}
	
	/**
	 * Testing status for the api mytest/settings/printsettings PassCriteria : 400
	 * 
	 * @throws Exception
	 */
	@Test
	public void testSaveUserSettingsValidateIncludeAnswerKeyIn() throws Exception {	
		
		String jsonUserSettings = (new Gson()).toJson(userSettings);		
		String invalidatedUserSettings = jsonUserSettings.replace("\"seperateFile\":false", "\"seperateFile\":true");
		
		mockMvc.perform(post("/settings/printsettings")
				.header("x-authorization", token)
				.contentType(MediaType.APPLICATION_JSON)
				.content(invalidatedUserSettings) )
				.andExpect(status().isBadRequest());
	}	
}
