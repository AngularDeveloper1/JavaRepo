package com.pearson.mytest.unit.test;

import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;

import com.pearson.mytest.bean.Container;
import com.pearson.mytest.bean.QuestionMetadata;
import com.pearson.mytest.proxy.ContainerDelegate;
import com.pearson.mytest.proxy.QuestionDelegate;
import com.pearson.mytest.service.ContainerService;
import com.pearson.mytest.service.QuestionService;

@RunWith(MockitoJUnitRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "file:src/main/webapp/WEB-INF/appServlet-servlet.xml" })
public class ContainerServiceTest {

	@Mock
	private ContainerDelegate containerRepo;

	@InjectMocks
	ContainerService containerService;
	
	@Mock
	 private QuestionDelegate questionRepo;
	
	@Mock
	private QuestionService questionService;

	// to hold Fake objects
	List<Container> containersFake;
	List<Container> containersWithChildrenFake;
	List<QuestionMetadata> questionsFake;
	
	Container fakeContainer;
	private static final String bookId = "1";
	private static final String containerId = "12345";
	private static final String parentContainerId = "123456";
	private static final String childId1 = "123";
	private static final String childId2 = "1234";

	@Before
	public void setUp() throws Exception {

		// prepare fake objects
		containersFake = generateFakeContainers();
		fakeContainer = generateFakeContainer();
		questionsFake = generateFakeQuestions();
		containersWithChildrenFake = generateFakeContainersWithChildren();
	}


	@Test
	public void testGetContainers() throws Exception {

			when(containerRepo.getRootLevelContainersByBookId(bookId)).thenReturn(containersFake);

		List<Container> containersResult = containerService.getContainers(bookId, "", false);

		Assert.assertEquals(containersFake, containersResult);
	}
	
	@Test
	public void testGetContainersWithQuizType() throws Exception {

		when(questionService.getQuestions(anyString())).thenReturn(questionsFake);
			when(containerRepo.getContainersFlatViewByBookId(bookId)).thenReturn(containersFake);
			when(containerRepo.getContainerByContainerId(anyString())).thenReturn(fakeContainer);
			
			
		List<Container> containersResult = containerService.getContainers(bookId, "Essay", false);

		Assert.assertEquals(containersFake.get(0).getGuid(), containersResult.get(0).getGuid());
	}

	@Test
	public void testGetContainerChildrenById() throws Exception {

		when(containerRepo.getContainerChildrenById(anyString())).thenReturn(containersFake);

		List<Container> containersResult = containerService.getContainerChildrenById(anyString());

		Assert.assertEquals(containersFake.get(0).getGuid(), containersResult.get(0).getGuid());
	}

	@Test
	public void testGetContainersByBookIdForContainersFound() throws Exception {

		when(containerRepo.getContainersFlatViewByBookId(anyString())).thenReturn(containersFake);

		List<Container> containersResult = containerService.getContainersFlatViewByBookIds(anyString());

		Assert.assertEquals(containersFake, containersResult);
	}
	
	@Test
	public void testGetContainersIncudeSelf()  throws Exception {		

		when(containerRepo.getContainerById(containerId)).thenReturn(fakeContainer);	
		List<Container> containersResult = containerService.getContainers(bookId,containerId, "", true);
		Assert.assertEquals(containersFake.get(0).getParentId(), containersResult.get(0).getParentId());		
	}
	
	@Test
	public void testGetContainersIncudeSelfWithQuizType()  throws Exception {		

		
		when(questionService.getQuestions(anyString())).thenReturn(questionsFake);
		when(containerRepo.getContainerChildrenById(containerId)).thenReturn(containersFake);
		when(containerRepo.getContainersFlatViewByBookId(bookId)).thenReturn(containersFake);
		when(containerRepo.getContainerById(containerId)).thenReturn(fakeContainer);
		
		List<Container> containersResult = containerService.getContainers(bookId,containerId, "Essay", false);
		Assert.assertEquals(containersFake.get(0).getGuid(), containersResult.get(0).getGuid());		
	}
	
	@Test
	public void testGetContainersIncudeSelfWithQuizTypeAndInnerConditions()  throws Exception {		

		
		when(questionService.getQuestions(anyString())).thenReturn(generateFakeQuestionsWithChildContainer());
		when(containerRepo.getContainerChildrenById(containerId)).thenReturn(containersFake);
		when(containerRepo.getContainersFlatViewByBookId(bookId)).thenReturn(containersWithChildrenFake);
		when(containerRepo.getContainerById(containerId)).thenReturn(fakeContainer);
		when(containerRepo.getContainerChildrenById(parentContainerId)).thenReturn(containersWithChildrenFake);
		when(containerRepo.getContainerChildrenById(childId1)).thenReturn(new ArrayList<Container>());
		when(containerRepo.getContainerChildrenById(childId2)).thenReturn(new ArrayList<Container>());
		
		List<Container> containersResult = containerService.getContainers(bookId,containerId, "Essay", false);
		Assert.assertEquals(containersFake.get(0).getGuid(), containersResult.get(0).getGuid());		
	}
	
	@Test
	public void testGetContainersById()  throws Exception {
		
		when(containerRepo.getContainerById(containerId)).thenReturn(fakeContainer);
		Container containersResult = containerService.getContainerById(containerId);
		Assert.assertEquals(fakeContainer, containersResult);
		
	}

	private List<Container> generateFakeContainers() {
		List<Container> containersFake = new ArrayList<Container>();
		Container container = new Container();
		container.setParentId(null);
		container.setBookid("bookId");
		container.setTitle("title");
		container.setGuid("123456");
	
		List<String> questionBindings = new ArrayList<String>();
		questionBindings.add("123456");
		
		container.setQuestionBindings(questionBindings);
		containersFake.add(container);

		return containersFake;
	}
	
	private List<Container> generateFakeContainersWithChildren() {
		List<Container> containersFake = new ArrayList<Container>();
		Container container = new Container();
		container.setParentId(null);
		container.setBookid("bookId");
		container.setTitle("title");
		container.setGuid("123");
	
		List<String> questionBindings = new ArrayList<String>();
		questionBindings.add("123");		
		container.setQuestionBindings(questionBindings);
		
		Container container1 = new Container();
		container1.setParentId("123");
		container1.setBookid("bookId");
		container1.setTitle("title");
		container1.setGuid("1234");

		List<String> questionBindings1 = new ArrayList<String>();
		questionBindings.add("1234");
		
		container1.setQuestionBindings(questionBindings1);
		containersFake.add(container);
		containersFake.add(container1);
		

		return containersFake;
	}
	
	

	private Container generateFakeContainer() {
		Container container = new Container();
		container.setGuid("123456");
		container.setParentId(null);
		container.setBookid("bookId");
		container.setTitle("title");
		return container;
	}
	
	private List<QuestionMetadata> generateFakeQuestions(){
		List<QuestionMetadata> questions = new ArrayList<QuestionMetadata>();
		QuestionMetadata question = new QuestionMetadata();
        question.setGuid("123456");
        question.setQuizType("Essay");
		questions.add(question);
		return questions;
	}
	private List<QuestionMetadata> generateFakeQuestionsWithChildContainer(){
		List<QuestionMetadata> questions = new ArrayList<QuestionMetadata>();
		QuestionMetadata question = new QuestionMetadata();
        question.setGuid("1234");
        question.setQuizType("Essay");
		questions.add(question);
		return questions;
	}

}
