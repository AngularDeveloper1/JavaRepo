package com.pearson.mytest.unit.test;

import static org.mockito.Matchers.anyList;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;

import com.pearson.mytest.bean.AssignmentBinding;
import com.pearson.mytest.bean.AssignmentContent;
import com.pearson.mytest.bean.Book;
import com.pearson.mytest.bean.TestMetadata;
import com.pearson.mytest.proxy.BookDelegate;
import com.pearson.mytest.proxy.TestDelegate;
import com.pearson.mytest.service.QuestionService;
import com.pearson.mytest.service.TestService;

@RunWith(MockitoJUnitRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "file:src/main/webapp/WEB-INF/appServlet-servlet.xml" })
public class TestServiceTest {

	@Mock
	private TestDelegate testRepo;

	@Mock
	private BookDelegate bookRepo;

	@InjectMocks
	TestService testService;

	@Mock
	QuestionService questionService;

	// to hold Fake objects
	com.pearson.mytest.bean.Test testFake;
	List<TestMetadata> testsFake;
	Book bookfake;

	//private final String guid = java.util.UUID.randomUUID().toString();
	private final String guid = "123456";
	private final String FAKE_TEST_ID = "FAKE_TEST_ID";
	private final String FAKE_BOOK_ID = "FAKE_BOOK_ID";
	

	@Before
	public void setUp() throws Exception {

		// prepare fake objects
		testsFake = generateFakeTests();
		testFake = generateFakeTest();
		bookfake = generateFakeBook();
	}

	@Test
	public void testgetTestByIDForTestFound() throws Exception {

		when(testRepo.getTestByID(FAKE_TEST_ID)).thenReturn(testFake);
		com.pearson.mytest.bean.Test test = testService.getTestByID(FAKE_TEST_ID);

		Assert.assertEquals(testFake.getGuid(), test.getGuid());
	}

	@Test
	public void testGetPublisherTestsByBookId() throws Exception {

		when(bookRepo.getBookByID(FAKE_BOOK_ID)).thenReturn(bookfake);
		when(testRepo.getTestByID(anyString())).thenReturn(testFake);

		List<com.pearson.mytest.bean.Test> TestResult = testService.getPublisherTestsByBookId(FAKE_BOOK_ID);


		Assert.assertEquals(testsFake.get(0).getGuid(), TestResult.get(0).getGuid());
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testGetTestQuestions() {		
		when(testRepo.getTestByID(FAKE_TEST_ID)).thenReturn(testFake);
		when(questionService.getQuestions(anyList())).thenReturn(FakeObjectHelper.generateQuestionsFake());

		List<com.pearson.mytest.bean.QuestionOutput> questionsResult = testService.getTestQuestions(FAKE_TEST_ID);

		Assert.assertEquals(questionsResult.get(0).getGuid(), testFake.getAssignmentContents().getBinding().get(0).getGuid());
	}

	private List<TestMetadata> generateFakeTests() {
		List<TestMetadata> tests = new ArrayList<TestMetadata>();
		TestMetadata testMetadata = new TestMetadata();

		testMetadata.setGuid(guid);
		testMetadata.setTitle("title");
		tests.add(testMetadata);

		return tests;
	}

	private com.pearson.mytest.bean.Test generateFakeTest() {
		com.pearson.mytest.bean.Test paperTest = new com.pearson.mytest.bean.Test();
		paperTest.setGuid(guid);
		paperTest.setTitle("title");

		AssignmentContent assignmentContent = new AssignmentContent();
		List<AssignmentBinding> questionBindings = new ArrayList<AssignmentBinding>();
		AssignmentBinding assignmentBinding = new AssignmentBinding();
		assignmentBinding.setGuid("004c7abc-9abf-45a6-b9cd-6df1daeace36");
		questionBindings.add(assignmentBinding);
		assignmentContent.setBinding(questionBindings);
		paperTest.setAssignmentContents(assignmentContent);

		return paperTest;
	}

	private Book generateFakeBook() {
		Book bookFake = new Book();

		bookFake.setGuid("123456");
		bookFake.setTitle("title");		
		List<String> testBindingLst = new ArrayList<String>();
		testBindingLst.add("Test1");

		bookFake.setTestBindings(testBindingLst);

		return bookFake;
	}

}
