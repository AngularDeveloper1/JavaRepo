package com.pearson.mytest.unit.test;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import com.pearson.mytest.bean.*;
import com.pearson.mytest.util.Common;
import com.pearson.mytest.util.UserHelper;

public final class FakeObjectHelper {
	private FakeObjectHelper() {
	}

	public static TestResult generateFakeTestResult() {
		TestResult testResultFake = new TestResult();

		String guid = java.util.UUID.randomUUID().toString();
		testResultFake.setGuid(guid);

		return testResultFake;
	}

	public static UserFolder generateFakeUserFolder() {
		UserFolder userFolderFake = new UserFolder();
		userFolderFake.setGuid("123456");
		userFolderFake.setUserID(UserHelper.getUserId(null));
		userFolderFake.setTitle("Fake User Folder");
		userFolderFake.setSequence(1.0);
		userFolderFake.setParentId(null);
		
		TestBinding testBindings = new TestBinding();
		testBindings.setTestId("b451df8d-4aaf-4953-83f6-81d73b320d62");
		TestBinding testBindings1 = new TestBinding();
		testBindings1.setTestId("Test1");
		List<TestBinding> testBindingLst = new ArrayList<TestBinding>();
		testBindingLst.add(testBindings);
		userFolderFake.setTestBindings(testBindingLst);
		return userFolderFake;
	}
	
	public static UserFolder generateFakeChildUserFolder() {
		UserFolder userFolderFake = new UserFolder();
		userFolderFake.setGuid("678");
		userFolderFake.setUserID(UserHelper.getUserId(null));
		userFolderFake.setTitle("Fake User Folder Child");
		userFolderFake.setSequence(1.0);
		userFolderFake.setParentId("123456");
		
		TestBinding testBindings = new TestBinding();
		testBindings.setTestId("b451df8d-4aaf-4953-83f6-81d73b320d62");
		TestBinding testBindings1 = new TestBinding();
		testBindings1.setTestId("Test1");
		List<TestBinding> testBindingLst = new ArrayList<TestBinding>();
		testBindingLst.add(testBindings);
		userFolderFake.setTestBindings(testBindingLst);
		return userFolderFake;
	}
	
	public static UserQuestionsFolder generateFakeUserQuestionsFolder() {
		
		UserQuestionsFolder folder = new UserQuestionsFolder();
		
		folder.setGuid(UUID.randomUUID().toString());
		folder.setUserID(UserHelper.getUserId(null));
		folder.setParentId(UserHelper.getUserId(null));
		folder.setTitle("Your Questions");
		
		List<QuestionBinding> questionBindings = new ArrayList<QuestionBinding>();
		QuestionBinding questionBinding = new QuestionBinding();
		questionBinding.setQuestionId("004c7abc-9abf-45a6-b9cd-6df1daeace36");
		questionBindings.add(questionBinding);		
		folder.setQuestionBindings(questionBindings);
		
		folder.setSequence(1.0);		

		return folder;
	}

	public static ArchivedFolder generateFakeArchivedFolder() {
		ArchivedFolder userFolderFake = new ArchivedFolder();
		userFolderFake.setGuid("123456");
		userFolderFake.setUserID("validUser");
		userFolderFake.setTitle("Chapter1");

		TestBinding testBindings = new TestBinding();
		testBindings.setTestId("12345");
		List<TestBinding> testBindingLst = new ArrayList<TestBinding>();
		testBindingLst.add(testBindings);
		userFolderFake.setTestBindings(testBindingLst);
		
		return userFolderFake;
	}

	public static TestMetadata generateFakeTestMetadata() {
		TestMetadata testMetadata = new TestMetadata();
		testMetadata.setTitle("Test 1");
		testMetadata.setGuid("123456");
		testMetadata.addExtendedMetadata(FakeObjectHelper
				.getSequenceExtendedMetadata());
		return testMetadata;

	}

	public static List<TestMetadata> generateFakeTestMetadataList() {
		List<TestMetadata> testsMetadata = new ArrayList<TestMetadata>();
		testsMetadata.add(FakeObjectHelper.generateFakeTestMetadata());
		return testsMetadata;
	}

	public static ExtMetadata getSequenceExtendedMetadata() {
		// Creating sequence extended metadata
		ExtMetadata exMetadata = new ExtMetadata();
		exMetadata.setName(Common.EXTENDED_METADATA_SEQUENCE);
		exMetadata.setValue("1.0");
		return exMetadata;
	}

	public static TestVersionInfo getTestVersionInfo() {
		TestVersionInfo versionInfo = new TestVersionInfo();
		versionInfo.setNoOfVersions(1);
		versionInfo.setScrambleType(TestScrambleType.QUESTIONS);
		return versionInfo;
	}

	public static List<TestResult> generateFakeTestResults() {
		List<TestResult> testResults = new ArrayList<TestResult>();
		testResults.add(FakeObjectHelper.generateFakeTestResult());
		return testResults;
	}

	public static TestEnvelop generateFakeTestEnvelop() {
		TestEnvelop testEnvelopFake = new TestEnvelop();
		Metadata metadata = FakeObjectHelper.generateMetadataFake();
		Test test = FakeObjectHelper.generateTestFake();
		metadata.addExtendedMetadata(FakeObjectHelper
				.getSequenceExtendedMetadata());
		testEnvelopFake.setmetadata(metadata);
		testEnvelopFake.setBody(test);
		return testEnvelopFake;
	}

	public static Metadata generateMetadataFake() {
		Metadata metadata = new Metadata();
		metadata.setTitle("Test1");
		return metadata;
	}

	public static Test generateTestFake() {
		Test test = new Test();
		AssignmentContent assignmentContent = new AssignmentContent();
		List<AssignmentBinding> questionBindings = new ArrayList<AssignmentBinding>();
		AssignmentBinding assignmentBinding1 = new AssignmentBinding();
		assignmentBinding1.setGuid("004c7abc-9abf-45a6-b9cd-6df1daeace36");
		questionBindings.add(assignmentBinding1);
		AssignmentBinding assignmentBinding2 = new AssignmentBinding();
		assignmentBinding2.setGuid("2099dd92-a00f-4390-94a1-0edf8eb3ac0e");

		questionBindings.add(assignmentBinding2);
		assignmentContent.setBinding(questionBindings);
		test.setAssignmentContents(assignmentContent);
		test.setTitle("Test1");
		return test;
	}
	
	public static List<QuestionOutput> generateQuestionsFake() {
		List<QuestionOutput> questions = new ArrayList<QuestionOutput>();
		questions.add(generateQuestionFake());
		return questions;
	}
	
	public static QuestionOutput generateQuestionFake() {
		QuestionOutput question = new QuestionOutput();
		question.setGuid("004c7abc-9abf-45a6-b9cd-6df1daeace36");
		Metadata metadata = new Metadata();
		metadata.setTitle("Test1");
		question.setMetadata(metadata);
		return question;
	}


}
