package com.pearson.mytest.test;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.pearson.mytest.controller.ContainersController;
import com.pearson.mytest.util.PIHelper;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "file:src/main/webapp/WEB-INF/appServlet-servlet.xml" })
public class ContainersControllerTest {

	@Autowired
	ContainersController ContainerController;

	private MockMvc mockMvc;
	private String token;
	private String bookId;

	@Before
	public void setUp() throws Exception {
		mockMvc = MockMvcBuilders.standaloneSetup(ContainerController).build();
		String username = TestData.UserToken.username;
		String password = TestData.UserToken.password;
		token = (new PIHelper()).getPIToken(username, password);
		bookId = TestData.ContainerController.bookId;
		
	}

	/**
	 * Testing the books root children by book id PassCriteria : should give
	 * http status 200
	 * 
	 * @throws Exception
	 */
	@Test
	public void testGetContainersByBook() throws Exception {

		mockMvc.perform(
				get("/books/"+bookId+"/nodes").header("x-authorization", token))
				.andExpect(status().isOk());
	}
	
	@Test
	public void testGetContainersFlatViewByBookIds() throws Exception {

		mockMvc.perform(
				get("/books/"+bookId+"/nodes?flat=true").header("x-authorization",
						token)).andExpect(status().isOk());
	}
	@Test
	public void testGetContainerChildrenById() throws Exception {
		String book = TestData.QuestionsController.bookId;
		String node = TestData.QuestionsController.nodeId;
		

		mockMvc.perform(
				get("/books/"+book+"/nodes/"+node+"/nodes").header("x-authorization",
						token)).andExpect(status().isOk());
	}
}
