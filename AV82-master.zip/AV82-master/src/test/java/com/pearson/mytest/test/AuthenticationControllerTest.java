package com.pearson.mytest.test;

import static org.springframework.test.util.AssertionErrors.fail;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.mock;

import java.util.ArrayList;
import javax.servlet.http.HttpServletRequest;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultMatcher;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.util.ObjectUtils;

import com.pearson.mytest.controller.AuthenticationController;
import com.pearson.mytest.provider.pi.service.AuthenticationService;
import com.pearson.mytest.provider.pi.service.Data;
import com.pearson.mytest.provider.pi.service.Email;
import com.pearson.mytest.provider.pi.service.UserProfile;
import com.pearson.mytest.util.PIHelper;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "file:src/main/webapp/WEB-INF/appServlet-servlet.xml" })
public class AuthenticationControllerTest {				

	@Mock
	private AuthenticationService authenticationService;
	
	@InjectMocks
	AuthenticationController authenticationController;
	
	private MockMvc mockMvc;
	private String token;
	private UserProfile userProfile = new UserProfile();
	
	@Before
	public void setUp() throws Exception {
		//mockMvc = MockMvcBuilders.standaloneSetup(authenticationController).build();		
		MockitoAnnotations.initMocks(this);
        this.mockMvc = MockMvcBuilders.standaloneSetup(authenticationController).build();
        
        String username = TestData.UserToken.username;
		String password = TestData.UserToken.password;
		token = (new PIHelper()).getPIToken(username, password);
		
	   userProfile = getUserProfile();
	}
	
	@Test
	public void testAuthenticateForInvalid() throws Exception {
			
		HttpServletRequest request = mock(HttpServletRequest.class);
		when(request.getHeader("AccessToken")).thenReturn("validtoken");		
		
		
		when(authenticationService.getPITokenFromAccessToken(anyString())).thenReturn(token);
		when(authenticationService.getUserProfileFromPIApi(anyString(), anyString())).thenReturn(userProfile);
		
		mockMvc.perform(
				post("/login")
				.header("AccessToken", "validtoken")
				.contentType(MediaType.APPLICATION_JSON))
				.andExpect(isOK_Or_Unauthorized());
	}
	
	@Test
	public void testAuthenticateForValid() throws Exception {
			
		HttpServletRequest request = mock(HttpServletRequest.class);
		when(request.getHeader("AccessToken")).thenReturn("validtoken");		
		
		
		when(authenticationService.getPITokenFromAccessToken(anyString())).thenReturn(token);
		when(authenticationService.getUserProfileFromPIApi(anyString(), anyString())).thenReturn(userProfile);
		when(authenticationService.isIntructor(anyString(), anyString())).thenReturn(true);
		
		mockMvc.perform(
				post("/login")
				.header("AccessToken", "validtoken")
				.contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk());
	}

	private UserProfile getUserProfile() {
		UserProfile userProfile = new UserProfile(); 
		Email email = new Email();
		email.isPrimary = true;
		email.emailAddress = "login@unittest.com";
		Data data = new Data();
		data.emails = new ArrayList<Email>();
		data.emails.add(email);
		data.familyName = "unittest";
		data.givenName = "login";
		userProfile.data = data;
		return userProfile;
	}
	
	public ResultMatcher isOK_Or_Unauthorized(){
		
		return new ResultMatcher() {
			public void match(MvcResult result) throws Exception {
				if(!(ObjectUtils.nullSafeEquals(HttpStatus.OK.value(), result.getResponse().getStatus()) || ObjectUtils.nullSafeEquals(HttpStatus.UNAUTHORIZED.value(), result.getResponse().getStatus())))
					fail("Login test get failed...");
			}
		};
	}
}
