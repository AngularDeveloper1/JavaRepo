package com.pearson.mytest.unit.test;

import static org.mockito.Mockito.when;
import static org.mockito.Matchers.*;

import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;

import com.pearson.mytest.bean.ArchivedFolder;
import com.pearson.mytest.bean.Metadata;
import com.pearson.mytest.bean.TestEnvelop;
import com.pearson.mytest.bean.TestResult;
import com.pearson.mytest.bean.TestVersionInfo;
import com.pearson.mytest.bean.UserFolder;
import com.pearson.mytest.framework.exception.BadDataException;
import com.pearson.mytest.framework.exception.NotFoundException;
import com.pearson.mytest.proxy.MetadataDelegate;
import com.pearson.mytest.proxy.TestVersionDelegate;
import com.pearson.mytest.proxy.paf.repo.TestVersionRepo;
import com.pearson.mytest.service.ArchiveService;
import com.pearson.mytest.service.MetadataService;
import com.pearson.mytest.service.MyTestService;
import com.pearson.mytest.service.TestService;
import com.pearson.mytest.service.TestVersionService;
import com.pearson.mytest.service.UserFolderService;

@RunWith(MockitoJUnitRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "file:src/main/webapp/WEB-INF/appServlet-servlet.xml" })
public class TestVersionServiceTest {

	@Mock
	private UserFolderService userFolderService;

	@Mock
	private TestService testService;

	@Mock
	private TestVersionRepo testVersionRepo;

	@Mock
	private MetadataDelegate metadataRepo;

	@Mock
	private MyTestService myTestService;
	
	@Mock
	private MetadataService metadataService;

	@InjectMocks
	TestVersionService testVersionService;

	@Mock
	private TestVersionDelegate testVersionDelegate;
	@Mock
	private ArchiveService archiveService;

	TestVersionInfo versionInfoFake;
	TestResult testResultFake;
	List<TestResult> testResultsFake;
	TestEnvelop testEnvelopFake;
	UserFolder userFolderFake;
	com.pearson.mytest.bean.Test testFake;
	Metadata metadataFake;
	String testVersions;
	ArchivedFolder archivedFolder;
	Metadata versionedTestMetadata;

	@Before
	public void setUp() throws Exception {
		versionInfoFake = FakeObjectHelper.getTestVersionInfo();
		userFolderFake = FakeObjectHelper.generateFakeUserFolder();
		testResultFake = FakeObjectHelper.generateFakeTestResult();
		testResultsFake = FakeObjectHelper.generateFakeTestResults();
		testFake = FakeObjectHelper.generateTestFake();
		metadataFake = FakeObjectHelper.generateMetadataFake();
		testEnvelopFake = FakeObjectHelper.generateFakeTestEnvelop();
		testVersions = getFakeTestVersions();
		archivedFolder = getFakeArchivedFolder();
		versionedTestMetadata = getFakeMetadata();

		this.stubbingMock();
	}

	private ArchivedFolder getFakeArchivedFolder() {
		ArchivedFolder archivedFolder = new ArchivedFolder();
		archivedFolder.setGuid("2099dd92-a00f-4390-94a1-0edf8eb3ac0e");

		return archivedFolder;
	}

	private String getFakeTestVersions() {

		return "http://localhost:8080/mytest/tests/b451df8d-4aaf-4953-83f6-81d73b320d62";
	}

	private Metadata getFakeMetadata() {
		Metadata metadata = new Metadata();
		metadata.setGuid("2099dd92-a00f-4390-94a1-0edf8eb3ac0e");
		metadata.setVersion("1");
		metadata.setTitle("Test1_v1");
		return metadata;
	}

	private void stubbingMock() {

		when(myTestService.getFolderTestsMaxExtMetadataSequence(userFolderFake))
				.thenReturn(1.0);
		when(testService.getTestByID("validTest")).thenReturn(testFake);
		when(metadataRepo.getMetadata("validTest"))
				.thenReturn(metadataFake);
		when(
				testVersionRepo.createVersionTest(any(TestEnvelop.class), eq("validTest"))).thenReturn(testResultFake);

		when(userFolderService.getTestFolder("validTest")).thenReturn(
				userFolderFake);
	}

	@Test(expected = BadDataException.class)
	public void testCreateVersionTestsBadData() throws Exception {
		when(userFolderService.getFolder(anyString(), anyString())).thenThrow(
				new NotFoundException("Folder not found"));
		testVersionService.createVersionTests(versionInfoFake, "validTest",
				"invalidUser");
	}

	@Test
	public void testCreateVersionTests() throws Exception {
		when(userFolderService.getFolder(anyString(), anyString())).thenReturn(
				userFolderFake);
		when(testVersionRepo.getTestVersions("validTest")).thenReturn(
				testVersions);
		
		when(metadataService.getMetadata("validTest")).thenReturn(
				versionedTestMetadata);		

		when(testVersionDelegate.getTestVersions(anyString())).thenReturn(
				testVersions);
		
		when(metadataRepo.getMetadata(anyString())).thenReturn(
				versionedTestMetadata);
		when(archiveService.getTestFolder(anyString())).thenReturn(null);

		List<TestResult> testResults = testVersionService.createVersionTests(
				versionInfoFake, "validTest", "validUser");
		testEnvelopFake.getmetadata().setExtendedMetadata(null);
		Assert.assertEquals(1, testResults.size());
	}

	@Test
	public void testCreateVersionTestsWithSequence() throws Exception {
		when(userFolderService.getFolder(anyString(), anyString())).thenReturn(
				userFolderFake);
		
		when(metadataService.getMetadata("validTest")).thenReturn(
				versionedTestMetadata);
		when(testVersionRepo.getTestVersions("validTest")).thenReturn("");
		List<TestResult> testResults = testVersionService.createVersionTests(
				versionInfoFake, "validTest", "validUser");
		Assert.assertEquals(1, testResults.size());
	}

}
