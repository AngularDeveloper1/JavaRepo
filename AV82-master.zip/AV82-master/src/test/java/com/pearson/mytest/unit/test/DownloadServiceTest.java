package com.pearson.mytest.unit.test;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.when;

import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;

import com.pearson.mytest.bean.AnswerAreas;
import com.pearson.mytest.bean.AnswerKeys;
import com.pearson.mytest.bean.ArchivedFolder;
import com.pearson.mytest.bean.AssignmentBinding;
import com.pearson.mytest.bean.AssignmentContent;
import com.pearson.mytest.bean.DownloadFormat;
import com.pearson.mytest.bean.DownloadInfo;
import com.pearson.mytest.bean.DownloadOutput;
import com.pearson.mytest.bean.Metadata;
import com.pearson.mytest.bean.PageNumberDisplay;
import com.pearson.mytest.bean.PrintSettings;
import com.pearson.mytest.bean.UserSettings;
import com.pearson.mytest.download.Pdf;
import com.pearson.mytest.download.TestDownload;
import com.pearson.mytest.framework.exception.ExpectationException;
import com.pearson.mytest.proxy.MetadataDelegate;
import com.pearson.mytest.proxy.QuestionDelegate;
import com.pearson.mytest.proxy.TestDelegate;
import com.pearson.mytest.proxy.TestVersionDelegate;
import com.pearson.mytest.proxy.UserSettingsDelegate;
import com.pearson.mytest.proxy.mytest.repo.ArchiveRepo;
import com.pearson.mytest.service.DownloadService;
import com.pearson.mytest.service.MetadataService;

@RunWith(MockitoJUnitRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "file:src/main/webapp/WEB-INF/appServlet-servlet.xml" })
public class DownloadServiceTest {

	@InjectMocks
	DownloadService downloadService;
	@Spy
	TestDownload downloadpdf = new Pdf();
	@Mock
	private TestDownload download;
	@Mock
	private TestDelegate testRepo;
	@Mock
	private QuestionDelegate fakeQuestionRepo;
	@Mock
	private com.pearson.mytest.bean.Test test;
	@Mock
	private UserSettingsDelegate userSettingsDelegate;
	@Mock
	private UserSettings userSettings;
	@Mock
	private TestVersionDelegate testVersionDelegate;
	@Mock
	private MetadataDelegate metadataDelegate;
	@Mock
	private ArchiveRepo archiveRepo;
	@Mock
	private MetadataService metadataService;

	DownloadOutput fakeDownloadOutput;
	DownloadOutput fakeDownloadOutputZip;
	com.pearson.mytest.bean.Test fakeTestDetail;
	List<AssignmentBinding> fakeBindingsList;
	String fakeQTIXML;
	String fakeQTIXMLForEssay;
	String fakeQTIXMLForMatching;
	String fakeQTIXMLForHorizontalOrien;
	PrintSettings fakePrintSettings;
	UserSettings fakeUserSettings;
	UserSettings fakeUserSettingsForAnsSameFile;
	UserSettings fakeUserSettingsForAnsSeperateFile;
	OutputStream stream;
	DownloadInfo downloadInfo;
	String testVersions;
	Metadata metadata;
	ArchivedFolder archivedFolder;

	@Before
	public void setUp() throws Exception {

		fakeDownloadOutput = generateFakeDownloadOutput();
		fakeTestDetail = generateFakeTest();
		fakeBindingsList = generateFakeAssignmentBindingList();
		fakeQTIXML = generateFakeQuestionRepo();
		fakeQTIXMLForEssay = generateFakeQuestionRepoForEssay();
		fakeQTIXMLForMatching = generateFakeQuestionRepoForMatching();
		fakeQTIXMLForHorizontalOrien = generateFakeHorizontalOrientation();
		fakeUserSettings = generateFakeUserSettings();
		fakeUserSettingsForAnsSameFile = generateFakeUserSettingsForAnsSameFile();
		fakeUserSettingsForAnsSeperateFile = generateFakeUserSettingsForSeperateFile();
		fakePrintSettings = generateFakePrintSettings();
		downloadInfo = generateFakeDownloadInfo();
		stream = new ByteArrayOutputStream();
		testVersions = getFakeTestVersions();
		metadata = getFakeMetadata();
		archivedFolder = getFakeArchivedFolder();
		fakeDownloadOutputZip=generateFakeDownloadOutputForZip();
	}

	private ArchivedFolder getFakeArchivedFolder() {
		ArchivedFolder archivedFolder = new ArchivedFolder();
		archivedFolder.setGuid("2099dd92-a00f-4390-94a1-0edf8eb3ac0e");

		return archivedFolder;
	}

	private Metadata getFakeMetadata() {
		Metadata metadata = new Metadata();
		metadata.setGuid("2099dd92-a00f-4390-94a1-0edf8eb3ac0e");
		metadata.setVersion("1");
		metadata.setTitle("MyTest_v1");
		return metadata;
	}

	private String getFakeTestVersions() {

		return "http://localhost:8080/mytest/tests/c01a0fdc-dd52-4035-ae3b-b7cebc6f771c";
	}

	private DownloadOutput generateFakeDownloadOutput() {
		DownloadOutput downloadOutput = new DownloadOutput();
		downloadOutput.setContentType("pdf");
		downloadOutput.setFileName("MyTest.pdf");
		return downloadOutput;
	}
	
	private DownloadOutput generateFakeDownloadOutputForZip() {
		DownloadOutput downloadOutput = new DownloadOutput();
		downloadOutput.setContentType("zip");
		downloadOutput.setFileName("MyTest.zip");
		return downloadOutput;
	}
	
	private com.pearson.mytest.bean.Test generateFakeTest() {
		com.pearson.mytest.bean.Test test = new com.pearson.mytest.bean.Test();
		test.setTitle("MyTest");
		AssignmentContent assignmentContent = new AssignmentContent();
		assignmentContent.setBinding(generateFakeAssignmentBindingList());
		test.setAssignmentContents(assignmentContent);
		return test;
	}

	private List<AssignmentBinding> generateFakeAssignmentBindingList() {
		List<AssignmentBinding> assignmentBindingList = new ArrayList<AssignmentBinding>();

		AssignmentBinding assignmentBinding = new AssignmentBinding();
		assignmentBinding.setGuid(java.util.UUID.randomUUID().toString());
		assignmentBinding.setActivityFormat("Test");
		assignmentBinding.setBindingIndex(1);

		assignmentBindingList.add(assignmentBinding);

		return assignmentBindingList;

	}

	private String generateFakeQuestionRepo() {
		return "<?xml version=\"1.0\" encoding=\"utf-8\"?><assessmentItem xmlns=\"http://www.imsglobal.org/xsd/imsqti_v2p1\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"http://www.imsglobal.org/xsd/imsqti_v2p1 http://www.imsglobal.org/xsd/qti/qtiv2p1/imsqti_v2p1.xsd\" title=\"03-1-13\" identifier=\"Identifier\" label=\"03-1-13\" toolName=\"pegasus\" toolVersion=\"toolversion\" adaptive=\"false\" timeDependent=\"false\"><responseDeclaration identifier=\"RESPONSE\" cardinality=\"single\" baseType=\"identifier\" /><outcomeDeclaration identifier=\"FEEDBACK\" cardinality=\"single\" baseType=\"identifier\" /><outcomeDeclaration identifier=\"ITEMSCORE\" cardinality=\"single\" baseType=\"float\" /><outcomeDeclaration identifier=\"SCORE\" cardinality=\"single\" baseType=\"float\" normalMaximum=\"1\"><defaultValue><value>0</value></defaultValue></outcomeDeclaration><outcomeDeclaration identifier=\"MAXSCORE\" cardinality=\"single\" baseType=\"float\"><defaultValue><value>1</value></defaultValue></outcomeDeclaration><itemBody><p><![CDATA[Which process of perceptual organization and interpretation is being used when we use information we think we know about a person to make assumptions about things we don&rsquo;t know about the person?]]></p><choiceInteraction shuffle=\"true\" responseIdentifier=\"RESPONSE\" maxChoices=\"1\" minChoices=\"1\"><simpleChoice identifier=\"RESPONSE_1\" fixed=\"false\"><![CDATA[impression formation]]></simpleChoice><simpleChoice identifier=\"RESPONSE_2\" fixed=\"false\"><![CDATA[implicit personality theory]]></simpleChoice><simpleChoice identifier=\"RESPONSE_3\" fixed=\"false\"><![CDATA[causal attribution theory]]></simpleChoice><simpleChoice identifier=\"RESPONSE_4\" fixed=\"false\"><![CDATA[correspondence inference theory]]></simpleChoice></choiceInteraction></itemBody><responseProcessing><responseCondition><responseIf><match><variable identifier=\"RESPONSE\" /><baseValue baseType=\"identifier\">RESPONSE_1</baseValue></match><setOutcomeValue identifier=\"SCORE\"><baseValue baseType=\"float\">0</baseValue></setOutcomeValue><setOutcomeValue identifier=\"FEEDBACK\"><baseValue baseType=\"identifier\">FEEDBACK_1</baseValue></setOutcomeValue></responseIf><responseElseIf><match><variable identifier=\"RESPONSE\" /><baseValue baseType=\"identifier\">RESPONSE_2</baseValue></match><setOutcomeValue identifier=\"SCORE\"><baseValue baseType=\"float\">1</baseValue></setOutcomeValue><setOutcomeValue identifier=\"FEEDBACK\"><baseValue baseType=\"identifier\">FEEDBACK_2</baseValue></setOutcomeValue></responseElseIf><responseElseIf><match><variable identifier=\"RESPONSE\" /><baseValue baseType=\"identifier\">RESPONSE_3</baseValue></match><setOutcomeValue identifier=\"SCORE\"><baseValue baseType=\"float\">0</baseValue></setOutcomeValue><setOutcomeValue identifier=\"FEEDBACK\"><baseValue baseType=\"identifier\">FEEDBACK_3</baseValue></setOutcomeValue></responseElseIf><responseElseIf><match><variable identifier=\"RESPONSE\" /><baseValue baseType=\"identifier\">RESPONSE_4</baseValue></match><setOutcomeValue identifier=\"SCORE\"><baseValue baseType=\"float\">0</baseValue></setOutcomeValue><setOutcomeValue identifier=\"FEEDBACK\"><baseValue baseType=\"identifier\">FEEDBACK_4</baseValue></setOutcomeValue></responseElseIf></responseCondition></responseProcessing></assessmentItem>";
	}
	
	private String generateFakeQuestionRepoForEssay(){
		return "<?xml version=\"1.0\" encoding=\"utf-8\"?><assessmentItem xmlns=\"http://www.imsglobal.org/xsd/imsqti_v2p1\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"http://www.imsglobal.org/xsd/imsqti_v2p1 http://www.imsglobal.org/xsd/qti/qtiv2p1/imsqti_v2p1.xsd\" title=\"01-3-13\" identifier=\"Identifier\" label=\"01-3-13\" toolName=\"pegasus\" toolVersion=\"toolversion\" adaptive=\"false\" timeDependent=\"false\"><responseDeclaration identifier=\"RESPONSE\" cardinality=\"single\" baseType=\"identifier\"><correctResponse><value><![CDATA[The model of <i>communication as transaction</i> acknowledges that when we talk to another person face-to-face, we are constantly reacting to our partner's responses. Thus, all the components of the communication process in this model are simultaneous.]]></value></correctResponse></responseDeclaration><outcomeDeclaration identifier=\"FEEDBACK\" cardinality=\"single\" baseType=\"identifier\" /><outcomeDeclaration identifier=\"ITEMSCORE\" cardinality=\"single\" baseType=\"float\" /><outcomeDeclaration identifier=\"SCORE\" cardinality=\"single\" baseType=\"float\" normalMaximum=\"1\"><defaultValue><value>0</value></defaultValue></outcomeDeclaration><outcomeDeclaration identifier=\"MAXSCORE\" cardinality=\"single\" baseType=\"float\"><defaultValue><value>1</value></defaultValue></outcomeDeclaration><itemBody><blockquote><p>Discuss in which communication model the sources can be both sender and receiver.</p></blockquote><extendedTextInteraction expectedLength=\"1000\" expectedLines=\"10\" responseIdentifier=\"RESPONSE\" /></itemBody><responseProcessing><responseCondition><responseIf><not><isNull><variable identifier=\"RESPONSE\" /></isNull></not><setOutcomeValue identifier=\"FEEDBACK\"><baseValue baseType=\"identifier\">FEEDBACK-1</baseValue></setOutcomeValue></responseIf></responseCondition></responseProcessing></assessmentItem>";
	}
	
	private String generateFakeQuestionRepoForMatching(){
		return "<?xml version=\"1.0\" encoding=\"utf-8\"?><assessmentItem xmlns=\"http://www.imsglobal.org/xsd/imsqti_v2p1\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"http://www.imsglobal.org/xsd/imsqti_v2p1 http://www.imsglobal.org/xsd/qti/qtiv2p1/imsqti_v2p1.xsd\" title=\"07-4-02\" identifier=\"Identifier\" label=\"07-4-02\" toolName=\"pegasus\" toolVersion=\"toolversion\" adaptive=\"false\" timeDependent=\"false\"><responseDeclaration identifier=\"RESPONSE_1\" cardinality=\"single\" baseType=\"identifier\"><mapping defaultValue=\"0\"><mapEntry mapKey=\"RESP_1\" mappedValue=\"1\" /></mapping></responseDeclaration><responseDeclaration identifier=\"RESPONSE_2\" cardinality=\"single\" baseType=\"identifier\"><mapping defaultValue=\"0\"><mapEntry mapKey=\"RESP_2\" mappedValue=\"1\" /></mapping></responseDeclaration><responseDeclaration identifier=\"RESPONSE_3\" cardinality=\"single\" baseType=\"identifier\"><mapping defaultValue=\"0\"><mapEntry mapKey=\"RESP_3\" mappedValue=\"1\" /></mapping></responseDeclaration><responseDeclaration identifier=\"RESPONSE_4\" cardinality=\"single\" baseType=\"identifier\"><mapping defaultValue=\"0\"><mapEntry mapKey=\"RESP_4\" mappedValue=\"1\" /></mapping></responseDeclaration><responseDeclaration identifier=\"RESPONSE_5\" cardinality=\"single\" baseType=\"identifier\"><mapping defaultValue=\"0\"><mapEntry mapKey=\"RESP_5\" mappedValue=\"1\" /></mapping></responseDeclaration><outcomeDeclaration identifier=\"FEEDBACK-1\" cardinality=\"single\" baseType=\"identifier\" /><outcomeDeclaration identifier=\"FEEDBACK-2\" cardinality=\"single\" baseType=\"identifier\" /><outcomeDeclaration identifier=\"FEEDBACK-3\" cardinality=\"single\" baseType=\"identifier\" /><outcomeDeclaration identifier=\"FEEDBACK-4\" cardinality=\"single\" baseType=\"identifier\" /><outcomeDeclaration identifier=\"FEEDBACK-5\" cardinality=\"single\" baseType=\"identifier\" /><outcomeDeclaration identifier=\"ITEMSCORE\" cardinality=\"single\" baseType=\"float\" /><outcomeDeclaration identifier=\"SCORE\" cardinality=\"single\" baseType=\"float\" normalMaximum=\"5\"><defaultValue><value>0</value></defaultValue></outcomeDeclaration><outcomeDeclaration identifier=\"MAXSCORE\" cardinality=\"single\" baseType=\"float\"><defaultValue><value>5</value></defaultValue></outcomeDeclaration><itemBody><p><![CDATA[<EM>Match the definition on the left with the term on the right.</EM>]]></p><blockquote><p><![CDATA[the mirroring of each other&rsquo;s nonverbal behavior by communication partners]]><inlineChoiceInteraction responseIdentifier=\"RESPONSE_1\" shuffle=\"true\"><inlineChoice identifier=\"RESP_1\"><![CDATA[interactional synchrony]]></inlineChoice><inlineChoice identifier=\"RESP_2\"><![CDATA[emblems]]></inlineChoice><inlineChoice identifier=\"RESP_3\"><![CDATA[proxemics]]></inlineChoice><inlineChoice identifier=\"RESP_4\"><![CDATA[territoriality]]></inlineChoice><inlineChoice identifier=\"RESP_5\"><![CDATA[kinesics]]></inlineChoice></inlineChoiceInteraction></p></blockquote><blockquote><p><![CDATA[nonverbal cues that have specific, generally understood meanings in a given culture]]><inlineChoiceInteraction responseIdentifier=\"RESPONSE_2\" shuffle=\"true\"><inlineChoice identifier=\"RESP_1\"><![CDATA[interactional synchrony]]></inlineChoice><inlineChoice identifier=\"RESP_2\"><![CDATA[emblems]]></inlineChoice><inlineChoice identifier=\"RESP_3\"><![CDATA[proxemics]]></inlineChoice><inlineChoice identifier=\"RESP_4\"><![CDATA[territoriality]]></inlineChoice><inlineChoice identifier=\"RESP_5\"><![CDATA[kinesics]]></inlineChoice></inlineChoiceInteraction></p></blockquote><blockquote><p><![CDATA[study of how close or far away from people and objects people position themselves]]><inlineChoiceInteraction responseIdentifier=\"RESPONSE_3\" shuffle=\"true\"><inlineChoice identifier=\"RESP_1\"><![CDATA[interactional synchrony]]></inlineChoice><inlineChoice identifier=\"RESP_2\"><![CDATA[emblems]]></inlineChoice><inlineChoice identifier=\"RESP_3\"><![CDATA[proxemics]]></inlineChoice><inlineChoice identifier=\"RESP_4\"><![CDATA[territoriality]]></inlineChoice><inlineChoice identifier=\"RESP_5\"><![CDATA[kinesics]]></inlineChoice></inlineChoiceInteraction></p></blockquote><blockquote><p><![CDATA[how animals and humans use space and objects to communicate occupancy or ownership of space]]><inlineChoiceInteraction responseIdentifier=\"RESPONSE_4\" shuffle=\"true\"><inlineChoice identifier=\"RESP_1\"><![CDATA[interactional synchrony]]></inlineChoice><inlineChoice identifier=\"RESP_2\"><![CDATA[emblems]]></inlineChoice><inlineChoice identifier=\"RESP_3\"><![CDATA[proxemics]]></inlineChoice><inlineChoice identifier=\"RESP_4\"><![CDATA[territoriality]]></inlineChoice><inlineChoice identifier=\"RESP_5\"><![CDATA[kinesics]]></inlineChoice></inlineChoiceInteraction></p></blockquote><blockquote><p><![CDATA[study of human movement and gesture]]><inlineChoiceInteraction responseIdentifier=\"RESPONSE_5\" shuffle=\"true\"><inlineChoice identifier=\"RESP_1\"><![CDATA[interactional synchrony]]></inlineChoice><inlineChoice identifier=\"RESP_2\"><![CDATA[emblems]]></inlineChoice><inlineChoice identifier=\"RESP_3\"><![CDATA[proxemics]]></inlineChoice><inlineChoice identifier=\"RESP_4\"><![CDATA[territoriality]]></inlineChoice><inlineChoice identifier=\"RESP_5\"><![CDATA[kinesics]]></inlineChoice></inlineChoiceInteraction></p></blockquote></itemBody><responseProcessing><responseCondition><responseIf><isNull><variable identifier=\"RESPONSE_1\" /></isNull><setOutcomeValue identifier=\"SCORE\"><mapResponse identifier=\"RESPONSE_1\" /></setOutcomeValue></responseIf><responseElse><setOutcomeValue identifier=\"ITEMSCORE\"><mapResponse identifier=\"RESPONSE_1\" /></setOutcomeValue><setOutcomeValue identifier=\"SCORE\"><mapResponse identifier=\"RESPONSE_1\" /></setOutcomeValue><responseCondition><responseIf><gt><variable identifier=\"ITEMSCORE\" /><baseValue baseType=\"float\">0</baseValue></gt><setOutcomeValue identifier=\"FEEDBACK-1\"><baseValue baseType=\"identifier\">FEEDBACK-0</baseValue></setOutcomeValue></responseIf><responseElse><setOutcomeValue identifier=\"FEEDBACK-1\"><baseValue baseType=\"identifier\">FEEDBACK-1</baseValue></setOutcomeValue></responseElse></responseCondition></responseElse></responseCondition><responseCondition><responseIf><isNull><variable identifier=\"RESPONSE_2\" /></isNull><setOutcomeValue identifier=\"SCORE\"><sum><variable identifier=\"SCORE\" /><mapResponse identifier=\"RESPONSE_2\" /></sum></setOutcomeValue></responseIf><responseElse><setOutcomeValue identifier=\"ITEMSCORE\"><mapResponse identifier=\"RESPONSE_2\" /></setOutcomeValue><setOutcomeValue identifier=\"SCORE\"><sum><variable identifier=\"SCORE\" /><mapResponse identifier=\"RESPONSE_2\" /></sum></setOutcomeValue><responseCondition><responseIf><gt><variable identifier=\"ITEMSCORE\" /><baseValue baseType=\"float\">0</baseValue></gt><setOutcomeValue identifier=\"FEEDBACK-2\"><baseValue baseType=\"identifier\">FEEDBACK-2</baseValue></setOutcomeValue></responseIf><responseElse><setOutcomeValue identifier=\"FEEDBACK-2\"><baseValue baseType=\"identifier\">FEEDBACK-3</baseValue></setOutcomeValue></responseElse></responseCondition></responseElse></responseCondition><responseCondition><responseIf><isNull><variable identifier=\"RESPONSE_3\" /></isNull><setOutcomeValue identifier=\"SCORE\"><sum><variable identifier=\"SCORE\" /><mapResponse identifier=\"RESPONSE_3\" /></sum></setOutcomeValue></responseIf><responseElse><setOutcomeValue identifier=\"ITEMSCORE\"><mapResponse identifier=\"RESPONSE_3\" /></setOutcomeValue><setOutcomeValue identifier=\"SCORE\"><sum><variable identifier=\"SCORE\" /><mapResponse identifier=\"RESPONSE_3\" /></sum></setOutcomeValue><responseCondition><responseIf><gt><variable identifier=\"ITEMSCORE\" /><baseValue baseType=\"float\">0</baseValue></gt><setOutcomeValue identifier=\"FEEDBACK-3\"><baseValue baseType=\"identifier\">FEEDBACK-4</baseValue></setOutcomeValue></responseIf><responseElse><setOutcomeValue identifier=\"FEEDBACK-3\"><baseValue baseType=\"identifier\">FEEDBACK-5</baseValue></setOutcomeValue></responseElse></responseCondition></responseElse></responseCondition><responseCondition><responseIf><isNull><variable identifier=\"RESPONSE_4\" /></isNull><setOutcomeValue identifier=\"SCORE\"><sum><variable identifier=\"SCORE\" /><mapResponse identifier=\"RESPONSE_4\" /></sum></setOutcomeValue></responseIf><responseElse><setOutcomeValue identifier=\"ITEMSCORE\"><mapResponse identifier=\"RESPONSE_4\" /></setOutcomeValue><setOutcomeValue identifier=\"SCORE\"><sum><variable identifier=\"SCORE\" /><mapResponse identifier=\"RESPONSE_4\" /></sum></setOutcomeValue><responseCondition><responseIf><gt><variable identifier=\"ITEMSCORE\" /><baseValue baseType=\"float\">0</baseValue></gt><setOutcomeValue identifier=\"FEEDBACK-4\"><baseValue baseType=\"identifier\">FEEDBACK-6</baseValue></setOutcomeValue></responseIf><responseElse><setOutcomeValue identifier=\"FEEDBACK-4\"><baseValue baseType=\"identifier\">FEEDBACK-7</baseValue></setOutcomeValue></responseElse></responseCondition></responseElse></responseCondition><responseCondition><responseIf><isNull><variable identifier=\"RESPONSE_5\" /></isNull><setOutcomeValue identifier=\"SCORE\"><sum><variable identifier=\"SCORE\" /><mapResponse identifier=\"RESPONSE_5\" /></sum></setOutcomeValue></responseIf><responseElse><setOutcomeValue identifier=\"ITEMSCORE\"><mapResponse identifier=\"RESPONSE_5\" /></setOutcomeValue><setOutcomeValue identifier=\"SCORE\"><sum><variable identifier=\"SCORE\" /><mapResponse identifier=\"RESPONSE_5\" /></sum></setOutcomeValue><responseCondition><responseIf><gt><variable identifier=\"ITEMSCORE\" /><baseValue baseType=\"float\">0</baseValue></gt><setOutcomeValue identifier=\"FEEDBACK-5\"><baseValue baseType=\"identifier\">FEEDBACK-8</baseValue></setOutcomeValue></responseIf><responseElse><setOutcomeValue identifier=\"FEEDBACK-5\"><baseValue baseType=\"identifier\">FEEDBACK-9</baseValue></setOutcomeValue></responseElse></responseCondition></responseElse></responseCondition><responseCondition><responseIf><and><isNull><variable identifier=\"RESPONSE_1\" /></isNull><isNull><variable identifier=\"RESPONSE_2\" /></isNull><isNull><variable identifier=\"RESPONSE_3\" /></isNull><isNull><variable identifier=\"RESPONSE_4\" /></isNull><isNull><variable identifier=\"RESPONSE_5\" /></isNull></and><setOutcomeValue identifier=\"SCORE\"><baseValue baseType=\"float\">0.0</baseValue></setOutcomeValue></responseIf></responseCondition></responseProcessing></assessmentItem>";
	}
	
	private String generateFakeHorizontalOrientation() {
		return "<?xml version=\"1.0\" encoding=\"utf-8\"?><assessmentItem xmlns=\"http://www.imsglobal.org/xsd/imsqti_v2p1\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"http://www.imsglobal.org/xsd/imsqti_v2p1 http://www.imsglobal.org/xsd/qti/qtiv2p1/imsqti_v2p1.xsd\" title=\"03-1-13\" identifier=\"Identifier\" label=\"03-1-13\" toolName=\"pegasus\" toolVersion=\"toolversion\" adaptive=\"false\" timeDependent=\"false\"><responseDeclaration identifier=\"RESPONSE\" cardinality=\"single\" baseType=\"identifier\" /><outcomeDeclaration identifier=\"FEEDBACK\" cardinality=\"single\" baseType=\"identifier\" /><outcomeDeclaration identifier=\"ITEMSCORE\" cardinality=\"single\" baseType=\"float\" /><outcomeDeclaration identifier=\"SCORE\" cardinality=\"single\" baseType=\"float\" normalMaximum=\"1\"><defaultValue><value>0</value></defaultValue></outcomeDeclaration><outcomeDeclaration identifier=\"MAXSCORE\" cardinality=\"single\" baseType=\"float\"><defaultValue><value>1</value></defaultValue></outcomeDeclaration><itemBody><p><![CDATA[Which process of perceptual organization and interpretation is being used when we use information we think we know about a person to make assumptions about things we don&rsquo;t know about the person?]]></p><choiceInteraction shuffle=\"true\" orientation=\"Horizontal\" responseIdentifier=\"RESPONSE\" maxChoices=\"1\" minChoices=\"1\"><simpleChoice identifier=\"RESPONSE_1\" fixed=\"false\"><![CDATA[impression formation]]></simpleChoice><simpleChoice identifier=\"RESPONSE_2\" fixed=\"false\"><![CDATA[implicit personality theory]]></simpleChoice><simpleChoice identifier=\"RESPONSE_3\" fixed=\"false\"><![CDATA[causal attribution theory]]></simpleChoice><simpleChoice identifier=\"RESPONSE_4\" fixed=\"false\"><![CDATA[correspondence inference theory]]></simpleChoice></choiceInteraction></itemBody><responseProcessing><responseCondition><responseIf><match><variable identifier=\"RESPONSE\" /><baseValue baseType=\"identifier\">RESPONSE_1</baseValue></match><setOutcomeValue identifier=\"SCORE\"><baseValue baseType=\"float\">0</baseValue></setOutcomeValue><setOutcomeValue identifier=\"FEEDBACK\"><baseValue baseType=\"identifier\">FEEDBACK_1</baseValue></setOutcomeValue></responseIf><responseElseIf><match><variable identifier=\"RESPONSE\" /><baseValue baseType=\"identifier\">RESPONSE_2</baseValue></match><setOutcomeValue identifier=\"SCORE\"><baseValue baseType=\"float\">1</baseValue></setOutcomeValue><setOutcomeValue identifier=\"FEEDBACK\"><baseValue baseType=\"identifier\">FEEDBACK_2</baseValue></setOutcomeValue></responseElseIf><responseElseIf><match><variable identifier=\"RESPONSE\" /><baseValue baseType=\"identifier\">RESPONSE_3</baseValue></match><setOutcomeValue identifier=\"SCORE\"><baseValue baseType=\"float\">0</baseValue></setOutcomeValue><setOutcomeValue identifier=\"FEEDBACK\"><baseValue baseType=\"identifier\">FEEDBACK_3</baseValue></setOutcomeValue></responseElseIf><responseElseIf><match><variable identifier=\"RESPONSE\" /><baseValue baseType=\"identifier\">RESPONSE_4</baseValue></match><setOutcomeValue identifier=\"SCORE\"><baseValue baseType=\"float\">0</baseValue></setOutcomeValue><setOutcomeValue identifier=\"FEEDBACK\"><baseValue baseType=\"identifier\">FEEDBACK_4</baseValue></setOutcomeValue></responseElseIf></responseCondition></responseProcessing></assessmentItem>";
	}

	private UserSettings generateFakeUserSettings() {
		PrintSettings printSettings = new PrintSettings();
		
		printSettings.setBottomMargin("1.2");
		printSettings.setFont("Arial");
		printSettings.setFontSize("12");
		printSettings.setHeaderSpace("1.2");
		printSettings.setFooterSpace("1.2");
		printSettings.setIncludeStudentName(true);
		printSettings.setIncludeAreaForStudentResponse(AnswerAreas.BETWEENQUESTIONS);
		
		UserSettings userSettings = new UserSettings();
		userSettings.setPrintSettings(printSettings);
		return userSettings;
	}
	
	private UserSettings generateFakeUserSettingsForAnsSameFile(){
		PrintSettings printSettings = new PrintSettings();
		
		printSettings.setBottomMargin("1.2");
		printSettings.setFont("Arial");
		printSettings.setFontSize("12");
		printSettings.setHeaderSpace("1.2");
		printSettings.setFooterSpace("1.2");
		printSettings.setIncludeStudentName(true);
		printSettings.setIncludeAnswerKeyIn(AnswerKeys.SAMEFILE);
		printSettings.setPageNumberDisplay(PageNumberDisplay.BOTTOMMIDDLE);
		
		UserSettings userSettings = new UserSettings();
		userSettings.setPrintSettings(printSettings);
		return userSettings;
	}

	private UserSettings generateFakeUserSettingsForSeperateFile(){
		PrintSettings printSettings = new PrintSettings();
		
		printSettings.setBottomMargin("1.2");
		printSettings.setFont("Arial");
		printSettings.setFontSize("12");
		printSettings.setHeaderSpace("1.2");
		printSettings.setFooterSpace("1.2");
		printSettings.setIncludeStudentName(true);
		printSettings.setIncludeAnswerKeyIn(AnswerKeys.SEPARATEFILE);
		
		UserSettings userSettings = new UserSettings();
		userSettings.setPrintSettings(printSettings);
		return userSettings;
	}
	
	private PrintSettings generateFakePrintSettings() {
		PrintSettings printSettings = new PrintSettings();
		printSettings.setBottomMargin("1.2");
		printSettings.setFont("Arial");
		printSettings.setHeaderSpace("fake Heaser space");
		printSettings.setFooterSpace("fale Footer space");

		return printSettings;
	}

	private DownloadInfo generateFakeDownloadInfo() {
		DownloadInfo downloadInfo = new DownloadInfo();
		return downloadInfo;
	}

	@Test
	public void testDownload() throws Exception {

		when(testRepo.getTestByID(anyString())).thenReturn(fakeTestDetail);

		when(fakeQuestionRepo.getQuestionXmlById(anyString())).thenReturn(
				fakeQTIXML);

		when(userSettingsDelegate.getUserSettings(anyString())).thenReturn(
				fakeUserSettings);

		when(userSettings.getPrintSettings()).thenReturn(fakePrintSettings);
		when(download.download(eq(stream), any(DownloadInfo.class)))
				.thenReturn(fakeDownloadOutput);
		

		downloadService.downloadTest(stream,
				"testid", anyString(), DownloadFormat.pdf , AnswerKeys.NONE,
				AnswerAreas.NONE, false, false, false, "1",
				PageNumberDisplay.TOPRIGHT);

		Assert.assertTrue(((ByteArrayOutputStream)stream).toByteArray().length > 0);

	}
	
	@Test(expected = ExpectationException.class)
	public void testDownloadWithExpectedException() throws Exception {

		when(testRepo.getTestByID(anyString())).thenReturn(fakeTestDetail);

		when(fakeQuestionRepo.getQuestionXmlById(anyString())).thenReturn(
				fakeQTIXML);

		when(userSettingsDelegate.getUserSettings(anyString())).thenReturn(
				fakeUserSettings);

		when(userSettings.getPrintSettings()).thenReturn(fakePrintSettings);
		
		when(download.download(eq(stream), any(DownloadInfo.class)))
				.thenReturn(fakeDownloadOutput);

		when(testVersionDelegate.getTestVersions(anyString())).thenReturn(
				testVersions);

		when(metadataDelegate.getMetadata(anyString()))
				.thenReturn(metadata);
		
		when(metadataService.getMetadata("c01a0fdc-dd52-4035-ae3b-b7cebc6f771c")).thenReturn(
				null);	

		when(archiveRepo.getTestFolder(anyString())).thenReturn(archivedFolder);
		
		DownloadOutput downloadOutput = downloadService.downloadTest(stream,
				"testid", anyString(), DownloadFormat.pdf, AnswerKeys.NONE,
				AnswerAreas.NONE, true, false, false, "1",
				PageNumberDisplay.TOPRIGHT);


	}
	
	@Test(expected = Exception.class)
	public void testDownloadWithException() throws Exception {

		when(testRepo.getTestByID(anyString())).thenReturn(fakeTestDetail);

		when(fakeQuestionRepo.getQuestionXmlById(anyString())).thenReturn(
				fakeQTIXML);

		when(userSettingsDelegate.getUserSettings(anyString())).thenReturn(
				fakeUserSettings);

		when(userSettings.getPrintSettings()).thenReturn(fakePrintSettings);
		
		when(download.download(eq(stream), any(DownloadInfo.class)))
				.thenReturn(fakeDownloadOutput);

		when(testVersionDelegate.getTestVersions(anyString())).thenReturn(
				null);

		when(metadataDelegate.getMetadata(anyString()))
				.thenReturn(metadata);
		
		when(metadataService.getMetadata("c01a0fdc-dd52-4035-ae3b-b7cebc6f771c")).thenReturn(
				null);	

		when(archiveRepo.getTestFolder(anyString())).thenReturn(archivedFolder);
		
		DownloadOutput downloadOutput = downloadService.downloadTest(stream,
				"testid", anyString(), DownloadFormat.pdf, AnswerKeys.NONE,
				AnswerAreas.NONE, true, false, false, "1",
				PageNumberDisplay.TOPRIGHT);


	}
	
	@Test
	public void testDownloadWithSpyDocument() throws Exception {


		when(testRepo.getTestByID(anyString())).thenReturn(fakeTestDetail);

		when(fakeQuestionRepo.getQuestionXmlById(anyString())).thenReturn(
				fakeQTIXML);

		when(userSettingsDelegate.getUserSettings(anyString())).thenReturn(
				fakeUserSettings);

		when(userSettings.getPrintSettings()).thenReturn(fakePrintSettings);


		downloadService.downloadTest(stream,
				"testid", anyString(), DownloadFormat.pdf, AnswerKeys.NONE,
				AnswerAreas.NONE, false, false, false, "1",
				PageNumberDisplay.TOPRIGHT);

		Assert.assertTrue(((ByteArrayOutputStream)stream).toByteArray().length > 0);

	}
	
	@Test
	public void testDownloadForAnsInSameFile() throws Exception {

		when(testRepo.getTestByID(anyString())).thenReturn(fakeTestDetail);

		when(fakeQuestionRepo.getQuestionXmlById(anyString())).thenReturn(
				fakeQTIXML);

		when(userSettingsDelegate.getUserSettings(anyString())).thenReturn(
				fakeUserSettingsForAnsSameFile);

		when(userSettings.getPrintSettings()).thenReturn(fakePrintSettings);

		downloadService.downloadTest(stream,
				"testid", anyString(), DownloadFormat.pdf, AnswerKeys.SAMEFILE,
				AnswerAreas.NONE, false, true, true, "1",
				PageNumberDisplay.TOPRIGHT);

		Assert.assertTrue(((ByteArrayOutputStream)stream).toByteArray().length > 0);

	}
	
	@Test
	public void testDownloadForAnsInSeperateFile() throws Exception {


		when(testRepo.getTestByID(anyString())).thenReturn(fakeTestDetail);

		when(fakeQuestionRepo.getQuestionXmlById(anyString())).thenReturn(
				fakeQTIXML);

		when(userSettingsDelegate.getUserSettings(anyString())).thenReturn(
				fakeUserSettingsForAnsSeperateFile);

		when(userSettings.getPrintSettings()).thenReturn(fakePrintSettings);

		downloadService.downloadTest(stream,
				"testid", anyString(), DownloadFormat.pdf, AnswerKeys.SEPARATEFILE,
				AnswerAreas.NONE, false, false, true, "1",
				PageNumberDisplay.TOPRIGHT);

		Assert.assertTrue(((ByteArrayOutputStream)stream).toByteArray().length > 0);

	}
	
	@Test
	public void testDownloadForEssayQuestion() throws Exception {


		when(testRepo.getTestByID(anyString())).thenReturn(fakeTestDetail);

		when(fakeQuestionRepo.getQuestionXmlById(anyString())).thenReturn(
				fakeQTIXMLForEssay);

		when(userSettingsDelegate.getUserSettings(anyString())).thenReturn(
				fakeUserSettingsForAnsSeperateFile);

		when(userSettings.getPrintSettings()).thenReturn(fakePrintSettings);

		downloadService.downloadTest(stream,
				"testid", anyString(), DownloadFormat.pdf, AnswerKeys.NONE,
				AnswerAreas.NONE, false, false, true, "1",
				PageNumberDisplay.TOPRIGHT);

		Assert.assertTrue(((ByteArrayOutputStream)stream).toByteArray().length > 0);

	}
	
	@Test
	public void testDownloadForMatchQuestion() throws Exception {

		when(testRepo.getTestByID(anyString())).thenReturn(fakeTestDetail);

		when(fakeQuestionRepo.getQuestionXmlById(anyString())).thenReturn(
				fakeQTIXMLForMatching);

		when(userSettingsDelegate.getUserSettings(anyString())).thenReturn(
				fakeUserSettingsForAnsSeperateFile);

		when(userSettings.getPrintSettings()).thenReturn(fakePrintSettings);

		downloadService.downloadTest(stream,
				"testid", anyString(), DownloadFormat.pdf, AnswerKeys.NONE,
				AnswerAreas.NONE, false, false, true, "1",
				PageNumberDisplay.BOTTOMMIDDLE);

		Assert.assertTrue(((ByteArrayOutputStream)stream).toByteArray().length > 0);

	}
	
	@Test
	public void testDownloadForLastPageAnswerArea() throws Exception {

		when(testRepo.getTestByID(anyString())).thenReturn(fakeTestDetail);

		when(fakeQuestionRepo.getQuestionXmlById(anyString())).thenReturn(
				fakeQTIXMLForMatching);

		when(userSettingsDelegate.getUserSettings(anyString())).thenReturn(
				fakeUserSettingsForAnsSeperateFile);

		when(userSettings.getPrintSettings()).thenReturn(fakePrintSettings);

		downloadService.downloadTest(stream,
				"testid", anyString(), DownloadFormat.pdf, AnswerKeys.NONE,
				AnswerAreas.LASTPAGE, false, false, true, "1",
				PageNumberDisplay.BOTTOMMIDDLE);

		Assert.assertTrue(((ByteArrayOutputStream)stream).toByteArray().length > 0);

	}
	
	@Test
	public void testDownloadForLeftSideAnswerArea() throws Exception {

		when(testRepo.getTestByID(anyString())).thenReturn(fakeTestDetail);

		when(fakeQuestionRepo.getQuestionXmlById(anyString())).thenReturn(
				fakeQTIXMLForMatching);

		when(userSettingsDelegate.getUserSettings(anyString())).thenReturn(
				fakeUserSettingsForAnsSeperateFile);

		when(userSettings.getPrintSettings()).thenReturn(fakePrintSettings);

		downloadService.downloadTest(stream,
				"testid", anyString(), DownloadFormat.pdf, AnswerKeys.NONE,
				AnswerAreas.LEFTSIDE, false, false, true, "1",
				PageNumberDisplay.BOTTOMMIDDLE);

		Assert.assertTrue(((ByteArrayOutputStream)stream).toByteArray().length > 0);

	}
	
	@Test
	public void testDownloadForLeftSideAnswerAreaWithMCQuest() throws Exception {

		when(testRepo.getTestByID(anyString())).thenReturn(fakeTestDetail);

		when(fakeQuestionRepo.getQuestionXmlById(anyString())).thenReturn(
				fakeQTIXMLForHorizontalOrien);

		when(userSettingsDelegate.getUserSettings(anyString())).thenReturn(
				fakeUserSettingsForAnsSeperateFile);

		when(userSettings.getPrintSettings()).thenReturn(fakePrintSettings);

		downloadService.downloadTest(stream,
				"testid", anyString(), DownloadFormat.pdf, AnswerKeys.NONE,
				AnswerAreas.LEFTSIDE, false, false, true, "1",
				PageNumberDisplay.BOTTOMMIDDLE);

		Assert.assertTrue(((ByteArrayOutputStream)stream).toByteArray().length > 0);

	}
	
	@Test
	public void testDownloadIncludeRandomizedTests() throws Exception {

		when(testRepo.getTestByID(anyString())).thenReturn(fakeTestDetail);

		when(fakeQuestionRepo.getQuestionXmlById(anyString())).thenReturn(
				fakeQTIXML);

		when(userSettingsDelegate.getUserSettings(anyString())).thenReturn(
				fakeUserSettings);

		when(userSettings.getPrintSettings()).thenReturn(fakePrintSettings);
		
		when(download.download(eq(stream), any(DownloadInfo.class)))
				.thenReturn(fakeDownloadOutput);

		when(testVersionDelegate.getTestVersions(anyString())).thenReturn(
				testVersions);

		when(metadataDelegate.getMetadata(anyString()))
				.thenReturn(metadata);
		
		when(metadataService.getMetadata("c01a0fdc-dd52-4035-ae3b-b7cebc6f771c")).thenReturn(
				metadata);	

		when(archiveRepo.getTestFolder(anyString())).thenReturn(archivedFolder);
		
		DownloadOutput downloadOutput = downloadService.downloadTest(stream,
				"testid", anyString(), DownloadFormat.pdf, AnswerKeys.NONE,
				AnswerAreas.NONE, true, false, false, "1",
				PageNumberDisplay.TOPRIGHT);

		Assert.assertEquals(downloadOutput.getFileName(), fakeDownloadOutputZip.getFileName());
		Assert.assertEquals(downloadOutput.getContentType(), fakeDownloadOutputZip.getContentType());
	}
	
	@Test
	public void testDownloadBBPoolManager() throws Exception {

		when(testRepo.getTestByID(anyString())).thenReturn(fakeTestDetail);

		when(fakeQuestionRepo.getQuestionXmlById(anyString())).thenReturn(
				fakeQTIXML);

		when(userSettingsDelegate.getUserSettings(anyString())).thenReturn(
				fakeUserSettings);

		when(userSettings.getPrintSettings()).thenReturn(fakePrintSettings);
		when(download.download(eq(stream), any(DownloadInfo.class)))
				.thenReturn(fakeDownloadOutput);

		DownloadOutput downloadOutput=downloadService.downloadTest(stream,
				"testid", anyString(), DownloadFormat.bbpm , AnswerKeys.NONE,
				AnswerAreas.NONE, false, false, false, "1",
				PageNumberDisplay.TOPRIGHT);

		Assert.assertTrue(downloadOutput.getFileName().indexOf(fakeDownloadOutputZip.getFileName().replace(".zip", "") +" BBpoolmgr")>-1);
		Assert.assertEquals(downloadOutput.getContentType(), fakeDownloadOutputZip.getContentType());

	}
	
	@Test
	public void testDownloadBBTestManager() throws Exception {

		when(testRepo.getTestByID(anyString())).thenReturn(fakeTestDetail);

		when(fakeQuestionRepo.getQuestionXmlById(anyString())).thenReturn(
				fakeQTIXML);

		when(userSettingsDelegate.getUserSettings(anyString())).thenReturn(
				fakeUserSettings);

		when(userSettings.getPrintSettings()).thenReturn(fakePrintSettings);
		when(download.download(eq(stream), any(DownloadInfo.class)))
				.thenReturn(fakeDownloadOutput);

		DownloadOutput downloadOutput=downloadService.downloadTest(stream,
				"testid", anyString(), DownloadFormat.bbtm , AnswerKeys.NONE,
				AnswerAreas.NONE, false, false, false, "1",
				PageNumberDisplay.TOPRIGHT);

		Assert.assertTrue(downloadOutput.getFileName().indexOf(fakeDownloadOutputZip.getFileName().replace(".zip", "") +" BBtestmgr")>-1);
		Assert.assertEquals(downloadOutput.getContentType(), fakeDownloadOutputZip.getContentType());

	}
	
	@Test
	public void testDownloadQTI2p1() throws Exception {

		when(testRepo.getTestByID(anyString())).thenReturn(fakeTestDetail);

		when(fakeQuestionRepo.getQuestionXmlById(anyString())).thenReturn(
				fakeQTIXML);

		when(userSettingsDelegate.getUserSettings(anyString())).thenReturn(
				fakeUserSettings);

		when(userSettings.getPrintSettings()).thenReturn(fakePrintSettings);
		when(download.download(eq(stream), any(DownloadInfo.class)))
				.thenReturn(fakeDownloadOutput);

		DownloadOutput downloadOutput=downloadService.downloadTest(stream,
				"testid", anyString(), DownloadFormat.qti21 , AnswerKeys.NONE,
				AnswerAreas.NONE, false, false, false, "1",
				PageNumberDisplay.TOPRIGHT);

		Assert.assertTrue(downloadOutput.getFileName().indexOf(fakeDownloadOutputZip.getFileName().replace(".zip", "") +" QTImgr")>-1);
		Assert.assertEquals(downloadOutput.getContentType(), fakeDownloadOutputZip.getContentType());

	}
}
