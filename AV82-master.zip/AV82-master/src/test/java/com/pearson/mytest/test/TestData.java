package com.pearson.mytest.test;



public class TestData {		
	
	public class UserToken
	{
		public static final String username = "mytestnextgen_user1";
		public static final String password = "P@ssword1";
		
	}
	
	public class QuestionsController 
	{
		public static final String bookId = "13ecac68-4460-4571-9cd5-f55014d8db2d";
		public static final String nodeId = "f2abe703-3e35-4be4-9cff-433a914fe1f3";
		public static final String questionId = "c6eb3ca2-b083-45e7-8f6e-89caa89dc094";
		
		
	}
	public class BookController 
	{  
		public static final String bookId = "de6dff18-0c7c-4b4b-b10e-74c1b1a56aea";	
		
	}
	
	public class ContainerController
	{
		public static final String bookId = "de6dff18-0c7c-4b4b-b10e-74c1b1a56aea";
		public static final String bookTitle ="Wave 4 -  MASTER, MyTest for  Zarefsky Public Speaking 7e (01/16/13)_5";
		public static final String publisher ="Prentice Hall";
		public static final String author = "David";
		
	}
	public class MyTestController
	{
		 public static final String testId = "473f0dde-e432-43ea-8835-90dfe82dc940";
	}
	public class TestController
	{
		 public static final String testId = "c47f43e0-63e6-4b42-98e0-6781837fb7d9";
		 public static final String bookId = "4d865d70-e4a2-4334-a7d4-08b4f5fcd401";
	}
	public class TestDownloadController
	{
		 public static final String testId = "b451df8d-4aaf-4953-83f6-81d73b320d62";
		 public static final String testIdAllTypeOfQuestions = "9f29513d-8b71-4661-b3e3-fa305e496bdf";
	}
	
	public class ArchiveController
	{
		public static final String folderId ="0f9fce0e-28de-4116-a2b2-7864ff708f21";
		public static final String TestId = "01890e57-d64d-425d-bb69-ee127b84e607";
		public static final String archivedFolderId = "bc85bd34-799a-450b-aac7-589a6edfc71b";	
		
	}
	
	public class UserFolderController
	{
		public static final String rootFolderTitle ="JUnit test case root fodler";
		public static final String folderTitle ="JUnit test case fodler";		
		public static final String sequence ="1";
		public static final String parentId ="b6ab2013-4e49-463b-b66a-0d28cfe4ab30";
	
		
	}
	


}
