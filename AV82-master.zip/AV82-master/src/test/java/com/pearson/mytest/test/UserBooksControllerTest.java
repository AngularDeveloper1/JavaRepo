package com.pearson.mytest.test;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.pearson.mytest.bean.UserBook;
import com.pearson.mytest.controller.UserBooksController;
import com.pearson.mytest.proxy.mytest.repo.UserBookRepo;
import com.pearson.mytest.util.PIHelper;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "file:src/main/webapp/WEB-INF/appServlet-servlet.xml" })
public class UserBooksControllerTest {

	@Autowired
	UserBooksController userBooksController;

	private MockMvc mockMvc;
	private String token;

	@Before
	public void setUp() throws Exception {
		mockMvc = MockMvcBuilders.standaloneSetup(userBooksController).build();
		String username = TestData.UserToken.username;
		String password = TestData.UserToken.password;
		token = (new PIHelper()).getPIToken(username, password);	
		
		UserBookRepo userBookRepo = new UserBookRepo();

		UserBook userBook = new UserBook();
		userBook.setGuid("ddffgghh");
		userBook.setUserId("ffffffff54b3faa6e4b0f10ebd0747ce");
		userBook.setQuestionBindings(new ArrayList<String>());
		userBook.setTestBindings(new ArrayList<String>());
		userBook.setTitle("title");
		userBook.setIsImported(false);
		
		userBookRepo.saveUserBook(userBook);
	}

	/**
	 * Testing the books root children by book id PassCriteria : should give
	 * http status 200
	 * 
	 * @throws Exception
	 */
	@Test
	public void testGetUserBooks() throws Exception {

		mockMvc.perform(
				get("/my/importbooks").header("x-authorization", token))
				.andExpect(status().isOk());
	}
	
	@Test
	public void testImportUserBooks() throws Exception {
        String userBookIds = "[\"ddffgghh\"]";

		mockMvc.perform(
				post("/my/importbooks").header("x-authorization", token)
						.contentType(MediaType.APPLICATION_JSON)
						.content(userBookIds)).andExpect(status().isOk());
	}	
}
