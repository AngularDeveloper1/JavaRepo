package com.pearson.mytest.test;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;





import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.binary.StringUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.pearson.mytest.util.PIHelper;
import com.pearson.mytest.controller.TestDownloadController;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "file:src/main/webapp/WEB-INF/appServlet-servlet.xml" })
public class TestDownloadControllerTest {

	@Autowired
	TestDownloadController testDownloadController;
	
	private MockMvc mockMvc;
	private String token;
	private String testId;
	private String testIdAllTypeOfQuestions;

	@Before
	public void setUp() throws Exception {
		mockMvc = MockMvcBuilders.standaloneSetup(testDownloadController).build();
		String username = TestData.UserToken.username;
		String password = TestData.UserToken.password;;
		token = (new PIHelper()).getPIToken(username, password);
		testId = TestData.TestDownloadController.testId;
		testIdAllTypeOfQuestions = TestData.TestDownloadController.testIdAllTypeOfQuestions;
		
	}
	
	@Test
	public void testprintTest() throws Exception {
		String data = StringUtils.newStringUtf8(Base64.encodeBase64(("answerKey=NONE$answerArea=NONE$AT=" + token).getBytes()));
		mockMvc.perform(
				get("/tests/"+testId+"/download/doc?data=" + data)
					).andExpect(
				status().isOk());
	}
	
	@Test
	public void testprintTestWithAnswerKey() throws Exception {
		String data = StringUtils.newStringUtf8(Base64.encodeBase64(("answerKey=SAMEFILE$answerArea=NONE$AT=" + token).getBytes()));
		mockMvc.perform(
				get("/tests/"+testId+"/download/doc?data=" + data)
					).andExpect(
				status().isOk());
	}
	
	@Test
	public void testprintAnswerKey() throws Exception {
		String data = StringUtils.newStringUtf8(Base64.encodeBase64(("answerKey=SEPARATEFILE$answerArea=NONE$AT=" + token).getBytes()));
		mockMvc.perform(
				get("/tests/"+testId+"/download/doc?data=" + data)
					).andExpect(
				status().isOk());
	}
	
	@Test
	public void testprintPDF() throws Exception {
		String data = StringUtils.newStringUtf8(Base64.encodeBase64(("answerKey=NONE$answerArea=NONE$AT=" + token).getBytes()));
		mockMvc.perform(
				get("/tests/"+testId+"/download/pdf?data=" + data)
					).andExpect(
				status().isOk());
	}
	
	@Test
	public void testprintPDFWithAnswerKey() throws Exception {
		String data = StringUtils.newStringUtf8(Base64.encodeBase64(("answerKey=SAMEFILE$answerArea=NONE$AT=" + token).getBytes()));
		mockMvc.perform(
				get("/tests/"+testId+"/download/pdf?data=" + data)
					).andExpect(
				status().isOk());
	}
	
	@Test
	public void testprintPDFAnswerKey() throws Exception {
		String data = StringUtils.newStringUtf8(Base64.encodeBase64(("answerKey=SEPARATEFILE$answerArea=NONE$AT=" + token).getBytes()));
		mockMvc.perform(
				get("/tests/"+testId+"/download/pdf?data=" + data)
					).andExpect(
				status().isOk());
	}
	
	@Test
	public void testprintDocIncludeRandomizedTests() throws Exception {
		String data = StringUtils.newStringUtf8(Base64.encodeBase64(("answerKey=NONE$answerArea=NONE$includeRandomizedTests=true$AT=" + token).getBytes()));
		mockMvc.perform(
				get("/tests/"+testId+"/download/doc?data=" + data)
					).andExpect(
				status().isOk());
	}
	
	@Test
	public void testprintDocIncludeStudentName() throws Exception {
		String data = StringUtils.newStringUtf8(Base64.encodeBase64(("answerKey=NONE$answerArea=NONE$includeStudentName=true$AT=" + token).getBytes()));
		mockMvc.perform(
				get("/tests/"+testId+"/download/doc?data=" + data)
					).andExpect(
				status().isOk());
	}
	
	@Test
	public void testprintDocSaveSettings() throws Exception {
		String data = StringUtils.newStringUtf8(Base64.encodeBase64(("answerKey=NONE$answerArea=NONE$saveSettings=true$AT=" + token).getBytes()));
		mockMvc.perform(
				get("/tests/"+testId+"/download/doc?data=" + data)
					).andExpect(
				status().isOk());
	}
	
	@Test
	public void testprintPDFIncludeRandomizedTests() throws Exception {
		String data = StringUtils.newStringUtf8(Base64.encodeBase64(("answerKey=NONE$answerArea=NONE$includeRandomizedTests=true$AT=" + token).getBytes()));
		mockMvc.perform(
				get("/tests/"+testId+"/download/pdf?data=" + data)
					).andExpect(
				status().isOk());
	}
	
	@Test
	public void testprintPDFIncludeStudentName() throws Exception {
		String data = StringUtils.newStringUtf8(Base64.encodeBase64(("answerKey=NONE$answerArea=NONE$includeStudentName=true$AT=" + token).getBytes()));
		mockMvc.perform(
				get("/tests/"+testId+"/download/pdf?data=" + data)
					).andExpect(
				status().isOk());
	}
	
	@Test
	public void testprintPDFSaveSettings() throws Exception {
		String data = StringUtils.newStringUtf8(Base64.encodeBase64(("answerKey=NONE$answerArea=NONE$saveSettings=true$AT=" + token).getBytes()));
		mockMvc.perform(
				get("/tests/"+testId+"/download/pdf?data=" + data)
					).andExpect(
				status().isOk());
	}
	
	@Test
	public void testDownloadBBPoolManager() throws Exception {
		String data = StringUtils.newStringUtf8(Base64.encodeBase64(("answerKey=NONE$answerArea=NONE$AT=" + token).getBytes()));
		mockMvc.perform(
				get("/tests/"+testIdAllTypeOfQuestions+"/download/bbpm?data=" + data)
					).andExpect(
				status().isOk());
	}
	
	@Test
	public void testDownloadBBTestManager() throws Exception {
		String data = StringUtils.newStringUtf8(Base64.encodeBase64(("answerKey=NONE$answerArea=NONE$AT=" + token).getBytes()));
		mockMvc.perform(
				get("/tests/"+testIdAllTypeOfQuestions+"/download/bbtm?data=" + data)
					).andExpect(
				status().isOk());
	}
	
	@Test
	public void testDownloadQTI2p1() throws Exception {
		String data = StringUtils.newStringUtf8(Base64.encodeBase64(("answerKey=NONE$answerArea=NONE$AT=" + token).getBytes()));
		mockMvc.perform(
				get("/tests/"+testIdAllTypeOfQuestions+"/download/qti21?data=" + data)
					).andExpect(
				status().isOk());
	}
	
}
