package com.pearson.mytest.unit.test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;

import static org.mockito.Mockito.*;

import com.pearson.mytest.bean.Book;
import com.pearson.mytest.bean.Container;
import com.pearson.mytest.bean.QuestionEnvelop;
import com.pearson.mytest.bean.QuestionMetadata;
import com.pearson.mytest.bean.QuestionOutput;
import com.pearson.mytest.bean.UserQuestionsFolder;
import com.pearson.mytest.proxy.ContainerDelegate;
import com.pearson.mytest.proxy.QuestionDelegate;
import com.pearson.mytest.proxy.mytest.repo.BookRepo;
import com.pearson.mytest.proxy.mytest.repo.ContainerRepo;
import com.pearson.mytest.service.ContainerService;
import com.pearson.mytest.service.MetadataService;
import com.pearson.mytest.service.QuestionService;
import com.pearson.mytest.service.UserFolderService;
import com.pearson.mytest.util.UserHelper;

@RunWith(MockitoJUnitRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations={"file:src/main/webapp/WEB-INF/appServlet-servlet.xml"})
public class QuestionServiceTest {

	@Mock
	private QuestionDelegate questionRepo;
	
	@Mock
	private ContainerService containerService;
	
	@Mock
	private BookRepo bookRepo;
	
	@Mock
	private ContainerDelegate containerRepo;
	
	@Mock
	private ContainerRepo containerRepos;
	
	@Mock
	private UserFolderService userFolderService;
	
	@InjectMocks
	private QuestionService questionService;
	
	@Mock
	private MetadataService metadataService;
	
	
	
	
	List<QuestionMetadata> emptyQuestionFake;
	List<QuestionMetadata> questionsFake;
	List<Container> containersFake;
	HashMap<String, String> mapFake;
	String questionXMLFake;
	String returnMessageFake;
	List<String> fakeQuestionBindings;
	List<QuestionOutput> questionFake;
	//private final String QuestionGUID=java.util.UUID.randomUUID().toString();
	private final String QuestionGUID="123456";
	
	private final String FAKE_BOOK_ID = "FAKE_BOOK_ID";
	private final String FAKE_CONTAINER_ID = "FAKE_CONTAINER_ID";
	private final String FAKE_QUESTION_ID = "FAKE_QUESTION_ID";
	
	@Before
	public void setUp() throws Exception {
		emptyQuestionFake = new ArrayList<QuestionMetadata>();
		questionsFake =generateFakeQuestions();
		containersFake = new ArrayList<Container>();
		mapFake = new HashMap<String, String>();
		questionXMLFake = "Fake QuestionXML";
		returnMessageFake = "Success";
		fakeQuestionBindings=getFakeQuestionBindings();
		questionFake=FakeObjectHelper.generateQuestionsFake();
	}
	
	
	@Test
	public void testGetQuestionsInThreadedView(){
		when(questionRepo.getQuestions(FAKE_BOOK_ID)).thenReturn(questionsFake);
		when(containerRepo.getQuestionBindings(FAKE_BOOK_ID, FAKE_CONTAINER_ID)).thenReturn(fakeQuestionBindings);
		List<QuestionMetadata> actualQuestions = questionService.getQuestions(FAKE_BOOK_ID, FAKE_CONTAINER_ID, mapFake , false);
		Assert.assertEquals(questionsFake.get(0).getGuid(), actualQuestions.get(0).getGuid());
	}
	
/*	@Test (expected = NotFoundException.class)
	public void testGetQuestionsInFlatViewException(){
		
		when(questionRepo.getQuestions(anyString())).thenReturn(emptyQuestionFake);
		
		when(containerRepo.getQuestionBindings(anyString(), anyString())).thenReturn(fakeQuestionBindings);
		when(containerService.getContainerChildrenById(anyString())).thenReturn(containersFake);
		HashMap<String, String> map = Mockito.any();
		List<QuestionMetadata> actualQuestions = questionService.getQuestions(anyString(), anyString(), map, true);
		Assert.assertEquals(emptyQuestionFake, actualQuestions);
	}
	*/
	@Test
	public void testGetQuestionsInFlatView(){
		when(containerService.getContainerChildrenById(FAKE_CONTAINER_ID)).thenReturn(containersFake);
		when(questionRepo.getQuestions(eq(FAKE_BOOK_ID))).thenReturn(questionsFake);
		when(containerRepo.getQuestionBindings(anyString(), anyString())).thenReturn(fakeQuestionBindings);
		List<QuestionMetadata> actualQuestions = questionService.getQuestions(FAKE_BOOK_ID, FAKE_CONTAINER_ID, mapFake, true);
		Assert.assertEquals(questionsFake.get(0).getGuid(), actualQuestions.get(0).getGuid());
	}
	
	@Test
	public void testGetQuestionsByID(){
		when(questionRepo.getQuestionXmlById(FAKE_QUESTION_ID)).thenReturn(questionXMLFake);
		String actualQuestionXML = questionService.getQuestionXmlById(FAKE_QUESTION_ID);
		Assert.assertEquals(questionXMLFake, actualQuestionXML);
	}
		
	
	@Test
	public void testGetUserQuestions() {		

		when(userFolderService.getMyQuestionsFolder(UserHelper.getUserId(null))).thenReturn(FakeObjectHelper.generateFakeUserQuestionsFolder());
		when(questionRepo.getQuestionXmlById(anyString())).thenReturn(anyString());
		when(metadataService.getMetadata("FAKE_METADATA_ID")).thenReturn(FakeObjectHelper.generateMetadataFake());

		List<com.pearson.mytest.bean.QuestionOutput> questionsResult = questionService.getUserQuestions(UserHelper.getUserId(null),null);

		Assert.assertEquals(questionsResult.get(0).getGuid(), questionFake.get(0).getGuid());
	}
	
	@Test
	public void testGetUserQuestionsForFolder() {		

		UserQuestionsFolder uqfolder = FakeObjectHelper.generateFakeUserQuestionsFolder();

		when(userFolderService.getMyQuestionsFolder(UserHelper.getUserId(null),uqfolder.getGuid())).thenReturn(FakeObjectHelper.generateFakeUserQuestionsFolder());
		when(questionRepo.getQuestionXmlById(anyString())).thenReturn(anyString());
		when(metadataService.getMetadata("FAKE_METADATA_ID")).thenReturn(FakeObjectHelper.generateMetadataFake());

		List<com.pearson.mytest.bean.QuestionOutput> questionsResult = questionService.getUserQuestions(UserHelper.getUserId(null),uqfolder.getGuid());

		Assert.assertEquals(questionsResult.get(0).getGuid(), questionFake.get(0).getGuid());
	}
	
	@Test
	public void testSaveQuestion(){
		Book fakeBook = new Book();
		Container fakeContainer = new Container();
		when(bookRepo.getBookByID(FAKE_BOOK_ID)).thenReturn(fakeBook);
		when(containerRepos.getContainerById(FAKE_BOOK_ID)).thenReturn(fakeContainer);
		when(questionRepo.saveQuestion(any(QuestionEnvelop.class), anyString(), anyString())).thenReturn(returnMessageFake);
		QuestionEnvelop envelop= new QuestionEnvelop();
		envelop = generateFakeQuestionEnvelop();
		String actual = questionService.saveQuestion(envelop, FAKE_BOOK_ID, FAKE_CONTAINER_ID);
		Assert.assertEquals(returnMessageFake, actual);
	}

	
	@Test
	public void testGetQuestions() {	
		List<String> questionGuid=new ArrayList<String>();
		questionGuid.add("004c7abc-9abf-45a6-b9cd-6df1daeace36");
	
		when(questionRepo.getQuestionXmlById(anyString())).thenReturn(anyString());
		when(metadataService.getMetadata("FAKE_METADATA_ID")).thenReturn(FakeObjectHelper.generateMetadataFake());
		
		List<com.pearson.mytest.bean.QuestionOutput> questionsResult = questionService.getQuestions(questionGuid);
	
		Assert.assertEquals(questionsResult.get(0).getGuid(), FakeObjectHelper.generateQuestionFake().getGuid());
	}
	
	@Test
	public void testGetQuestionsByBookId() {	
		
		when(questionRepo.getQuestions(FAKE_BOOK_ID)).thenReturn(questionsFake);
		
		List<QuestionMetadata> actualQuestions = questionService.getQuestions(FAKE_BOOK_ID);
		Assert.assertEquals(questionsFake.get(0).getGuid(), actualQuestions.get(0).getGuid());
	}
	
	

	private List<QuestionMetadata> generateFakeQuestions(){
		List<QuestionMetadata> questions = new ArrayList<QuestionMetadata>();
		QuestionMetadata question = new QuestionMetadata();
        question.setGuid(QuestionGUID);
		questions.add(question);
		return questions;
	}
	
	private List<String> getFakeQuestionBindings() {
		List<String> fakeQuestionBindings = new ArrayList<String>();
		fakeQuestionBindings.add(QuestionGUID);
		return fakeQuestionBindings;
	}
	
	private QuestionEnvelop generateFakeQuestionEnvelop() {
		QuestionEnvelop envelop= new QuestionEnvelop();
			envelop.setmetadata(FakeObjectHelper.generateMetadataFake());
			return envelop;
	}
	


}