
package com.pearson.mytest.test;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.pearson.mytest.controller.ImageController;
import com.pearson.mytest.util.PIHelper;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations={"file:src/main/webapp/WEB-INF/appServlet-servlet.xml"})

public class ImageControllerTest {
	
	@Autowired
	ImageController ImageController;
	
	private MockMvc mockMvc;
	private String token;
	
	@Before
	public void setUp() throws Exception {
		mockMvc = MockMvcBuilders.standaloneSetup(ImageController).build();
		String username = TestData.UserToken.username;
		String password = TestData.UserToken.password;
		token = (new PIHelper()).getPIToken(username, password);
	}


	@Test
	public void test() throws Exception {	        
	        
	        mockMvc.perform(MockMvcRequestBuilders.fileUpload("/image/upload")
	                .file("file", "Test Content".getBytes())
	                .header("x-authorization", token)
	                .contentType(MediaType.MULTIPART_FORM_DATA)
	                .accept(MediaType.APPLICATION_JSON))	             
	                .andExpect(status().isOk());
		
		
		
		
	}

}
