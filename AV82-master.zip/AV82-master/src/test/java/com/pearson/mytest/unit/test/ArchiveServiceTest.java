package com.pearson.mytest.unit.test;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyListOf;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;

import com.pearson.mytest.bean.ArchivedFolder;
import com.pearson.mytest.bean.Metadata;
import com.pearson.mytest.bean.TestBinding;
import com.pearson.mytest.bean.TestMetadata;
import com.pearson.mytest.bean.UserFolder;
import com.pearson.mytest.proxy.ArchiveDelegate;
import com.pearson.mytest.proxy.MyTestDelegate;
import com.pearson.mytest.proxy.UserFoldersDelegate;
import com.pearson.mytest.service.ArchiveService;
import com.pearson.mytest.service.MetadataService;
import com.pearson.mytest.service.MyTestService;
import com.pearson.mytest.service.TestService;
import com.pearson.mytest.service.UserFolderService;
import com.pearson.mytest.util.UserHelper;

@RunWith(MockitoJUnitRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "file:src/main/webapp/WEB-INF/appServlet-servlet.xml" })
public class ArchiveServiceTest {

	@Mock
	private ArchiveDelegate archiveRepo;

	@Mock
	private MetadataService metadataService;
	
	@Mock
	private UserFolderService userFolderService;
	
	@Mock
	private UserFoldersDelegate userFoldersRepo;

	@Mock
	private MyTestService myTestService;
	
	@Mock
	private TestService testService;
	
	@Mock
	private ArchiveService archiveServiceMock;
	
	@Mock
	private MyTestDelegate myTestsRepo;
	
	@InjectMocks
	ArchiveService archiveService;

	// to hold Fake objects
	List<ArchivedFolder> archivedFoldersFake;
	ArchivedFolder archivedFolderFake;
	TestBinding testBindingFake;
	Metadata metadataFake;
	List<TestMetadata> testMetadataFake;
	List<UserFolder> userFolderWithChildrenFake;
	List<ArchivedFolder> ArchivedFolderWithChildrenFake;
	
	@Before
	public void setUp() throws Exception {

		// prepare fake objects
		archivedFoldersFake = generateFakeArchivedFolders();
		archivedFolderFake = FakeObjectHelper.generateFakeArchivedFolder();
		testBindingFake = generateFakeTestBinding();
		metadataFake = FakeObjectHelper.generateMetadataFake();
		testMetadataFake = FakeObjectHelper.generateFakeTestMetadataList();
		userFolderWithChildrenFake = generateFakeUserFolderWithChildren();
		ArchivedFolderWithChildrenFake = generateFakeArchivedFolderWithChildren();
		
		when(userFoldersRepo.getFolder(anyString())).thenReturn(new UserFolder());
		when(userFoldersRepo.getFolder(anyString())).thenReturn(new UserFolder());
		when(archiveRepo.getFolder(anyString())).thenReturn(new ArchivedFolder());
	}

	@Test
	public void testGetFolders() throws Exception {

		when(archiveRepo.getFolders(anyString(), anyString())).thenReturn(archivedFoldersFake);

		List<ArchivedFolder> archivedFoldersResult = archiveService.getFolders(anyString(), anyString());

		Assert.assertEquals(archivedFoldersFake, archivedFoldersResult);
	}
	/*
	@Test
	public void testGetTests() throws Exception {

		when(archiveRepo.getArchiveRoot(anyString())).thenReturn(archivedFolderFake);
		when(archiveRepo.getFolder(anyString())).thenReturn(archivedFolderFake);
		when(metadataService.getMetadata(anyString())).thenReturn(metadataFake);
		
		List<TestMetadata> result = archiveService.getTests(anyString(), anyString());

		Assert.assertNotNull(result);
	}*/

	@Test
	public void testArchiveFolder() throws Exception {

		UserFolder userFolderFake = FakeObjectHelper.generateFakeUserFolder();
		when (userFoldersRepo.getFolder(anyString())).thenReturn(userFolderFake);
		ArchivedFolder archivedFolderFake = FakeObjectHelper.generateFakeArchivedFolder();
		when (archiveRepo.getFolder(anyString())).thenReturn(archivedFolderFake);
		Mockito.doNothing().when(archiveRepo).archiveFolders(archivedFoldersFake);
		List<TestMetadata> tests = FakeObjectHelper.generateFakeTestMetadataList();
		when(myTestService.getMyFolderTests(any(UserFolder.class))).thenReturn(tests);
		archiveService.archiveFolder("folderId");
	}
	
	@Test
	public void testArchiveFolderWithCondition() throws Exception {

		UserFolder userFolderFake = FakeObjectHelper.generateFakeUserFolder();
		when (userFoldersRepo.getFolder(anyString())).thenReturn(userFolderFake);
		ArchivedFolder archivedFolderFake = FakeObjectHelper.generateFakeArchivedFolder();
		when (archiveRepo.getFolder(anyString())).thenReturn(archivedFolderFake);
		Mockito.doNothing().when(archiveRepo).archiveFolders(archivedFoldersFake);
		List<TestMetadata> tests = FakeObjectHelper.generateFakeTestMetadataList();
		when(myTestService.getMyFolderTests(any(UserFolder.class))).thenReturn(tests);
		when(userFoldersRepo.getChildFolders("folderId")).thenReturn(userFolderWithChildrenFake);
		
		archiveService.archiveFolder("folderId");
	}

	@Test
	public void testArchiveTest() throws Exception {
		UserFolder userFolderFake = FakeObjectHelper.generateFakeUserFolder();
		when (userFoldersRepo.getMyTestRoot(anyString())).thenReturn(userFolderFake);
		when (userFoldersRepo.getFolder(anyString())).thenReturn(userFolderFake);
		Mockito.doNothing().when(userFoldersRepo).saveFolder(any(UserFolder.class));
		Mockito.doNothing().when(archiveRepo).saveFolder(any(ArchivedFolder.class));
		Mockito.doNothing().when(archiveRepo).archiveFolders(anyListOf(ArchivedFolder.class));
		archiveService.archiveTest("userID", "12345", "123456");
	}
	
	@Test
	public void testRestoreFolder() throws Exception {

		ArchivedFolder archivedFolderFake = FakeObjectHelper.generateFakeArchivedFolder();		
		when (archiveRepo.getFolder(anyString())).thenReturn(archivedFolderFake);
		UserFolder userFolderFake = FakeObjectHelper.generateFakeUserFolder();
		when (userFoldersRepo.getFolder(anyString())).thenReturn(userFolderFake);
		Mockito.doNothing().when(userFoldersRepo).saveFolder(userFolderFake);		
		List<TestMetadata> tests = FakeObjectHelper.generateFakeTestMetadataList();
		when(myTestService.getMyFolderTests(any(UserFolder.class))).thenReturn(tests);
		
		archiveService.restoreFolder("folderId");
	}
	
	@Test
	public void testRestoreFolderWithDuplicateName() throws Exception {

		ArchivedFolder archivedFolderFake = FakeObjectHelper.generateFakeArchivedFolder();		
		when (archiveRepo.getFolder(anyString())).thenReturn(archivedFolderFake);
		
		UserFolder userFolderFake = FakeObjectHelper.generateFakeUserFolder();
		when (userFoldersRepo.getFolder(anyString())).thenReturn(userFolderFake);
		Mockito.doNothing().when(userFoldersRepo).saveFolder(userFolderFake);		
		List<TestMetadata> tests = FakeObjectHelper.generateFakeTestMetadataList();
		when(myTestService.getMyFolderTests(any(UserFolder.class))).thenReturn(tests);
		
		when(archiveRepo.getChildFolders("folderId")).thenReturn(ArchivedFolderWithChildrenFake);
		
		archiveService.restoreFolder("folderId");
	}

	@Test
	public void testDeleteFolder() throws Exception {

		ArchivedFolder archivedFolderFake = FakeObjectHelper.generateFakeArchivedFolder();		
		when (archiveRepo.getFolder(anyString())).thenReturn(archivedFolderFake);
		UserFolder userFolderFake = FakeObjectHelper.generateFakeUserFolder();
		when (userFoldersRepo.getFolder(anyString())).thenReturn(userFolderFake);
		Mockito.doNothing().when(userFoldersRepo).saveFolder(userFolderFake);
		Mockito.doNothing().when(myTestsRepo).delete(anyString());		
		List<TestMetadata> tests = FakeObjectHelper.generateFakeTestMetadataList();
		when(myTestService.getMyFolderTests(any(UserFolder.class))).thenReturn(tests);
		archiveService.deleteFolder("folderId");
	}
	
	@Test
	public void testRestoreTest() throws Exception {

		ArchivedFolder archivedFolderFake = FakeObjectHelper.generateFakeArchivedFolder();
		when (archiveRepo.getArchiveRoot(anyString())).thenReturn(archivedFolderFake);
		when (archiveRepo.getFolder(anyString())).thenReturn(archivedFolderFake);
		when (testService.getTestByID(anyString())).thenReturn(FakeObjectHelper.generateTestFake());
		Mockito.doNothing().when(userFoldersRepo).saveFolder(any(UserFolder.class));
		Mockito.doNothing().when(archiveRepo).saveFolder(any(ArchivedFolder.class));
		Mockito.doNothing().when(archiveRepo).archiveFolders(anyListOf(ArchivedFolder.class));
		archiveService.restoreTest("userID", "12345", "123456");
	}

	@Test
	public void testDeleteTest() throws Exception {

		when(archiveRepo.getArchiveRoot(anyString())).thenReturn(archivedFolderFake);
		archiveService.deleteTest(null, "testId", UserHelper.getUserId(null));
	}
	
	private List<ArchivedFolder> generateFakeArchivedFolders() {
		List<ArchivedFolder> archivedFoldersFake = new ArrayList<ArchivedFolder>();

		ArchivedFolder archivedFolder = new ArchivedFolder();
		String guid = "123";
		archivedFolder.setParentId("parentId");
		archivedFolder.setGuid(guid);
		archivedFolder.setSequence(1);
		archivedFolder.setTitle("title");
		archivedFolder.setUserID("userId");
		archivedFoldersFake.add(archivedFolder);

		return archivedFoldersFake;
	}
	
	private List<ArchivedFolder> generateFakeArchivedFolderWithChildren() {
		List<ArchivedFolder> archivedFoldersFake = new ArrayList<ArchivedFolder>();
		String guid=null;
		ArchivedFolder archivedFolder = new ArchivedFolder();
		 guid = "123";
		archivedFolder.setParentId("parentId");
		archivedFolder.setGuid(guid);
		archivedFolder.setSequence(1);
		archivedFolder.setTitle("title");
		archivedFolder.setUserID("userId");
		archivedFoldersFake.add(archivedFolder);
		
		ArchivedFolder archivedFolder1 = new ArchivedFolder();
		 guid = "1234";
		 archivedFolder1.setParentId("123");
		 archivedFolder1.setGuid(guid);
		 archivedFolder1.setSequence(2);
		 archivedFolder1.setTitle("title");
		 archivedFolder1.setUserID("userId");
		archivedFoldersFake.add(archivedFolder1);
		
		ArchivedFolder archivedFolder2 = new ArchivedFolder();
		 guid = "12345";
		 archivedFolder2.setParentId("parentId");
		 archivedFolder2.setGuid(guid);
		 archivedFolder2.setSequence(2);
		 archivedFolder2.setTitle("title");
		 archivedFolder2.setUserID("userId");
		archivedFoldersFake.add(archivedFolder2);


		return archivedFoldersFake;
	}
	
	private List<UserFolder> generateFakeUserFolderWithChildren() {
		List<UserFolder> userfoldersFake = new ArrayList<UserFolder>();
		String guid=null;
		UserFolder userfolder = new UserFolder();
		 guid = "123456";
		 userfolder.setParentId("parentId");
		 userfolder.setGuid(guid);
		 userfolder.setSequence(1);
		 userfolder.setTitle("title");
		 userfolder.setUserID("userId");
		userfoldersFake.add(userfolder);
		
		
		UserFolder userfolder1 = new UserFolder();
		 guid = "12345";
		 userfolder1.setParentId("parentId");
		 userfolder1.setGuid(guid);
		 userfolder1.setSequence(2);
		 userfolder1.setTitle("title");
		 userfolder1.setUserID("userId");
		userfoldersFake.add(userfolder1);


		return userfoldersFake;
	}
	
	
	private TestBinding generateFakeTestBinding() {
		TestBinding testBinding = new TestBinding();
		testBinding.setTestId("123");
		testBinding.setSequence(1.0);
		return testBinding;
	}

}
