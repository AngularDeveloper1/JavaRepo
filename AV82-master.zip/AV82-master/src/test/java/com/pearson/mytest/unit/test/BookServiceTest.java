package com.pearson.mytest.unit.test;

import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;

import com.pearson.mytest.bean.Book;
import com.pearson.mytest.framework.exception.NotFoundException;
import com.pearson.mytest.proxy.BookDelegate;
import com.pearson.mytest.proxy.UserSettingsDelegate;
import com.pearson.mytest.service.BookService;

@RunWith(MockitoJUnitRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "file:src/main/webapp/WEB-INF/appServlet-servlet.xml" })
public class BookServiceTest {

	@Mock
	private BookDelegate bookRepo;
	
	@Mock
	private UserSettingsDelegate userSettingService;

	@InjectMocks
	BookService bookService;

	// to hold Fake objects
	Book bookFake;
	List<Book> bookListFake;
	Map<String, String> searchCriteriaFake;
	List<String> fakeUserBooks;
	private static final String guid = "123456";

	@Before
	public void setUp() throws Exception {

		// prepare fake objects
		bookFake = generateFakeBook();
		bookListFake = generateFakeBookList();
		searchCriteriaFake = generateFakeSearchCriteria();
		fakeUserBooks = generateFakeUserBooks();
		
	}

	@Test
	public void testGetBooksForBooksFound() throws Exception {

		when(bookRepo.getBooks(searchCriteriaFake)).thenReturn(bookListFake);

		List<Book> bookList = bookService.getBooks(searchCriteriaFake,
				anyString());

		Assert.assertEquals(bookListFake, bookList);
	}
	
	@Test
	public void testGetBooksForBooksContainsUserBooks() throws Exception {

		when(bookRepo.getBooks(searchCriteriaFake)).thenReturn(bookListFake);
		when(userSettingService.getUserBooks(anyString())).thenReturn(fakeUserBooks);
		searchCriteriaFake.put("userBooks", "true");

		List<Book> bookList = bookService.getBooks(searchCriteriaFake,anyString());

		Assert.assertEquals(bookListFake, bookList);
	}

	@Test(expected = NotFoundException.class)
	public void testGetBooksForBooksNotFound() throws Exception {

		when(bookRepo.getBooks(searchCriteriaFake)).thenThrow(
				new NotFoundException("Book not found"));
		bookService.getBooks(searchCriteriaFake, anyString());
	}

	@Test
	public void testGetBookByIDForBookFound() throws Exception {

		when(bookRepo.getBookByID(anyString())).thenReturn(bookFake);
		Book bookResult = bookService.getBookByID(anyString());

		Assert.assertEquals(bookFake, bookResult);
	}

	@Test(expected = NotFoundException.class)
	public void testGetBookByIDForBookNotFound() throws Exception {

		when(bookRepo.getBookByID(anyString())).thenThrow(
				new NotFoundException("Book not found"));
		bookService.getBookByID(anyString());
	}

	@Test
	public void testGetDisciplines() throws Exception {
		List<String> disciplines = new ArrayList<String>();
		disciplines.add("discipline");

		when(bookRepo.getDisciplines()).thenReturn(disciplines);

		List<String> disciplineResult = bookService.getDisciplines();
		Assert.assertEquals(disciplines, disciplineResult);
	}

	private Book generateFakeBook() {
		Book bookFake = new Book();

		//String guid = java.util.UUID.randomUUID().toString();
		bookFake.setGuid(guid);
		bookFake.setTitle("title");

		return bookFake;
	}

	private List<Book> generateFakeBookList() {
		Book book = new Book();
		List<Book> bookListFake = new ArrayList<Book>();

		//String guid = java.util.UUID.randomUUID().toString();
		book.setGuid(guid);
		book.setTitle("title");
		bookListFake.add(book);
		return bookListFake;
	}

	private Map<String, String> generateFakeSearchCriteria() {
		//String guid = java.util.UUID.randomUUID().toString();
		Map<String, String> searchCriteria = new HashMap<String, String>();

		searchCriteria.put("guid", guid);
	

		return searchCriteria;
	}
	private List<String> generateFakeUserBooks(){
		List<String> user= new ArrayList<String>();
		user.add(guid);		
		return user;
	}

}
