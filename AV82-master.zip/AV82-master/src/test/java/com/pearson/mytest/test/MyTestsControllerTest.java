package com.pearson.mytest.test;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.google.gson.Gson;
import com.pearson.mytest.bean.TestScrambleType;
import com.pearson.mytest.bean.TestVersionInfo;
import com.pearson.mytest.controller.MyTestsController;
import com.pearson.mytest.framework.exception.InternalException;
import com.pearson.mytest.framework.exception.NotFoundException;
import com.pearson.mytest.proxy.TestVersionDelegate;
import com.pearson.mytest.proxy.paf.repo.MyTestRepo;
import com.pearson.mytest.proxy.paf.repo.TestVersionRepo;
import com.pearson.mytest.util.PIHelper;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations={"file:src/main/webapp/WEB-INF/appServlet-servlet.xml"})
public class MyTestsControllerTest {

	@Autowired
	MyTestsController myTestController;
	
	@Autowired
	@Qualifier("testVersionRepo")
	private TestVersionDelegate testVersionRepo;

	private MockMvc mockMvc;
	private String token;

	@Before
	public void setUp() throws Exception {
		mockMvc = MockMvcBuilders.standaloneSetup(myTestController).build();
		String username = TestData.UserToken.username;
		String password = TestData.UserToken.password;
		token = (new PIHelper()).getPIToken(username, password);
	}

	
	@Test
	public void testSavePaperTest() throws Exception {
		String paperTestEnvelop = "{\"metadata\":{\"quizType\":null,\"title\":\"MyTest activity created from Evalu8 JUnitTest \",\"description\":\"sdfs\",\"subject\":[\"Education\"],\"timeRequired\":null,\"crawlable\":\"true\",\"keywords\":null,\"extendedMetadata\":[{\"name\":\"Dificulty\",\"value\":\"Low\"}],\"versionOf\":null,\"version\":null},\"body\": {\"title\": \"Production mytest activity created from Evalu8\",\"@context\": \"http://purl.org/pearson/paf/v1/ctx/core/StructuredAssignment\",\"@type\": \"StructuredAssignment\",\"assignmentContents\": {\"@contentType\": \"application/vnd.pearson.paf.v1.assignment+json\",\"binding\": [{	\"guid\": \"cba4aeaa-4784-4416-8fc9-e2a02034bc44\",	\"activityFormat\": \"application/vnd.pearson.qti.v2p1.asi+xml\",\"bindingIndex\": 0}]}}}";
		mockMvc.perform(
				post("/my/folders/835078310/tests")
				.header("x-authorization", token)
				.contentType(MediaType.APPLICATION_JSON)
				.content(paperTestEnvelop)).andExpect(
						status().isCreated());
	}
	
	
	@Test
	public void testCreateVersions() throws Exception {
		String testId = TestData.MyTestController.testId;
		TestVersionInfo info = new TestVersionInfo();
		info.setNoOfVersions(1);
		info.setScrambleType(TestScrambleType.BOTH);
		String jsonInfo = (new Gson()).toJson(info);	
		mockMvc.perform(
				post("/my/tests/"+testId+"/versions")
				.header("x-authorization", token)
				.contentType(MediaType.APPLICATION_JSON)
				.content(jsonInfo)).andExpect(
						status().isCreated());
	}

	/**
	 * Getting all tests from root folder
	 * status 200
	 * @throws Exception
	 */
	@Test
	public void testGetMyFolderTests() throws Exception {

		mockMvc.perform(
				get("/my/folders/"+null+"/tests").header("x-authorization", token))
				.andExpect(status().isOk());
	}

	/*@After
	public void cleanUp() throws Exception {
		String testMetadata;
		List<String> activityList = new ArrayList<String>();
		testMetadata = testVersionRepo.getTestVersions("473f0dde-e432-43ea-8835-90dfe82dc940");
		activityList = Arrays.asList(testMetadata.split("\r\n"));
		for (String url : activityList) {
			activityList = Arrays.asList(url.split("/"));
			String versionedTestId=activityList.get(activityList.size() - 1);
			MyTestRepo repo1 = new MyTestRepo();
			//repo1.delete(versionedTestId);
			
		
		}
	}*/
}
