package com.pearson.mytest.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.pearson.mytest.bean.AssignmentBinding;
import com.pearson.mytest.bean.Book;
import com.pearson.mytest.bean.QuestionOutput;
import com.pearson.mytest.bean.Test;
import com.pearson.mytest.framework.CacheWrapper;
import com.pearson.mytest.framework.exception.InternalException;
import com.pearson.mytest.framework.exception.NotFoundException;
import com.pearson.mytest.proxy.BookDelegate;
import com.pearson.mytest.proxy.TestDelegate;
import com.pearson.mytest.util.CacheKey;
/**
 * This <code>TestService</code> is responsible to get the tests, test questions and 
 * published tests from PAF.
 */
public class TestService {

	@Autowired
	@Qualifier("tests")
	private TestDelegate testRepo;

	@Autowired
	@Qualifier("books")
	private BookDelegate bookRepo;

	@Autowired
	@Qualifier("questionService")
	private QuestionService questionService;

	private static CacheWrapper CACHE;

	/**
	 * This constructor initializes the instance of the cache wrapper object for caching operations.
	 * 
	 */
	public TestService(){
		CACHE = CacheWrapper.getInstance();
	}

	/**
	 * This will fetch the details of a specific my test
	 * 
	 * @param testId
	 * @return
	 * @throws InternalException
	 * @throws NotFoundException
	 */
	public Test getTestByID(String testId) {
		String testCacheKey = String.format(CacheKey.TEST_FORMAT, testId);
		Test test = CACHE.get(testCacheKey);
		if (test == null) {
			test = testRepo.getTestByID(testId);
			CACHE.set(testCacheKey, test);
		}
		return test;
	}
	/**
	 * This method will fetch the published tests for the given book id
	 * @param bookId
	 *              , Book id
	 * @return list of tests
	 */
	public List<Test> getPublisherTestsByBookId(String bookId) {		

		List<Test> tests;
		String bookTestsCacheKey = String.format(CacheKey.BOOK_TESTS_FORMAT, bookId);
		tests = CACHE.get(bookTestsCacheKey);

		if(tests == null) {

			tests = new ArrayList<Test>();
			Book book = bookRepo.getBookByID(bookId);

			for(String testId : book.getTestBindings()) {
				try{

					tests.add(getTestByID(testId));				
				} catch(Exception e) { // NOSONAR
					// To skip if PAF fails for any one test					
				}
			}	

			CACHE.set(bookTestsCacheKey, (ArrayList<Test>)tests);
		}


		return tests;
	}

	/**
	 * This method will fetch the questions for the given test id
	 * @param testId
	 *              , Test id
	 * @return list of questions.
	 */
	public List<QuestionOutput> getTestQuestions(String testId) {

		String testQuestionsCacheKey = String.format(CacheKey.TEST_QUESTIONS_FORMAT, testId);

		List<QuestionOutput> questions = CACHE.get(testQuestionsCacheKey);

		if (questions == null) {

			List<String> questionIds = new ArrayList<String>();

			for (AssignmentBinding questionBinding : getTestByID(testId).getAssignmentContents().getBinding()) {
				questionIds.add(questionBinding.getGuid());
			}

			questions = questionService.getQuestions(questionIds);

			CACHE.set(testQuestionsCacheKey,(ArrayList<QuestionOutput>) questions);
		}

		return questions;
	}

}
