/**
 * 
 */
package com.pearson.mytest.proxy;

import com.pearson.mytest.bean.Test;
import com.pearson.mytest.framework.exception.InternalException;
import com.pearson.mytest.framework.exception.NotFoundException;

/**
 * This interface defines the contract for accessing and saving the Test
 *
 */
public interface TestDelegate {

	/**
	 * Get the test from the repository which is having the ID number
	 * <code>testID</code>
	 * 
	 * @param testID
	 *            ID number of the test
	 * @return Test having the id number testID
	 * @throws InternalException
	 *             The application custom exceptions
	 * @throws NotFoundException
	 *             The test not found custom exceptions
	 */
	Test getTestByID(String testID) ;
	
}
