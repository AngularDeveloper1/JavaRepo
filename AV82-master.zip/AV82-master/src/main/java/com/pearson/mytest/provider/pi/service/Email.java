package com.pearson.mytest.provider.pi.service;

public class Email {
	public String emailAddress;
	public Boolean isPrimary;
}
