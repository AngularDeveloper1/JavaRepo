package com.pearson.mytest.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.pearson.mytest.framework.exception.AccessDeniedException;
import com.pearson.mytest.provider.pi.service.AuthenticationProvider;
import com.pearson.mytest.provider.pi.service.AuthenticationService;
import com.pearson.mytest.provider.pi.service.Email;
import com.pearson.mytest.provider.pi.service.UserProfile;
import com.pearson.mytest.proxy.mytest.repo.LoginRepo;
import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;


/**
 * Authentication of the user
 *
 */
@Controller
@Api(value = "Authenticate", description = "Get Pearson Token from Access Token")
public class AuthenticationController extends BaseController {
	
	@Autowired
	@Qualifier("authenticationService")
	private AuthenticationService authenticationService;

	
	/**
	 * Authentication of the user
	 * @return Pearson Token as a string
	 *
	 */
	@ApiOperation(value = "Returns Pearson Token", notes = "Returns Pearson Token as a string")
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	@ResponseBody
	public String authenticate(HttpServletRequest request) {
		
		String accessToken = request.getHeader("AccessToken");
	
		String pearsonToken = authenticationService.getPITokenFromAccessToken(accessToken);
	
		AuthenticationProvider pi = new AuthenticationProvider();
		//String extUserId = pi.authenticate(pearsonToken);
	
		/*if(! authenticationService.isIntructor(pearsonToken, extUserId)) {
			throw new AccessDeniedException("Only instructors allowed. Invalid attempt by user id : " + extUserId);
		}*/
		int loginCount = (new LoginRepo()).logLogin("ffffffff54b3faa6e4b0f10ebd0747ce");
		
		UserProfile userProfile = authenticationService.getUserProfileFromPIApi(accessToken, "ffffffff54b3faa6e4b0f10ebd0747ce");
	
		return buildResponse(pearsonToken, loginCount, userProfile);
	}
	
	private String buildResponse(String pearsonToken, int loginCount, UserProfile userProfile) {
		/*StringBuilder response = new StringBuilder();
		response.append("{");
		response.append("\"token\": \"" + pearsonToken + "\", ");
		response.append("\"loginCount\": \"" + loginCount + "\", ");
		
		List<Email> emails = userProfile.data.emails;
		for(Email email : emails) {
			if(email.isPrimary) {
				response.append("\"emailAddress\": \"" + email.emailAddress + "\", ");
			}
		}
		
		response.append("\"familyName\": \"" + userProfile.data.familyName + "\", ");
		response.append("\"givenName\": \"" + userProfile.data.givenName + "\"");
		response.append("}");*/
		return "";
	}			

}
