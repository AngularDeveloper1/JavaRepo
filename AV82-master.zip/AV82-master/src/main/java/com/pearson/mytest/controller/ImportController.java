package com.pearson.mytest.controller;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.pearson.mytest.bean.Books;
import com.pearson.mytest.framework.exception.BadDataException;
import com.pearson.mytest.framework.exception.ConfigException;
import com.pearson.mytest.framework.exception.InternalException;
import com.pearson.mytest.framework.exception.NotFoundException;
import com.pearson.mytest.service.ImportService;
import com.pearson.mytest.util.Swagger;
import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;
import com.wordnik.swagger.annotations.ApiParam;
	 
	/**
	 * importing additional books 
	 */ 
	@Controller
	@Api(value = "Books", description = "Import Book APIs")
	public class ImportController extends BaseController {

		@Autowired
		@Qualifier("importService")
		private ImportService importService;
		
		
		/**
		 * Save the question to repository
		 * @param question, JSON data having meta data and qti2.1 xml
		 * @param bookid, Book id under which question has to be created.
		 * @param nodeId, Node id under which question has to be created.
		 * @return response message from repository
		 * @throws NotFoundException
		 * @throws InternalException
		 * @throws ConfigException
		 * @throws BadDataException 
		 */
		@ApiOperation(value = "import books", notes = Swagger.SAVE_QUESTION)
		@RequestMapping(value = "/books/import", method = RequestMethod.POST)
		@ResponseBody
		public void importBooks(@ApiParam(name = "body") @RequestBody Books books,
				HttpServletResponse response){
			 			
			importService.importBooks(books);
			response.setStatus(HttpServletResponse.SC_CREATED);		 
		}
}
