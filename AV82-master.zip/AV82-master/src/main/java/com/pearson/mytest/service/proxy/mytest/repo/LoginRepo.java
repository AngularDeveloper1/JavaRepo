package com.pearson.mytest.proxy.mytest.repo;

import java.util.Date;
import java.util.List;

import org.mongodb.morphia.query.Query;

import com.pearson.mytest.bean.Login;
import com.pearson.mytest.dataaccess.DataAccessHelper;

public class LoginRepo {


	private DataAccessHelper<Login> loginaccessor;

	/**
	 * Constructor to access DataAccessHelper to perform login operation.
	 * 
	 */
	public LoginRepo() {
		loginaccessor = new DataAccessHelper<Login>(Login.class);
	}

	/**
	 * This method will get the login count of the user.
	 * 
	 * @param userid
	 * 				, represents the user.
	 * @return login count as a number.
	 */
	public int logLogin(String userid) {
		
		Login login = new Login();
		login.setUserid(userid);
		login.setDatetime(new Date());
		
		loginaccessor.save(login);
		
		return getLoginCount(userid);
	}
	
	private int getLoginCount(String userid) {
		
		Query<Login> query = loginaccessor.getDataQuery();
		List<Login> logins = query.filter("userid", userid).asList();
				
		return logins.size();
	}
}
