/**
 * 
 */
package com.pearson.mytest.dataaccess;

import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.mongodb.morphia.Datastore;
import org.mongodb.morphia.Morphia;

import com.mongodb.MongoClient;
import com.mongodb.MongoCredential;
import com.mongodb.ServerAddress;
import com.pearson.mytest.framework.ConfigurationManager;
import com.pearson.mytest.framework.exception.ConfigException;
import com.pearson.mytest.framework.exception.InternalException;

/**
 * @author prasadbn DataAccessor class is designed to connect to mongo database
 *         using morphia java driver. This will return datastore which will be
 *         used to CRUD operation with mongo db. morphia.mapPackage methods will
 *         map the entity to table in database.
 *
 */
/**
 * @author ravikumar.gh
 *
 */
public class DataAccessor {

	private static Datastore datastore;

	private static final Integer DEFAULT_MONGO_PORT = 27017;

	/**
	 * This method will return the data store by connecting the Mongo db. This
	 * will be mapped to package and can able to do CRUD operation for all
	 * entities in database.
	 * 
	 * @return Datastore, is the Mongo db reference point which can be used to
	 *         CRUD operation.
	 * @throws ConfigException
	 * @throws UnknownHostException
	 * @TODOEntry Getting the database and server from properties file
	 */
	public static Datastore getDatastore() {
		if (datastore == null) {

			MongoClient client = null;
			ConfigurationManager config = ConfigurationManager.getInstance();

			try {

				String servers = config.getDataBaseServer();
				MongoCredential credentials = getCredential(config);

				if (credentials == null) {
					client = new MongoClient(getMongoServers(servers));
				} else {
					client = new MongoClient(getMongoServers(servers),
							Arrays.asList(credentials));
				}

			} catch (Exception e) {
				throw new InternalException(
						"Error on mongoclient creation in getDatastore method",
						e);
			}

			Morphia morphia = new Morphia();
			datastore = morphia.createDatastore(client, config.getDataBase());

		}

		return datastore;

	}

	
	/**
	 * @param config
	 * @return MongoDB Credentials
	 */
	private static MongoCredential getCredential(ConfigurationManager config) {

		String userName = config.getDataBaseUserName();

		if (userName == null || userName.isEmpty()) {
			return null;
		} else {
			return MongoCredential.createMongoCRCredential(userName, config
					.getDataBase(), config.getDataBasePassword().toCharArray());
		}
	}

	/**
	 * Returns a list of one or multiple (in case of replication) MongoDB server addresses
	 * @param connString
	 * @return
	 */
	private static List<ServerAddress> getMongoServers(String connString) {

		List<ServerAddress> seeds = new ArrayList<ServerAddress>();
		String[] servers = connString.split(",");

		for (String server : servers) {

			String[] host = server.split(":");

			try {

				seeds.add(new ServerAddress(host[0], host.length > 1 ? Integer
						.parseInt(host[1]) : DEFAULT_MONGO_PORT));

			} catch (NumberFormatException | UnknownHostException numEx) {
				throw new InternalException(
						"Error reading mongodb connection: Mongo Port in "
								+ server, numEx);
			}

		}

		return seeds;

	}

	/**
	 * This method will return the data store by mapping the specific entity.
	 * So, the data store will have reference to only given entity and able to
	 * do CRUD operation to given entity.
	 * 
	 * @param klazz
	 *            , Entity annotated class
	 * @return Datastore, is the Mongo db reference point which can be used to
	 *         CRUD operation.
	 * @throws ConfigException
	 * @throws UnknownHostException
	 */
	public Datastore getGenericDataStore(Class<?> klazz) {
		ConfigurationManager config = ConfigurationManager.getInstance();
		MongoClient mongoclient;
		try {
			mongoclient = new MongoClient(config.getDataBaseServer());
		} catch (UnknownHostException e) {
			throw new InternalException(
					"Error on mongoclient creation in getGenericDataStore method",
					e);
		}
		Morphia morphia = new Morphia();
		morphia.map(klazz);
		return morphia.createDatastore(mongoclient, config.getDataBase());
	}
}
