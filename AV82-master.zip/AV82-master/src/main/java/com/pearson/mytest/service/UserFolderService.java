package com.pearson.mytest.service;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.pearson.mytest.bean.QuestionBinding;
import com.pearson.mytest.bean.UserFolder;
import com.pearson.mytest.bean.UserQuestionsFolder;
import com.pearson.mytest.framework.CacheWrapper;
import com.pearson.mytest.framework.exception.BadDataException;
import com.pearson.mytest.framework.exception.NotFoundException;
import com.pearson.mytest.proxy.UserFoldersDelegate;
import com.pearson.mytest.util.CacheKey;

/**
 * This <code>UserFolderService</code> is responsible to create the folders and get the folders of tests and questions.
 */
public class UserFolderService {

	/**
	 * @Qualifier annotation searched for the value userFolders in
	 *            appServlet-servlet.xml file created instance
	 */
	@Autowired
	@Qualifier("userFoldersRepo")
	private UserFoldersDelegate userFoldersRepo;	

	/**
	 * This method is responsible to get the user folders
	 * 
	 * @param userId
	 *            The instructor user id to get the folder
	 * @param parentFolderId
	 *            The parent folder id to get its children folders
	 * @return The list of user folders
	 */
	public List<UserFolder> getFolders(String userId, String parentFolderId){
		
		return userFoldersRepo.getChildFolders(userId, parentFolderId);
	}
	
	/**
	 * To get the My Test Root folder used to store root level test bindings
	 * 
	 * @param userId
	 *            The instructor user id to get the folder
	 * @return User Folder
	 */
	public UserFolder getMyTestRoot(String userID){
		
		return userFoldersRepo.getMyTestRoot(userID);
	}
	
	/**
	 * To get the Question Folders Root folder 
	 * 
	 * @param userId
	 *            The instructor user id to get the folder
	 * @return User Folder
	 */
	public UserQuestionsFolder getQuestionFoldersRoot(String userID){
		
		return userFoldersRepo.getQuestionFoldersRoot(userID);
	}
	
	/**
	 * To get User Questions Root folder used to store user created question bindings
	 * 
	 * @param userId
	 *            The instructor user id to get the folder
	 * @return User Questions Folder
	 */
	public UserQuestionsFolder getMyQuestionsFolder(String userID){
		
		return userFoldersRepo.getMyQuestionsFolder(userID);
	}
	
	/**
	 * This method is responsible to get the folder of a user created questions
	 * @param folderId
	 * 				 ,folder id
	 * @param userID
	 * 				, user id
	 */
	public UserQuestionsFolder getMyQuestionsFolder(String userID, String folderId){
		
		return userFoldersRepo.getMyQuestionsFolder(userID, folderId);
	}
	
	public List<UserQuestionsFolder> getMyQuestionsFolders(String userID){
		
		return userFoldersRepo.getMyQuestionsFolders(userID);
	}
	
    public List<UserQuestionsFolder> getChildQuestionFolders(String folderId){
        
        return userFoldersRepo.getChildQuestionFolders(folderId);
    }
	
	/**
	 * To get the containing folder for test
	 * 
	 * @param testId
	 *            The PAF guid of the test stored in test bindings property of any user folder
	 * @return User Folder
	 */
	public UserFolder getTestFolder(String testId) {

		return userFoldersRepo.getTestFolder(testId);		 
	}	
	
	public double getUserFolderMinSeq(String userId) {

		return userFoldersRepo.getUserFolderMinSeq(userId);		 
	}
	
	public double getUserQuestionsFolderMinSeq(String userId) {

		return userFoldersRepo.getUserQuestionsFolderMinSeq(userId);		 
	}

	/**
	 * This method is responsible to get the user folder
	 * 
	 * @param userId
	 *            The instructor user id to get the folder
	 * @param folderId
	 *            The folder id to get its details
	 * @return The folder details
	 * @throws NotFoundException
	 */
	public UserFolder getFolder(String userId, String folderId) {
		
		UserFolder userFolder;		
		
        if(folderId == null || "null".equals(folderId) ) {
        	
        	userFolder = getMyTestRoot(userId);
		} else {
			
			userFolder = userFoldersRepo.getFolder(folderId);
		}        
		
		return userFolder; 
	}
	/**
	 * This method is responsible to save the folder
	 */
	public UserFolder saveFolder(UserFolder folder, String userId){
		
		// Check for userId and its value should not be null or empty
		if (userId == null) {
			throw new BadDataException("userId should not be null or empty");
		}
		if (folder.getGuid() == null) {
			folder.setGuid(UUID.randomUUID().toString());
		}
		folder.setUserID(userId);
		
		//Validate the user folder values
		folder.validateState();
		
		List<UserFolder> folders = new ArrayList<UserFolder>();
		folders.add(folder);
		userFoldersRepo.saveFolders(folders);		
		
		return folder;
	}
	
	public UserQuestionsFolder saveUserQuestionFolder(UserQuestionsFolder folder, String userId){
		
		// Check for userId and its value should not be null or empty
		if (userId == null) {
			throw new BadDataException("userId should not be null or empty");
		}
		if (folder.getGuid() == null) {
			folder.setGuid(UUID.randomUUID().toString());
			folder.setQuestionBindings(new ArrayList<QuestionBinding>());
		}
		folder.setUserID(userId);		
		
		List<UserQuestionsFolder> folders = new ArrayList<UserQuestionsFolder>();
		folders.add(folder);
		    
        String userQuestionsCacheKey = String.format(CacheKey.USER_QUESTIONS_FORMAT, folder.getGuid());    
        CacheWrapper.getInstance().delete(userQuestionsCacheKey);
        
		userFoldersRepo.saveUserQuestionFolders(folders);		
		
		return folder;
	}	
	/**
	 * This method is responsible to get the child folders of a folder
	 * @param parentFolderId
	 * 						, parent folder id
	 */
	public List<UserFolder> getFolders(String parentFolderId){

		List<UserFolder> folders;

		folders = userFoldersRepo.getChildFolders(parentFolderId);

		return folders;
	}
}
