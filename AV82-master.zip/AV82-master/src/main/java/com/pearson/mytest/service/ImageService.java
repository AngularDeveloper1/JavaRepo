package com.pearson.mytest.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.multipart.MultipartFile;
import com.pearson.mytest.proxy.eps.ImageRepo;

/**
 * Service which meant for image operation like accessing, uploading, etc..
 * @author prasadbn
 *
 */
public class ImageService {
	
	@Autowired
	@Qualifier("imageRepo")
	private ImageRepo imageAccessor;

	/**
	 * uploading the image file to EPS repository
	 * @param file, Springframework's file
	 * @return
	 */
	public String uploadImage(MultipartFile file){
		return imageAccessor.uploadImage(file);
	}
}
