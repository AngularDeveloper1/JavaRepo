package com.pearson.mytest.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.pearson.mytest.bean.Book;
import com.pearson.mytest.framework.exception.NotFoundException;
import com.pearson.mytest.proxy.BookDelegate;
import com.pearson.mytest.proxy.UserSettingsDelegate;

/**
 * 
 * Serves the book and discipline related information.
 *
 */
public class BookService {

	/**
	 * 
	 * 
	 */
	@Autowired
	@Qualifier("books")
	private BookDelegate bookDelegate;

	@Autowired
	@Qualifier("usersettings")
	private UserSettingsDelegate userSettingService;

	/**
	 * This will get the list of books depending on the search criteria
	 * 
	 * @param searchCriteria
	 *            to search the book
	 * @return List of books
	 * @throws NotFoundException
	 */
	public List<Book> getBooks(Map<String, String> searchCriteria, String userid) {
		List<Book> books = null;
		List<Book> userSelectedbooks = new ArrayList<Book>();

		if (searchCriteria.containsKey("userBooks")
				&& Boolean.valueOf(searchCriteria.get("userBooks"))) {
			List<String> userbooks = null;
			books = bookDelegate.getBooks(searchCriteria);
			userbooks = userSettingService.getUserBooks(userid);

			for (String bookid : userbooks) {
				for (Book book : books) {
					if (bookid.equals(book.getGuid())) {
						userSelectedbooks.add(book);
					}
				}
			}

			return userSelectedbooks;
		} else {
			return bookDelegate.getBooks(searchCriteria);
		}
	}

	/**
	 * Gets the book detail by book id
	 * 
	 * @param bookID
	 * @return book details
	 * @throws NotFoundException
	 */
	public Book getBookByID(String bookID) {
		return bookDelegate.getBookByID(bookID);
	}

	/**
	 * Gets the list of disciplines/areas Like "Law","Nursing" ect
	 * 
	 * @return list of disciplines
	 * @throws NotFoundException
	 */
	public List<String> getDisciplines() {
		return bookDelegate.getDisciplines();
	}
}
