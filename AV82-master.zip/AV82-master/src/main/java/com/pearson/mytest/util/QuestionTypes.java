package com.pearson.mytest.util;

public enum QuestionTypes {
	ESSAY,MULTIPLERESPONSE, MATCHING, MULTIPLECHOICE, TRUEFALSE, FILLINBLANKS
}
