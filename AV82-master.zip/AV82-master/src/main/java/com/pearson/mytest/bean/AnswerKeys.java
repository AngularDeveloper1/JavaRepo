package com.pearson.mytest.bean;


/**
 * Indicates the space for the answer keys in download document
 *
 */
public enum AnswerKeys {

	NONE,
	SAMEFILE,
	SEPARATEFILE
}
