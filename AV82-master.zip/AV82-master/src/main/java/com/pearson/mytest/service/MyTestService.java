package com.pearson.mytest.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;


import com.pearson.mytest.bean.Metadata;
import com.pearson.mytest.bean.TestBinding;
import com.pearson.mytest.bean.TestEnvelop;
import com.pearson.mytest.bean.TestMetadata;
import com.pearson.mytest.bean.TestResult;
import com.pearson.mytest.bean.UserFolder;
import com.pearson.mytest.framework.CacheWrapper;
import com.pearson.mytest.framework.exception.BadDataException;
import com.pearson.mytest.framework.exception.ConfigException;
import com.pearson.mytest.framework.exception.InternalException;
import com.pearson.mytest.framework.exception.NotFoundException;
import com.pearson.mytest.proxy.MyTestDelegate;
import com.pearson.mytest.proxy.paf.util.Converter;
import com.pearson.mytest.util.CacheKey;

public class MyTestService {

	@Autowired
	@Qualifier("myTestsRepo")
	private MyTestDelegate myTestsRepo;

	@Autowired
	@Qualifier("metadataService")
	private MetadataService metadataService;

	@Autowired
	@Qualifier("userFolderService")
	private UserFolderService userFolderService;

	private static CacheWrapper CACHE;

	/**
	 * This constructor initializes the instance of the cache wrapper object for caching operations.
	 * 
	 */
	public MyTestService() {
		CACHE = CacheWrapper.getInstance();
	}

	/**
	 * Create paper test inside the specified user folder
	 * 
	 * @param test
	 *            paper test envelope contains test and meta data
	 * @param userId
	 *            test has been created for the user.
	 * @param folderId
	 *            The folder Id in which test should be created
	 * @return Newly created test details
	 * @throws NotFoundException
	 * @throws ConfigException
	 * @throws InternalException
	 * @throws BadDataException
	 */
	public TestResult saveTest(TestEnvelop test, String userId, String folderId) {
		TestResult result = null;
		UserFolder folder = this.getUserFolder(userId, folderId);

		if (test.getmetadata().getGuid() == null) {			
			
			result = myTestsRepo.create(test);
			
			if(folder != null){
				double sequence = 1.0;
				
				List<TestBinding> testBindings = folder.getTestBindings();
				if (!testBindings.isEmpty()) {
					sequence = testBindings.get(testBindings.size() - 1).getSequence() + 1;
				}			
				
				TestBinding testBinding = new TestBinding();
				testBinding.setTestId(result.getGuid());
				testBinding.setSequence(sequence);
				
				testBindings.add(testBinding);
				
				folder.setTestBindings(testBindings);
				
				userFolderService.saveFolder(folder, userId);
			}
		} else {
			
			result = myTestsRepo.update(test);
			
			CACHE.delete(String.format(CacheKey.TEST_FORMAT, test.getmetadata().getGuid()));
			CACHE.delete(String.format(CacheKey.METADATA_FORMAT, test.getmetadata().getGuid()));
			CACHE.delete(String.format(CacheKey.TEST_QUESTIONS_FORMAT, test.getmetadata().getGuid()));
		}		
		
		return result;
	}

	/**
	 * Get the test lists from the repository which are created under specific
	 * folder
	 * 
	 * @param userId
	 *            get all tests created by User
	 * @param folderId
	 *            folder Id where all created tests are accessed
	 * @return list of test which are listed under folder having folderID
	 * @throws NotFoundException
	 *             Application custom exception
	 * @throws InternalException
	 *             Application custom exception
	 * @throws BadDataException
	 *             Application custom exception
	 */
	public List<TestMetadata> getMyFolderTests(String userId, String folderId, boolean flat) {	
		
		UserFolder folder;
		if(folderId == null) {
			folder = userFolderService.getMyTestRoot(userId);
		} else {
			folder = this.getUserFolder(userId, folderId);
		}
		
		if(flat){
			List<TestMetadata> tests = new ArrayList<TestMetadata>();
			fillTestsFlatView(tests,folder);
			return tests;
		}else{
			return this.getMyFolderTests(folder);	
		}
		
	}

	private void fillTestsFlatView(List<TestMetadata> tests, UserFolder folder) {
		List<UserFolder> folders;
		folders = userFolderService.getFolders(folder.getGuid());
		tests.addAll(getMyFolderTests(folder));
		for (UserFolder userFolder : folders) {
			fillTestsFlatView(tests, userFolder);
		}
	}
	/**
	 * Get the test lists from the repository which are created under specific
	 * folder
	 * 
	 * @param folder
	 *            get all tests available inside the folder
	 * @return list of test which are listed under folder having folderID
	 * @throws InternalException
	 *             Application custom exception
	 * @throws BadDataException
	 *             Application custom exception
	 */
	public List<TestMetadata> getMyFolderTests(UserFolder folder) {
					
		List<TestMetadata> tests = new ArrayList<TestMetadata>();
			
		if(folder != null) {
			List<TestBinding> testBindings = folder.getTestBindings();
			
			if (!testBindings.isEmpty()) {

				for(TestBinding testBinding : testBindings) {
					Metadata metadata = metadataService.getMetadata(testBinding.getTestId());
					TestMetadata testMetadata = Converter.getDestinationBean(metadata, TestMetadata.class, Metadata.class); 
				
					tests.add(testMetadata); 
				}			
			}			
		}			
		
		return tests;
	}

	/**
	 * Gets the max sequence of a test available inside the folder
	 * 
	 * @param folder
	 *            the folder object is used to get max sequence of tests
	 *            available inside folder
	 * @return the max tests sequence of the give folder
	 */
	public double getFolderTestsMaxExtMetadataSequence(UserFolder folder) {

		List<TestBinding> testBindings = folder.getTestBindings(); 
		double sequence = 0.0;

		int testsLastIndex = testBindings.size();
		sequence = testsLastIndex;
		double extMetadataSequence = testBindings.get(testsLastIndex - 1).getSequence();
		if (extMetadataSequence > 0.0) {
			sequence = extMetadataSequence;
		}

		return sequence;
	}

	/**
	 * Get the user folder and if folder is not available then return null
	 * 
	 * @param userId
	 *            the User id
	 * @param folderId
	 *            the folder id
	 * @return folder object
	 */
	private UserFolder getUserFolder(String userId, String folderId) {
		
		UserFolder folder = new UserFolder();
        if(folderId == null || "null".equals(folderId)) {
        	folder = userFolderService.getMyTestRoot(userId);
		} else {				
			folder = userFolderService.getFolder(userId, folderId);
		}		
		
		return folder;
	}

}
