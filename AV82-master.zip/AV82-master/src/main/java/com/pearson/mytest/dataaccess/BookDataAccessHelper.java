package com.pearson.mytest.dataaccess;


import java.util.List;
import org.mongodb.morphia.query.Query;
import com.pearson.mytest.bean.Book;


/**
 * This helper class which will provide the facility to generate Book been query
 * 
 * @author nithinjain
 */
public class BookDataAccessHelper extends DataAccessHelper<Book> {

	public BookDataAccessHelper(){
		super(Book.class);
	}

	/**
	 * Get the list of Books based on the search string by applying "or" operation on (id, title, isbn, publisher, authors, discipline)
	 * @param datastore This indicates the data base
	 * @param s This indicates the Search string
	 * @return List<Book> 
	 */
	public List<Book> getSearchedBooks(String s) {
		Query<Book> q = this.datastore.createQuery(Book.class);

		q.or(q.criteria("guid").containsIgnoreCase(s),
				q.criteria("title").containsIgnoreCase(s),
				q.criteria("isbn").containsIgnoreCase(s),
				q.criteria("publisher").containsIgnoreCase(s),
				q.criteria("authors").containsIgnoreCase(s),
				q.criteria("discipline").containsIgnoreCase(s));

		return q.asList();
	}
}
