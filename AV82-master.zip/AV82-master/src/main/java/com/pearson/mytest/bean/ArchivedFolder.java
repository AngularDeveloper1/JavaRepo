package com.pearson.mytest.bean;


/**
 * Represents the archived folder for the user
 * 
 */
public class ArchivedFolder extends UserFolder {

	private static final long serialVersionUID = 1L;
	
}
