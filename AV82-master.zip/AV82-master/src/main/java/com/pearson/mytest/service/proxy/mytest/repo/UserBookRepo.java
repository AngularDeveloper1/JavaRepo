package com.pearson.mytest.proxy.mytest.repo;

import java.util.List;

import org.mongodb.morphia.query.Query;

import com.pearson.mytest.bean.UserBook;
import com.pearson.mytest.dataaccess.DataAccessHelper;
import com.pearson.mytest.proxy.UserBookDelegate;

public class UserBookRepo implements UserBookDelegate {

	private DataAccessHelper<UserBook> accessor;

	/**
	 * Constructor to access DataAccessHelper to perform user book operation.
	 * 
	 */
	public UserBookRepo() {
		accessor = new DataAccessHelper<UserBook>(UserBook.class);
	}

	/**
	 * This method will get the user books from database.
	 * 
	 * @param userId
	 * 				, represents the user.
	 * @return list of user books.
	 */
	@Override
	public List<UserBook> getUserBooks(String userId) {		
		
		Query<UserBook> query = accessor.getDataQuery();
		return query
				.filter(QueryFields.USERID, userId).asList();
		
	}
	
	/**
	 * This method will get the user book from database.
	 * 
	 * @param userId
	 * 				, represents the user.
	 * @return UserBook.
	 */
	@Override
	public UserBook getUserBook(String bookId) {		
		
		Query<UserBook> query = accessor.getDataQuery();
		
		return query.filter(QueryFields.GUID, bookId).get();
	}

	/**
	 * This method will save the user books to database.
	 * 
	 * @param userBooks
	 * 				, represents the books which belongs to user.
	 */
	@Override
	public void saveUserBooks(List<UserBook> userBooks) {
		accessor.save(userBooks);
	}

	/**
	 * This method will save the user book to database.
	 * 
	 * @param userBooks
	 * 				, represents the book which belongs to user.
	 */
	@Override
	public void saveUserBook(UserBook userBook) {
		accessor.save(userBook);
	}
}
