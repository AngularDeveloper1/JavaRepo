package com.pearson.mytest.bean;


/**
 * Indicates the answer area alignment in the download document
 *
 */
public enum AnswerAreas {
	
	NONE, 
	BETWEENQUESTIONS, 
	LEFTSIDE, 
	LASTPAGE
}
