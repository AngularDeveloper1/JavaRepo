package com.pearson.mytest.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.pearson.mytest.bean.TestEnvelop;
import com.pearson.mytest.bean.TestMetadata;
import com.pearson.mytest.bean.TestResult;
import com.pearson.mytest.bean.TestVersionInfo;
import com.pearson.mytest.service.MyTestService;
import com.pearson.mytest.service.TestVersionService;
import com.pearson.mytest.util.Swagger;
import com.pearson.mytest.util.UserHelper;
import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;
import com.wordnik.swagger.annotations.ApiParam;


/**
 * To save the user created test and get the list of all created tests for the given folder and 
 *
 */
@Controller
@Api(value = "My Tests", description = "My Tests")
public class MyTestsController extends BaseController {

	@Autowired
	@Qualifier("myTestService")
	private MyTestService myTestService;
		
	@Autowired
	@Qualifier("testVersionService")
	private TestVersionService testVersionService;
	
	/**
	 * To save or update the user test 
	 * @param testEnvelop
	 * @param folderId
	 * @param request
	 * @param response
	 * @return TestResult
	 */
	@ApiOperation(value = Swagger.SAVE_TEST_VALUE, notes = Swagger.SAVE_TEST_NOTE)
	@RequestMapping(value = "my/folders/{folderId}/tests", method = RequestMethod.POST)
	@ResponseBody
	public TestResult saveTestEnvelop(
			@ApiParam(name = "body") @RequestBody TestEnvelop testEnvelop,
			@PathVariable String folderId, HttpServletRequest request,
			HttpServletResponse response) {
		TestResult result = myTestService.saveTest(testEnvelop,
				UserHelper.getUserId(request), folderId);
		response.setStatus(HttpServletResponse.SC_CREATED);
		return result;
	}
		
	/**
	 * To fetch user test for the given folder
	 * @param folderId
	 * @param request
	 * @return List<TestMetadata>
	 * of  metadata
	 */
	@ApiOperation(value = Swagger.GET_MYFOLDER_TESTS_VALUE, notes = Swagger.GET_MYFOLDER_TESTS_NOTE)
	@RequestMapping(value = "my/folders/{folderId}/tests", method = RequestMethod.GET)
	@ResponseBody
	public List<TestMetadata> getMyFolderTests(@PathVariable String folderId, HttpServletRequest request, boolean flat) {
		return myTestService.getMyFolderTests(UserHelper.getUserId(request),
				folderId, flat);
	}


	/**
	 * To fetch the versions for the given test
	 * @param versionInfo
	 * @param testId
	 * @param request
	 * @param response
	 * @return List<TestResult>
	 * of TestResult
	 */
	@ApiOperation(value = Swagger.CREATE_TEST_VERSION, notes = Swagger.CREATE_TEST_VERSION_NOTE)
	@RequestMapping(value = "my/tests/{testId}/versions", method = RequestMethod.POST)
	@ResponseBody
	public List<TestResult> createVersions(
			@ApiParam(name = "body") @RequestBody TestVersionInfo versionInfo,
			@PathVariable String testId,
			HttpServletRequest request, HttpServletResponse response){

		List<TestResult> result = testVersionService.createVersionTests(versionInfo,
				testId, UserHelper.getUserId(request));
		response.setStatus(HttpServletResponse.SC_CREATED);

		return result;

	}

}
