package com.pearson.mytest.proxy.paf.repo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.pearson.mytest.bean.TestEnvelop;
import com.pearson.mytest.bean.TestResult;

import com.pearson.mytest.framework.exception.BadDataException;
import com.pearson.mytest.framework.exception.NotFoundException;
import com.pearson.mytest.proxy.BookDelegate;
import com.pearson.mytest.proxy.MyTestDelegate;
import com.pearson.mytest.proxy.paf.util.ActivityUtil;
import com.pearson.mytest.proxy.paf.util.Connector;
import com.pearson.mytest.util.Common;
/**
 * This <code>MyTestRepo</code> is responsible for create, delete, update of tests from PAF repository
 *
 */
public class MyTestRepo implements MyTestDelegate {

	@Autowired
	@Qualifier("books")
	BookDelegate bookRepo;

	/*
	 * @see
	 * com.pearson.mytest.proxy.MyTestDelegate#saveTest(com.pearson.mytest.bean
	 * .Test, long)
	 */
	@Override
	public TestResult create(TestEnvelop test){

		String format = Common.PAF_ACTIVITY_CREATION_CONTENT_TYPE;
		String result = null;
		String payload = ActivityUtil.getTestPayload(test);

		try {

			result = (new Connector()).saveActivity(payload, format);

		} catch (NotFoundException e) {
			throw new BadDataException(e.getMessage(), e);
		}

		return ActivityUtil.getTestResultBean(result);
	}

	/*
	 * @see
	 * com.pearson.mytest.proxy.MyTestDelegate#saveTest(com.pearson.mytest.bean
	 * .Test, long)
	 */
	@Override
	public TestResult update(TestEnvelop test) {

		String format = Common.PAF_ACTIVITY_CREATION_CONTENT_TYPE;
		String result = null;
		String payload = ActivityUtil.getTestPayload(test);

		try {

			result = (new Connector()).updateActivity(payload, format, test
					.getmetadata().getGuid());

		} catch (NotFoundException e) {
			throw new BadDataException(e.getMessage(), e);
		}

		return ActivityUtil.getTestResultBean(result);
	}
	/**
	 * This method will delete the test from PAF based on test id
	 * 
	 * @param testId
	 */
	@Override
	public void delete(String testId) {

		String format = Common.PAF_ACTIVITY_CREATION_CONTENT_TYPE;

		try {

			(new Connector()).deleteActivity(format, testId);

		} catch (NotFoundException e) {
			throw new BadDataException(e.getMessage(), e);
		}
	}

}
