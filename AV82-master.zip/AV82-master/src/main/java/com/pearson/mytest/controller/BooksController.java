package com.pearson.mytest.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.pearson.mytest.bean.Book;
import com.pearson.mytest.service.BookService;
import com.pearson.mytest.util.UserHelper;
import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;


/**
 * To get the books and disciplines for the user
 *
 */
@Controller
@Api(value = "Books", description = "Book APIs")
public class BooksController extends BaseController {

	/**
	 * @Qualifier annotation searched for the value books in
	 *            appServlet-servlet.xml file created instance
	 */
	@Autowired
	@Qualifier("bookService")
	private BookService bookService;

	
	/**
	 * To get all books of the user
	 * @return List<Book>, a list of all books 
	 *
	 */
	@ApiOperation(value = "Returns a list of all Books", notes = "Returns a list of all books")
	@RequestMapping(value = "/books", method = RequestMethod.GET)
	@ResponseBody
	public List<Book> getAllBooks(HttpServletRequest request) {

		List<Book> books = null;
		String userid = UserHelper.getUserId(request);

		Map<String, String> searchCriteria = null;
		searchCriteria = UserHelper.getQueryMap(request.getQueryString());
		books = bookService.getBooks(searchCriteria, userid);

		return books;

	}
	
	/**
	 *  To get book for the given id
	 * @param id
	 * of the required book
	 * @return Book
	 */
	@ApiOperation(value = "Return Book for given id", notes = "Return details of the book for the given {id}")
	@RequestMapping(value = "/books/{id}", method = RequestMethod.GET)
	@ResponseBody
	public Book getBookById(@PathVariable String id) {

		return bookService.getBookByID(id);

	}

	
	/**
	 * To get disciplines
	 * @return  list of disciplines 
	 *
	 */
	@RequestMapping(value = "/disciplines", method = RequestMethod.GET)
	@ResponseBody
	public List<String> getDisciplines() {
		List<String> disciplines;
		disciplines = bookService.getDisciplines();
		return disciplines;
	}
}
