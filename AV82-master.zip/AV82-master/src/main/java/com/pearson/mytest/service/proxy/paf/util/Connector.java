package com.pearson.mytest.proxy.paf.util;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.http.entity.ContentType;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestMethod;

import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.pearson.mytest.framework.ConfigurationManager;
import com.pearson.mytest.framework.RequestCorrelation;
import com.pearson.mytest.framework.exception.BadDataException;
import com.pearson.mytest.framework.exception.ConfigException;
import com.pearson.mytest.framework.exception.InternalException;
import com.pearson.mytest.framework.exception.NotFoundException;
import com.pearson.mytest.proxy.paf.auth.ApiDetails;
import com.pearson.mytest.proxy.paf.auth.TokenGenerator;
import com.pearson.mytest.util.Common;
import com.pearson.mytest.util.HttpResponse;

/**
 * Class which are designed to access and mutate the activities from PAF
 * 
 * @author nithinjain
 *
 */
public class Connector {

	/**
	 * Get the PAF activity list by invoking PAF restful call
	 * 
	 * @param bookTitle
	 *            The book title of a Activity
	 * @param filterCriteria
	 *            The filter criteria
	 * @return PAF Activity list
	 * @throws InternalException
	 * @throws NotFoundException
	 */
	public List<com.pearson.mytest.proxy.paf.bean.Activity> getActivities(
			String bookTitle, Map<String, String> filterCriteria) {

		return this.getActivities(bookTitle, filterCriteria, null);

	}

	/**
	 * Get the PAF activity list by invoking PAF restful call
	 * 
	 * @param bookTitle
	 *            The book title of a activity
	 * @param filterCriteria
	 *            The filter criteria
	 * @param containerTitle
	 *            The chapter title of a activity
	 * @return PAF activity list
	 * @throws InternalException
	 * @throws NotFoundException
	 */
	public List<com.pearson.mytest.proxy.paf.bean.Activity> getActivities(
			String bookTitle, Map<String, String> filterCriteria,
			String containerTitle) {

		List<com.pearson.mytest.proxy.paf.bean.Activity> activities = null;
		TokenGenerator tokenGenerator = new TokenGenerator();
		HttpResponse response = null;

		try {

			// add PAF restful service details to get questions
			ApiDetails api = new ApiDetails(RequestMethod.GET,
					ConfigurationManager.getInstance()
							.getPAFActivitiesEndPoint(), filterCriteria);

			api.addParam("bookTitle", bookTitle);
			if (containerTitle != null) {
				api.addParam("chapterTitle", containerTitle);
			}
			// Add header details to has map
			Map<String, String> headers = new HashMap<String, String>();
			headers.put(Common.AUTHORIZATION, tokenGenerator.getOauthToken(api));
			headers.put(RequestCorrelation.HEADER, RequestCorrelation.getId());

			// Make PAF http get request to get questions
			response = api.makeGet(headers, null);

			// Get the PAF questions detail from response
			activities = this.getActivitiesFromResponse(response);

		} catch (ConfigException e) {
			throw new InternalException("Not able to read configuration", e);
		}
		return activities;
	}
	
	/**
	 * Calling the PAF api with id and format to get the activity
	 * 
	 * @param id
	 *            , PAF activity id-- (guid)
	 * @param formatd
	 *            , PAF activity format
	 * @return response in string
	 * @throws InternalException
	 * @throws NotFoundException
	 */
	public String getActivity(String id, String format) {

		String actvity;

		TokenGenerator tokenGenerator = new TokenGenerator();
		try {
			ApiDetails api = new ApiDetails(RequestMethod.GET, String.format(
					"%s/%s/format", ConfigurationManager.getInstance()
							.getPAFActivitiesEndPoint(), id));

			api.addParam(Common.MEDIATYPE, format);

			Map<String, String> headers = new HashMap<String, String>();

			headers.put(Common.AUTHORIZATION, tokenGenerator.getOauthToken(api));
			headers.put(RequestCorrelation.HEADER, RequestCorrelation.getId());
			
			HttpResponse response = api.makeGet(headers, null);

			actvity = this.getResponseBody(response);

		} catch (ConfigException e) {
			throw new InternalException(
					"Exception thrown from Connector.getActivity method", e);
		}

		return actvity;
	}

	/**
	 * This method will save the activity to paf repository by sending OAuth
	 * token through header.
	 * 
	 * @param payLoad
	 *            , content in string format
	 * @param format
	 *            , format of the data to be stored
	 * @return response message
	 * @throws InternalException
	 * @throws NotFoundException
	 */
	public String saveActivity(String payLoad, String format) {
		String responseMessage;

		TokenGenerator tokenGenerator = new TokenGenerator();
		try {
			ApiDetails api = new ApiDetails(RequestMethod.POST, String.format(
					"%s", ConfigurationManager.getInstance()
							.getPAFActivitiesEndPoint()));

			Map<String, String> headers = new HashMap<String, String>();

			headers.put(Common.AUTHORIZATION, tokenGenerator.getOauthToken(api));
			headers.put(RequestCorrelation.HEADER, RequestCorrelation.getId());
			
			ContentType contentType = ContentType.create(format);
			HttpResponse response = api.makePost(headers, contentType, payLoad);

			responseMessage = this.getResponseBody(response);

		} catch (ConfigException e) {
			throw new InternalException(
					"Exception thrown from Connector.saveActivity method", e);
		}

		return responseMessage;
	}

	/**
	 * This method will update the activity to paf repository by sending OAuth
	 * token through header.
	 * 
	 * @param payLoad
	 *            , content in string format
	 * @param format
	 *            , format of the data to be stored
	 * @return response message
	 * @throws InternalException
	 * @throws NotFoundException
	 */
	public String updateActivity(String payLoad, String format, String guid) {
		String responseMessage;

		TokenGenerator tokenGenerator = new TokenGenerator();
		try {
			ApiDetails api = new ApiDetails(RequestMethod.PUT, String.format(
					Common.PAF_UPDATE_ACTIVITY_END_POINT_FORMAT,
					ConfigurationManager.getInstance()
							.getPAFActivitiesEndPoint(), guid));

			Map<String, String> headers = new HashMap<String, String>();

			headers.put(Common.AUTHORIZATION, tokenGenerator.getOauthToken(api));
			headers.put(RequestCorrelation.HEADER, RequestCorrelation.getId());
			
			ContentType contentType = ContentType.create(format);
			HttpResponse response = api.makePut(headers, contentType, payLoad);

			responseMessage = this.getResponseBody(response);

		} catch (ConfigException e) {
			throw new InternalException(
					"Exception thrown from Connector.updateActivity method", e);
		}

		return responseMessage;
	}
	
	public void deleteActivity(String format, String guid) {

		TokenGenerator tokenGenerator = new TokenGenerator();
		try {
			ApiDetails api = new ApiDetails(RequestMethod.DELETE, String.format(
					Common.PAF_UPDATE_ACTIVITY_END_POINT_FORMAT,
					ConfigurationManager.getInstance()
							.getPAFActivitiesEndPoint(), guid));

			Map<String, String> headers = new HashMap<String, String>();

			headers.put(Common.AUTHORIZATION, tokenGenerator.getOauthToken(api));
			headers.put(RequestCorrelation.HEADER, RequestCorrelation.getId());
			
			ContentType contentType = ContentType.create(format);
			HttpResponse response = api.makeDelete(headers, contentType);
			
			if(response.getCode().equals(HttpStatus.FORBIDDEN)){
				if(response.getReponseMessage().contains(ConfigurationManager.getInstance().getParentTestDeleteExceptionMsg())){
					throw new BadDataException("Test having versions cannot be deleted. Delete the versions first to delete the parent test.");	
				}else{
					throw new InternalException("Unable to delete the test");
				}
			}

		} catch (ConfigException e) {
			throw new InternalException(
					"Exception thrown from Connector.deleteActivity method", e);
		}
	}

	/**
	 * This method will update the activity to paf repository by sending OAuth
	 * token through header.
	 * 
	 * @param payLoad
	 *            , content in string format
	 * @param format
	 *            , format of the data to be stored
	 * @return response message
	 * @throws InternalException
	 * @throws NotFoundException
	 */
	public String createVersionActivity(String payLoad, String format,
			String guid) {
		String responseMessage;

		try {
			ApiDetails api = new ApiDetails(RequestMethod.POST, String.format(
					Common.PAF_VERSION_ACTIVITY_END_POINT_FORMAT,
					ConfigurationManager.getInstance()
							.getPAFActivitiesEndPoint(), guid));

			Map<String, String> headers = new HashMap<String, String>();

			headers.put(Common.AUTHORIZATION,
					(new TokenGenerator()).getOauthToken(api));
			headers.put(RequestCorrelation.HEADER, RequestCorrelation.getId());
			ContentType contentType = ContentType.create(format);
			HttpResponse response = api.makePost(headers, contentType, payLoad);

			responseMessage = this.getResponseBody(response);

		} catch (ConfigException e) {
			throw new InternalException(
					"Exception thrown from Connector.createVersionActivity method",
					e);
		}

		return responseMessage;
	}

	/**
	 * This gets the versions of the given test.
	 * @param testID
	 * @return list of URLs to get test details
	 */
	public String getTestVersions(String testID) {
		try {
			ApiDetails api = new ApiDetails(RequestMethod.GET, String.format(
					Common.PAF_VERSION_ACTIVITY_END_POINT_FORMAT,
					ConfigurationManager.getInstance()
							.getPAFActivitiesEndPoint(), testID));

			Map<String, String> headers = new HashMap<String, String>();
			headers.put(Common.AUTHORIZATION,
					(new TokenGenerator()).getOauthToken(api));
			headers.put(RequestCorrelation.HEADER, RequestCorrelation.getId());

			// Make PAF http get request to get questions
			HttpResponse response = api.makeGet(headers, null);

			// Get the PAF questions detail from response
			return this.getResponseBody(response);

		} catch (ConfigException e) {
			throw new InternalException("Not able to read configuration", e);
		}
	}

	/**
	 * Get the PAF activities from the response
	 * 
	 * @param response
	 *            The response object contains PAF activities
	 * @return PAF activity list
	 * @throws InternalException
	 * @throws NotFoundException
	 */
	private List<com.pearson.mytest.proxy.paf.bean.Activity> getActivitiesFromResponse(
			HttpResponse response) {
		String responseBody;
		List<com.pearson.mytest.proxy.paf.bean.Activity> pafActivities = null;

		Gson gson = new Gson();
		responseBody = this.getResponseBody(response);

		if (responseBody != null && !responseBody.isEmpty()) {
			// Get the type of PAF question bean list
			Type type = new TypeToken<List<com.pearson.mytest.proxy.paf.bean.Activity>>() {
				private static final long serialVersionUID = 1L;
			}.getType();

			// Conversion of Json to PAF question bean
			pafActivities = gson.fromJson(responseBody, type);
		} else {
			pafActivities = new ArrayList<com.pearson.mytest.proxy.paf.bean.Activity>();
		}

		return pafActivities;
	}

	/**
	 * Gets the response body string
	 * 
	 * @param response
	 *            The response object got from PAF
	 * @return The response body string
	 * @throws InternalException
	 * @throws NotFoundException
	 */
	private String getResponseBody(HttpResponse response) {
		String responseBody = null;
		// Get the response code from the response.
		int statusCode = response.getCode().value();

		// Return the user data if the response code is between 200
		// (HttpStatus.OK) &
		// 300(HttpStatus.MULTIPLE_CHOICES).
		if (statusCode >= HttpStatus.OK.value()
				&& statusCode < HttpStatus.MULTIPLE_CHOICES.value()) {

			// get the response body
			responseBody = response.getReponseMessage();

		} else if (statusCode == HttpStatus.NOT_FOUND.value()
				|| statusCode == HttpStatus.NOT_ACCEPTABLE.value()) {
			/**
			 * if PAF gives the http status like file not found(404) or not
			 * acceptable input from integrating partner(406), here it means -
			 * the given activity id and media type of the content mismatch Eg:
			 * http://repo.paf.cert.pearsoncmg.com/paf-repo/resources/
			 * activities
			 * /{id}/format?mediatype=application/vnd.pearson.qti.v2p1 .asi+xml
			 */

			throw new NotFoundException();
		} else {
			StringBuilder responseMsg = new StringBuilder();
			responseMsg
					.append("Not able to get the response from PAF -- PAF end point HTTP Status code :")
					.append(statusCode).append(", Message :")
					.append(response.getReponseMessage());
			throw new InternalException(responseMsg.toString());
		}

		return responseBody;
	}
}
