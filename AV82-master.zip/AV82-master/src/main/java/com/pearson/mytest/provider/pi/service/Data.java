package com.pearson.mytest.provider.pi.service;

import java.util.List;

public class Data {
	public List<Email> emails;
	public String familyName;
	public String givenName;
}
