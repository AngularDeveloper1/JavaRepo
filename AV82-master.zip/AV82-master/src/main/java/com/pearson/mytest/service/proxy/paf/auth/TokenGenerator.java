package com.pearson.mytest.proxy.paf.auth;

import com.pearson.ed.ltg.oauth.client.*;
import com.pearson.mytest.framework.ConfigurationManager;
import com.pearson.mytest.framework.exception.AuthTokenException;

/**
 * This class will is used to generate PAF authentication Oauth token.
 * 
 * @author nithinjain
 */
public class TokenGenerator {

	/**
	 * Gets the paf Oauth token string
	 * 
	 * @param data
	 *            the paf api details
	 * @return the paf oauth token string
	 * @throws Exception
	 */
	public String getOauthToken(ApiDetails data){
		String oauthToken;
		try {
			// return a string of oauth parameters
			oauthToken = OAuthClientSigner.constructSignedAuthorizationHeader(
					ConfigurationManager.getInstance().getPAFDataSecretKey(),
					ConfigurationManager.getInstance().getPAFOauthAlgorithm(),
					data.getMethod(), (String) data.getUrl(), data.getParams(),
					null, ConfigurationManager.getInstance()
							.getPAFConsumerKey());

		} catch (Exception e) {
			throw new AuthTokenException("Unable to generate oauth token",e);
		}
		return oauthToken;
	}
}
