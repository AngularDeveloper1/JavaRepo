package com.pearson.mytest.proxy.paf.repo;

import com.google.common.base.Strings;
import com.google.gson.Gson;
import com.pearson.mytest.bean.Metadata;
import com.pearson.mytest.framework.exception.InternalException;
import com.pearson.mytest.proxy.MetadataDelegate;
import com.pearson.mytest.proxy.paf.bean.Activity;
import com.pearson.mytest.proxy.paf.util.*;
import com.pearson.mytest.util.Common;

/**
 * This <code>MetadataRepo</code> is responsible to access meta data of the tests from PAF
 * repository
 *
 */
public class MetadataRepo implements MetadataDelegate {

	private static final String ITEM_ID_NULL = "Item id to fetch metadata is set to null";

	/**
	 * This method will get the meta data of the tests
	 * 
	 * @param metadataId
	 * @return test meta data
	 */
	@Override
	public Metadata getMetadata(String metadataId) {
		if (Strings.isNullOrEmpty(metadataId)) {
			throw new InternalException(ITEM_ID_NULL);
		}
		String metaData = (new Connector()).getActivity(metadataId,
				Common.PAF_METADATA_FORMAT);
		Activity activity = (new Gson()).fromJson(metaData, Activity.class);
		return Converter.getDestinationBean(activity, Metadata.class,
				Activity.class);
	}

}
