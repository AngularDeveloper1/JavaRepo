package com.pearson.mytest.servlet;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.ConnectException;
import java.net.HttpURLConnection;
import java.net.URL;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;

import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import com.pearson.mytest.framework.CacheWrapper;
import com.pearson.mytest.framework.ConfigurationManager;
import com.pearson.mytest.framework.LogWrapper;
import com.pearson.mytest.framework.exception.AccessDeniedException;
import com.pearson.mytest.framework.exception.BadDataException;
import com.pearson.mytest.framework.exception.ConfigException;
import com.pearson.mytest.framework.exception.InternalException;
import com.pearson.mytest.framework.exception.ServiceUnavailableException;
import com.pearson.mytest.provider.pi.service.AuthenticationProvider;
import com.pearson.mytest.proxy.mytest.repo.LoginRepo;
import com.pearson.mytest.util.Common;

/**
 * Servlet implementation class PI
 */
public class PI extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private static final Logger LOG = LogWrapper.getInstance(PI.class);
	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response){

		int loginCount = 0;
		
		try {
			String token;

			Credential credential = getCredentialFromRequest(request);

			token = (CacheWrapper.getInstance().get(credential.userName));
			if (token == null) {
				token = getPIToken(credential.userName, credential.password);
				CacheWrapper.getInstance().set(credential.userName, token);
			}
			
			AuthenticationProvider pi = new AuthenticationProvider();
			String extUserId = pi.authenticate(token);
			
			loginCount = logLogin(extUserId);
			
			String responseString = "{\"token\": \"" + token + "\", \"loginCount\": \"" + loginCount + "\"}";
			reponseWriter(response, responseString);
		} catch (BadDataException ex) {
			LOG.debug("BadDataException is handled in PI.doPost() method ", ex);
			response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
			reponseWriter(response,ex.getMessage());			
		} catch (InternalException ex) {
			LOG.debug("InternalException is handled in PI.doPost() method ", ex);
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			
		} catch (ServiceUnavailableException ex) {
			LOG.debug(
					"ServiceUnavailableException is handled in PI.doPost() method ",
					ex);
			response.setStatus(HttpServletResponse.SC_BAD_GATEWAY);
			reponseWriter(response,ex.getMessage());
		} catch (AccessDeniedException ex) {
			LOG.debug("Exception is handled in PI.doPost() method ", ex);
			response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			reponseWriter(response,ex.getMessage());
		}
		
	}
	
	private int logLogin(String extUserId) {

		int loginCount = 0;
		LoginRepo loginRepo = new LoginRepo();
		loginCount = loginRepo.logLogin(extUserId);		
		
		return loginCount;
	}
	
	private void reponseWriter(HttpServletResponse response,String message){
		try {
			response.getWriter().write(message);
		} catch (IOException e) {
			throw new InternalException(
					"Error in the method PI.doPost() ", e);
		}
	}

	public class Credential {
		String userName;
		String password;
	}

	private Credential getCredentialFromRequest(HttpServletRequest request){
		BufferedReader br = null;
		try {
			br = new BufferedReader(new InputStreamReader(
					request.getInputStream()));
			String requestBody = (br != null) ? br.readLine() : "";

			if (requestBody == null) {
				throw new BadDataException(Common.USER_REQUEST_BODY);
			}

			Credential credential = (new Gson()).fromJson(requestBody,
					Credential.class);

			if (credential.userName == null || credential.password == null) {
				throw new BadDataException(Common.USER_REQUEST_BODY);
			}

			return credential;
		} catch (JsonSyntaxException | IOException ex) {
			throw new BadDataException(Common.USER_REQUEST_BODY, ex);
		} finally{
			closeStream(br);
		}
	}

	private void closeStream(BufferedReader bufferReader) {
		
			if(bufferReader !=null) {
				try {
					bufferReader.close();
				} catch (IOException e) {
					LOG.error("Error while Closing The Stream");
				}
			}
		
	}

	private String getPIToken(String username, String password){

		try {
			String payload = "{\"userName\":\"%s\",\"password\":\"%s\"}";
			String url = ConfigurationManager.getInstance()
					.getSysToSysPITokenUrl();

			String response = excutePost(url,
					String.format(payload, username, password));

			Gson gson = new Gson();
			PIJson thing = gson.fromJson(response, PIJson.class);

			return thing.data;
		} catch (ConfigException ex) {
			throw new InternalException(
					"Unable to read properties from config", ex);
		}
	}

	public class PIJson {
		String data;
	}

	private String excutePost(String targetURL, String urlParameters){
		URL url;
		HttpURLConnection connection = null;
		try {

			url = new URL(targetURL);

			connection = (HttpURLConnection) url.openConnection();

			connection.setRequestMethod("POST");
			connection.setRequestProperty("Content-Type", "application/json");

			connection.setRequestProperty("Content-Length",
					"" + Integer.toString(urlParameters.getBytes().length));
			connection.setRequestProperty("Content-Language", "en-US");

			connection.setUseCaches(false);
			connection.setDoInput(true);
			connection.setDoOutput(true);

			// Send request
			DataOutputStream wr = new DataOutputStream(
					connection.getOutputStream());
			wr.writeBytes(urlParameters);
			wr.flush();
			wr.close();

			// Get Response
			InputStream is = connection.getInputStream();
			BufferedReader rd = new BufferedReader(new InputStreamReader(is));
			String line;
			StringBuilder response = new StringBuilder();
			while ((line = rd.readLine()) != null) {
				response.append(line);
				response.append('\r');
			}
			rd.close();
			is.close();
			return response.toString();

		} catch (ConnectException e) {

			throw new ServiceUnavailableException(
					"Unable to post to PI server", e);
		} catch (IOException e) {

			throw new AccessDeniedException("Invalid UserName / Password", e);
		} finally {
			if (connection != null) {
				connection.disconnect();
			}
		}
	}
}