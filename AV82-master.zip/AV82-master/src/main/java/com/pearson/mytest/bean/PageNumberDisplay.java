package com.pearson.mytest.bean;


/**
 * The <code>PageNumberDisplay</code> holds the positions to display the PageNumber
 *
 */
public enum PageNumberDisplay {
	
	BOTTOMMIDDLE, 
	BOTTOMRIGHT, 
	TOPRIGHT
}