package com.pearson.mytest.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.pearson.mytest.bean.Metadata;
import com.pearson.mytest.framework.CacheWrapper;
import com.pearson.mytest.proxy.MetadataDelegate;
import com.pearson.mytest.util.CacheKey;
/**
 * This <code>MetadataService</code> is responsible to get the mete data for tests.
 */
public class MetadataService {

	@Autowired
	@Qualifier("metadataRepo")
	private MetadataDelegate metadataRepo;
		
	private static CacheWrapper CACHE;
	/**
	 * This constructor initializes the instance of the cache wrapper object for caching operation.
	 */
	public MetadataService(){
		CACHE = CacheWrapper.getInstance();
	}
	
	/**
	 * Gets the meta data details of the test 
	 * @param testId
	 * @return metadata object 
	 */
	public Metadata getMetadata(String metadataId){
	
		String metadataCacheKey = String.format(CacheKey.METADATA_FORMAT, metadataId);
		Metadata metadata = CACHE.get(metadataCacheKey);
		if (metadata == null) {
			metadata =  metadataRepo.getMetadata(metadataId);
			CACHE.set(metadataCacheKey, metadata);
		}
		return metadata;				
	}
}
