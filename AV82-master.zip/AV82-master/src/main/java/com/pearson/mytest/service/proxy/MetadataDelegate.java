package com.pearson.mytest.proxy;

import com.pearson.mytest.bean.Metadata;
import com.pearson.mytest.framework.exception.InternalException;
import com.pearson.mytest.framework.exception.NotFoundException;

/**
 * This interface defines the contract for accessing test and question metadata
 *
 */
public interface MetadataDelegate {

	/**
	 * Gets the test metadata for both test and question
	 * 
	 * @param metadataId
	 * @return
	 * @throws InternalException
	 * @throws NotFoundException
	 */
	Metadata getMetadata(String metadataId);

}
