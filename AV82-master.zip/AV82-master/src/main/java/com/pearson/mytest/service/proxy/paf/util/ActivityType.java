package com.pearson.mytest.proxy.paf.util;

/**
 * 
 * @author nithinjain
 *
 */
public enum ActivityType {
	/**
	 * Indicates the PAF question
	 */
	item,
	/**
	 * Indicates the PAF activity
	 */
	assignment

}
