/**
 * 
 */
package com.pearson.mytest.dataaccess;

import java.lang.reflect.Field;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.mongodb.morphia.Datastore;
import org.mongodb.morphia.query.Query;
import org.mongodb.morphia.query.ValidationException;

import com.pearson.mytest.bean.BaseEntity;
import com.pearson.mytest.framework.exception.ConfigException;
import com.pearson.mytest.framework.exception.NotFoundException;

/**
 * DataAccessHelper class is the helper class which will provide the facility to
 * do generic operation. T will be expecting Entity Annotated class type.
 * 
 * @author prasadbn
 */
public class DataAccessHelper<T> {

	protected Datastore datastore;
	private Class<T> klazz;

	/**
	 * Constructor which get the access of mongodb by getting Datastore
	 * 
	 * @throws ConfigException
	 * @throws UnknownHostException
	 */
	public DataAccessHelper() {
		datastore = DataAccessor.getDatastore();
	}

	/**
	 * Constructor which get the access of mongodb by getting Datastore.
	 * 
	 * @param clazz
	 *            , Entity annotated class reference
	 * @throws ConfigException
	 * @throws UnknownHostException
	 */
	public DataAccessHelper(Class<T> clazz) {
		this();
		klazz = clazz;
	}

	/**
	 * Saving the entity to the database
	 * 
	 * @param entity
	 *            , Entity annotated class
	 */
	public void save(T entity) {
		datastore.save(entity);
	}

	/**
	 * Saving the entity list to the database
	 * 
	 * @param entityList
	 *            , List of Entity
	 */
	public void save(List<T> entityList) {
		datastore.save(entityList);
	}

	public void delete(List<String> ids) {
		datastore.delete(klazz, ids);
	}

	public void delete(String id) {
		datastore.delete(klazz, id);
	}

	/**
	 * Getting the list of entities
	 * 
	 * @param clazz
	 *            , entity annotated class reference
	 * @return list of given entity values
	 */
	public List<T> getList() {
		return datastore.find(klazz).asList();
	}

	/**
	 * Getting the entity value for the given id
	 * 
	 * @param clazz
	 *            , entity annotated class reference
	 * @param id
	 *            , id of the entity
	 * @return entity value
	 */
	public T getById(String id) {
		return datastore.get(klazz, id);
	}

	/**
	 * Get the list of T (Entity value) for the given property name and property
	 * value
	 * 
	 * @param key
	 *            , property name in string
	 * @param value
	 *            , value of the property
	 * @return List of Entity value
	 */
	public List<T> getByKeyValue(String key, Object value) {
		return datastore.find(klazz).filter(key, value).asList();
	}

	/**
	 * Gets the query reference to build the query
	 * 
	 * @return Query<Entity>
	 */
	public Query<T> getDataQuery() {
		return datastore.find(klazz);
	}

	/**
	 * Get the list of T (Entity value) for the given filter criteria
	 * 
	 * @param criteria
	 *            The filter criteria of a entity
	 * @return List of Entity value
	 */
	public List<T> getByFilter(Map<String, String> criteria) {
		Query<T> q = this.getDataQuery(criteria);
		return q.asList();
	}

	/**
	 * Get the list of T (Entity value) for the given filter criteria
	 * 
	 * @param criteria
	 *            The filter criteria of a entity
	 * @return List of Entity value
	 */
	public List<T> getByFieldHavingAnyOf(String field, List<String> values) {
		Query<T> q = datastore.createQuery(klazz);

		q.field(field.toLowerCase()).in(values);

		return q.asList();
	}

	/**
	 * Gets the query reference to criteria
	 *
	 * @param criteria
	 *            The filter criteria of a entity
	 * @return Query<Entity>
	 */
	private Query<T> getDataQuery(Map<String, String> criteria) {
		Query<T> q = datastore.createQuery(klazz);

		for (Map.Entry<String, String> entry : criteria.entrySet()) {
			q.field(entry.getKey().toLowerCase()).equal(entry.getValue());
		}

		return q;
	}

	/**
	 * Get the basic field value like id, title, i.e, fields mentioned in
	 * BaseEntity bean. This will accept the id of the bean and fieldname which
	 * is needed. Using reflection, field value will be returned.
	 * 
	 * @param id
	 *            , key identifier of bean
	 * @param fieldName
	 *            , field name of bean's key, which field value need to be
	 *            fetch.
	 * @return field value
	 * @throws NotFoundException
	 */
	public String getBaseFieldById(String id, String fieldName) {
		T object;
		Field field;
		String returnValue = "";
		try {
			object = datastore.createQuery(klazz).filter("guid", id)
					.retrievedFields(true, fieldName).get();
			field = BaseEntity.class.getDeclaredField(fieldName);
			field.setAccessible(true);
			returnValue = (String) field.get(object);
		} catch (NoSuchFieldException | SecurityException
				| IllegalArgumentException | IllegalAccessException
				| ValidationException | NullPointerException e) {
			customNotFundException(fieldName, e);
		}
		return returnValue;
	}

	/**
	 * Get the basic field value like id, title, i.e, fields mentioned in
	 * BaseEntity bean. This will accept the map value of search key and search
	 * value, and name of the field which field value needs to be fetch. Using
	 * reflection field value will be returned.
	 * 
	 * @param criteria
	 *            , Map value of fieldname and field value
	 * @param fieldName
	 *            , field name of bean's key, which field value need to be
	 *            fetch.
	 * @return field value of the field with name having input fieldName.
	 * @throws NotFoundException
	 */
	public String getBaseFieldByCriteria(Map<String, String> criteria,
			String fieldName) {
		T object;
		Field field;
		String returnValue = "";
		try {
			object = getDataQuery(criteria).retrievedFields(true, fieldName)
					.get();
			field = BaseEntity.class.getDeclaredField(fieldName);
			field.setAccessible(true);
			returnValue = (String) field.get(object);
		} catch (NoSuchFieldException | SecurityException
				| IllegalArgumentException | IllegalAccessException
				| ValidationException | NullPointerException e) {
			customNotFundException(fieldName, e);
		}
		return returnValue;
	}

	/**
	 * This function has been used to throw the not found exception by logging
	 * custom message
	 * 
	 * @param fieldName
	 * @param e
	 * @throws NotFoundException
	 */
	private void customNotFundException(String fieldName, Exception e) {
		throw new NotFoundException("Field " + fieldName
				+ " is not found in the bean", e);
	}

	@SuppressWarnings("unchecked")
	public List<String> getDistinctValuesByField(String fieldName) {
		List<String> distinctList;
		distinctList = (ArrayList<String>) datastore.getCollection(klazz)
				.distinct(fieldName);
		return distinctList;
	}

	/**
	 * Get the field value which is of type list<string> like questionbindings
	 * of container bean. This will accept the map value of search key and
	 * search value, and name of the field which field value needs to be fetch.
	 * Using reflection field value will be returned.
	 * 
	 * @param criteria
	 *            , Map value of fieldname and field value
	 * @param fieldName
	 *            , field name of bean's key, which field value need to be
	 *            fetch.
	 * @return field value of type List<String> which is of the field with name
	 *         having input fieldName.
	 * @throws NotFoundException
	 */
	@SuppressWarnings("unchecked")
	public List<String> getListFieldByCriteria(Map<String, String> criteria,
			String fieldName) {
		T object;
		Field field;
		List<String> returnValue;
		try {
			object = getDataQuery(criteria).retrievedFields(true, fieldName)
					.get();
			field = klazz.getDeclaredField(fieldName);
			field.setAccessible(true);
			returnValue = (List<String>) field.get(object);
			return returnValue;
		} catch (NoSuchFieldException | SecurityException
				| IllegalArgumentException | IllegalAccessException
				| ValidationException | NullPointerException e) {
			throw new NotFoundException("Field " + fieldName
					+ " is not found in the bean", e);
		}
	}
}
