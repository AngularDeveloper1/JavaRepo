package com.pearson.mytest.bean;

/**
 *  Indicates Download document extensions 
 */
public enum DownloadFormat {
	doc,
	pdf,
	bbpm,
	bbtm,
	qti21;
}
