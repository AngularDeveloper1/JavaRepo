/**
 * 
 */
package com.pearson.mytest.proxy.mytest.repo;

import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.pearson.mytest.bean.Book;
import com.pearson.mytest.dataaccess.BookDataAccessHelper;
import com.pearson.mytest.framework.exception.ConfigException;
import com.pearson.mytest.framework.exception.NotFoundException;
import com.pearson.mytest.proxy.BookDelegate;
import com.pearson.mytest.util.BookHelper;

/**
 * Implementation class which got implemented from interface BookDelegate
 * 
 * @see com.pearson.mytest.proxy.BookDelegate
 *
 */
public class BookRepo implements BookDelegate {

	private BookDataAccessHelper accessor;

	/**
	 * Constructor to access the DataAccessHelper to perform Book operations.
	 * 
	 * @throws ConfigException
	 * @throws UnknownHostException
	 */
	public BookRepo() {
		accessor = new BookDataAccessHelper();
	}
	
	/**
	 * This method will get the books from database.
	 * 
	 * @param  criteria
	 * @return list of books.
	 */
	@Override
	public List<Book> getBooks(Map<String, String> criteria) {

		Map<String, String> filterCriteriaValues = null;
		filterCriteriaValues = this.validateFilterCriteria(criteria);

		List<Book> books = null;
		if (filterCriteriaValues.containsKey("s")) {
			books = accessor.getSearchedBooks(filterCriteriaValues.get("s"));
		} else {
			books = accessor.getByFilter(filterCriteriaValues);
		}

		if (books.isEmpty()) {
			throw new NotFoundException("Books not found");
		}

		return books;
	}
	
	/**
	 * This method will get the book from database based on book id.
	 * 
	 * @param  bookID
	 * 				, represents id of the book.
	 * @return Book object.
	 */
	@Override
	public Book getBookByID(String bookID) {
		Book book = null;
		book = accessor.getById(bookID);

		if (book == null) {
			throw new NotFoundException("Book not found");
		}

		return book;
	}
	
	/**
	 * This method will get the title of the book from database based on book id.
	 * 
	 * @param  bookID
	 * 				, represents id of the book.
	 * @return book title as a string.
	 */
	@Override
	public String getTitle(String bookID) {
		return accessor.getBaseFieldById(bookID, "title");
	}

	/**
	 * This method will get the disciplines from database.
	 * 
	 */
	@Override
	public List<String> getDisciplines() {

		return accessor.getDistinctValuesByField("discipline");
	}
	
	/**
	 * This method will get the books of the disciplines from database.
	 * 
	 * @param  disciplines
	 * 				, represents the list of disciplines.
	 * @return list of books.
	 */
	@Override
	public List<Book> getBooksByDisciplines(List<String> disciplines) {

		List<Book> books = null;
		books = accessor.getByFieldHavingAnyOf("discipline", disciplines);
		return books;
	}

	/**
	 * @see com.pearson.mytest.proxy.BookDelegate#save(Book)
	 */
	@Override
	public void save(Book book) {
		accessor.save(book);

	}

	/**
	 * Check for "s" request param, if system finds the value for "s" then
	 * system will do search with "or" operation on (id,title,authors, isbn,
	 * publisher,discipline) Hence system will ignore other request param values
	 * if user has provided
	 * @param filterCriteria
	 * @return
	 */
	private Map<String, String> validateFilterCriteria(
			Map<String, String> filterCriteria) {
		Map<String, String> filterCriteriaValues = new HashMap<String, String>();

		if (filterCriteria.containsKey("s")
				&& (filterCriteria.get("s") != null)) {
			filterCriteriaValues.put("s", filterCriteria.get("s"));
		} else {
			for (Map.Entry<String, String> entry : filterCriteria.entrySet()) {
				if (BookHelper.getFilterCriteriaMap().containsKey(
						entry.getKey())) {

					filterCriteriaValues.put(BookHelper.getFilterCriteriaMap()
							.get(entry.getKey()), entry.getValue());
				}

			}
		}

		return filterCriteriaValues;

	}

}
