package com.pearson.mytest.proxy.paf.repo;

import com.google.common.base.Strings;
import com.google.gson.Gson;
import com.pearson.mytest.bean.Test;
import com.pearson.mytest.framework.exception.InternalException;
import com.pearson.mytest.framework.exception.NotFoundException;
import com.pearson.mytest.proxy.TestDelegate;
import com.pearson.mytest.proxy.paf.bean.Assignment;
import com.pearson.mytest.proxy.paf.util.ActivityUtil;
import com.pearson.mytest.proxy.paf.util.Connector;
import com.pearson.mytest.util.Common;

/**
 * This <code>TestRepo</code> is responsible to access and mutate the tests from PAF repository
 *
 */
public class TestRepo implements TestDelegate {

	private static final String TEST_NOT_FOUND = "Test not found";
	private static final String TEST_ID_NULL = "Test id is set to null";

	/**
	 * This method will get the test based on test id from PAF
	 * 
	 * @param testId
	 * 				, test id number which needs to get the test.
	 * @return test
	 */
	@Override
	public Test getTestByID(String testId) {
		if (Strings.isNullOrEmpty(testId)) {
			throw new InternalException(TEST_ID_NULL);
		}
		Assignment assignment;
		Test paperTest;
		Connector pafConnect = new Connector();
		Gson gson = new Gson();
		String activity = pafConnect.getActivity(testId,
				Common.PAF_ASSIGNMENT_FORMAT);

		if (activity != null && !activity.isEmpty()) {
			assignment = gson.fromJson(activity, Assignment.class);
		} else {
			throw new NotFoundException(TEST_NOT_FOUND);
		}

		// Check assignment object for null
		if (assignment == null) {
			throw new NotFoundException(TEST_NOT_FOUND);
		}

		paperTest = ActivityUtil.getMyTest(assignment);
		paperTest.setGuid(testId);
		return paperTest;
	}

}
