package com.pearson.mytest.provider.pi.service;

public class UserProfile {
	public Data data;
}
