package com.pearson.mytest.bean;

public class Question {
	
	private QuestionMetadata metadata;
	private String xml;
	
	public QuestionMetadata getMetadata() {
		return metadata;
	}
	public void setMetadata(QuestionMetadata metadata) {
		this.metadata = metadata;
	}
	public String getXml() {
		return xml;
	}
	public void setXml(String xml) {
		this.xml = xml;
	}
	
	
	
	
}
