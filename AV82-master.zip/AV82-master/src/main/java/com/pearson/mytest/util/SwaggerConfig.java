package com.pearson.mytest.util;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.mangofactory.swagger.configuration.SpringSwaggerConfig;
import com.mangofactory.swagger.paths.SwaggerPathProvider;
import com.mangofactory.swagger.plugin.SwaggerSpringMvcPlugin;
import com.wordnik.swagger.model.ApiInfo;

/**
 * This <code>SwaggerConfig</code> is utility for swagger configuration
 * 
 */
@Configuration
@ComponentScan(basePackages={"com.mangofactory.swagger"})
public class SwaggerConfig {

    public static final String SWAGGER_GROUP = "testBuilder";

    @Value("${documentation.services.basePath}")
    private String docsLocation;
    @Value("${documentation.services.info.title}")
    private String title;
    @Value("${documentation.services.info.description}")
    private String description;
    @Value("${documentation.services.info.termsOfServiceUrl}")
    private String termsOfServiceUrl;
    @Value("${documentation.services.info.contact}")
    private String contact;
    @Value("${documentation.services.info.license}")
    private String license;
    @Value("${documentation.services.info.licenseUrl}")
    private String licenseUrl;


    @Autowired
    private SpringSwaggerConfig springSwaggerConfig;
    
    @Bean
    public SwaggerSpringMvcPlugin configureSwagger(){
    	SwaggerSpringMvcPlugin swaggerSpringMvcPlugin = new SwaggerSpringMvcPlugin(this.springSwaggerConfig);
    	swaggerSpringMvcPlugin.apiInfo(apiInfo());
    	swaggerSpringMvcPlugin.apiVersion("1.1");
    	swaggerSpringMvcPlugin.swaggerGroup(SWAGGER_GROUP);
    	swaggerSpringMvcPlugin.pathProvider(new SwaggerPathProvider() {
			
			@Override
			protected String getDocumentationPath() {
				return "/";
			}
			
			@Override
			protected String applicationPath() {
				return docsLocation;
			}
		});
		return swaggerSpringMvcPlugin;
    }
    
    /**
     * API Info as it appears on the swagger-ui page
     */
    private ApiInfo apiInfo() {       
        return new ApiInfo(
        		title,
        		description,
        		termsOfServiceUrl,
        		contact,
        		license,
        		licenseUrl
        );
    }
}


