package com.pearson.mytest.proxy.mytest.repo;

class QueryFields {
	
	public static final String GUID = "guid";
	public static final String USERID ="userId";
	public static final String PARENTID ="parentId";
	public static final String TITLE = "title";
	public static final String SEQUENCE = "sequence";
    public static final String YOUR_QUESTIONS = "Your Questions";
	public static final String BOOKID ="bookid";
}