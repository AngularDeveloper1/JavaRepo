/**
 * 
 */
package com.pearson.mytest.proxy.paf.repo;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.google.common.base.Strings;
import com.google.gson.Gson;
import com.pearson.mytest.bean.Metadata;
import com.pearson.mytest.bean.QuestionMetadata;
import com.pearson.mytest.bean.QuestionEnvelop;
import com.pearson.mytest.framework.ConfigurationManager;
import com.pearson.mytest.framework.exception.InternalException;
import com.pearson.mytest.framework.exception.NotFoundException;
import com.pearson.mytest.proxy.BookDelegate;
import com.pearson.mytest.proxy.QuestionDelegate;
import com.pearson.mytest.proxy.paf.bean.Activity;
import com.pearson.mytest.proxy.paf.util.ActivityType;
import com.pearson.mytest.proxy.paf.util.Connector;
import com.pearson.mytest.proxy.paf.util.Converter;
import com.pearson.mytest.util.Common;

/**
 * This <code>QuestionRepo</code> is responsible to access and mutate the questions from PAF
 * repository
 *
 */
public class QuestionRepo implements QuestionDelegate {

	private static final String QUESTIONS_NOT_FOUND = "Questions not found";
	private static final String QUESTION_ID_NULL = "Question id is set to null";
	private static final String PAF_FORMAT = "application/vnd.pearson.paf.v1.envelope+json;body=\"application/vnd.pearson.qti.v2p1.asi+xml\"";
	private static final String PREV_DATE = "prevdate";
	private static final String RECORD_SIZE = "rsize";
	private static final String PREV_DATE_IN = "in";

	/**
	 * @see com.pearson.mytest.controller#bookDelegate
	 */
	@Autowired
	@Qualifier("books")
	private BookDelegate bookRepo;

	/**
	 * This method will get all questions of quiz types passed for a given
	 * course.
	 * 
	 * @param bookID
	 * @return list of question meta data
	 */
	@Override
	public List<QuestionMetadata> getQuestions(String bookID) {
		String batchSize = ConfigurationManager.getInstance()
				.getPAFActivitiesRecordSize();
		List<Activity> bookQuestions = new ArrayList<Activity>();
		Date startDate = new Date(0);
		SimpleDateFormat ft = new SimpleDateFormat(
				"yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
		String startDateString = ft.format(startDate);
		String bookTitle = bookRepo.getTitle(bookID);
		fillBookQuestions(bookQuestions, bookTitle, startDateString,
				Integer.valueOf(batchSize));
		if (bookQuestions.isEmpty()) {
			throw new NotFoundException(QUESTIONS_NOT_FOUND);
		}
		return Converter.getDestinationBeanList(bookQuestions,
				QuestionMetadata.class, Activity.class);
	}

	/**
	 * 
	 * @param bookQuestions
	 * @param bookID
	 * @param date
	 */
	private void fillBookQuestions(List<Activity> bookQuestions,
			String bookTitle, String date, int batchSize) {
		List<com.pearson.mytest.proxy.paf.bean.Activity> pafQuestions;
		Connector pafConnect = new Connector();
		Map<String, String> filterCriteriaValues = new HashMap<String, String>();
		filterCriteriaValues.put(PREV_DATE, date);
		filterCriteriaValues.put(RECORD_SIZE, String.valueOf(batchSize));
		filterCriteriaValues.put(PREV_DATE_IN, "1");
		filterCriteriaValues.put(Common.ACTIVITY_TYPE,
				ActivityType.item.toString());
		pafQuestions = pafConnect
				.getActivities(bookTitle, filterCriteriaValues);

		bookQuestions.addAll(pafQuestions);
		if (pafQuestions.size() == batchSize) {
			String modifiedDate = pafQuestions.get(pafQuestions.size() - 1)
					.getModified();
			this.fillBookQuestions(bookQuestions, bookTitle, modifiedDate,
					batchSize);
		}
	}

	/**
	 * This method will get the question XML based on question id
	 * 
	 * @param questionId
	 * @return question xml
	 */
	@Override
	public String getQuestionXmlById(String questionId) {
		if (Strings.isNullOrEmpty(questionId)) {
			throw new InternalException(QUESTION_ID_NULL);
		}
		Connector pafConnect = new Connector();
		return pafConnect.getActivity(questionId, Common.PAF_QUESTION_FORMAT);

	}

	/**
	 * This method will save the questions to PAF based on bookTitle and chapterTitle
	 * 
	 * @param question
	 *               , question envelop which needs to get question mete data.
	 * @param bookTitle
	 * @param chapterTitle 
	 * @return response message as string
	 */
	@Override
	public String saveQuestion(QuestionEnvelop question, String bookTitle,
			String chapterTitle) {

		com.pearson.mytest.proxy.paf.bean.QuestionEnvelop pafQuestion = Converter
				.getDestinationBean(
						question,
						com.pearson.mytest.proxy.paf.bean.QuestionEnvelop.class,
						QuestionEnvelop.class);

		Activity metadata = Converter.getDestinationBean(
				question.getmetadata(), Activity.class, Metadata.class);

		pafQuestion.setMetadata(metadata);

		pafQuestion.getMetadata().setBookTitle(bookTitle);
		pafQuestion.getMetadata().setChapterTitle(chapterTitle);

		Connector pafConnect = new Connector();
		String format = PAF_FORMAT;
		Gson gson = new Gson();
		String payload = gson.toJson(pafQuestion);

		return pafConnect.saveActivity(payload, format);
	}

}
