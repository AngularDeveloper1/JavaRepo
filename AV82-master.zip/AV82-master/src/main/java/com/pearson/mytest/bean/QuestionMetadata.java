package com.pearson.mytest.bean;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.pearson.mytest.framework.ConfigurationManager;
import com.pearson.mytest.framework.exception.ConfigException;
import com.pearson.mytest.framework.exception.InternalException;
import com.pearson.mytest.util.Common;
/**
 *  This <code>QuestionMetadata</code> is responsible to hold the meta data of the questions 
 *
 */
public class QuestionMetadata extends Metadata implements Serializable {

	/**
	 * Indicate the version id of serialization
	 */
	private static final long serialVersionUID = 1L;

	@JsonProperty("@id")
	public String getId() {
		try {
			return String.format(Common.QUESTION_END_POINT_FORMAT,
					ConfigurationManager.getInstance().getMyTestBaseUrl(),
					this.getGuid());
		} catch (ConfigException e) {
			throw new InternalException(
					"Not able to read configuration - Question.getId", e);
		}
	}
}
