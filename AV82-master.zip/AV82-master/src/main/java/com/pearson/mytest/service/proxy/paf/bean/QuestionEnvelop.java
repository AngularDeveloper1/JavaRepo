package com.pearson.mytest.proxy.paf.bean;

import com.googlecode.jmapper.annotations.JMap;

/**
 * This <code>QuestionEnvelop</code> is entity of PAF to represents the question body.
 */
public class QuestionEnvelop extends BaseEnvelop {

	/**
	 * Indicates the question body
	 */
	@JMap
	private String body;

	/** Get {@see #body}. @return {@link #body}. */
	public String getBody() {
		return body;
	}

	/** Set {@see #body}. @param {@link #body}. */
	public void setBody(String body) {
		this.body = body;
	}

}
