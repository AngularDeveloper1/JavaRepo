package com.pearson.mytest.download;

import java.io.OutputStream;

import com.pearson.mytest.bean.DownloadInfo;
import com.pearson.mytest.bean.DownloadOutput;


/**
 * Presenting the assessment/assignment in various form
 *
 */
public interface TestDownload {
	DownloadOutput download(OutputStream stream, DownloadInfo downloadInfo);
	String extension();
}
