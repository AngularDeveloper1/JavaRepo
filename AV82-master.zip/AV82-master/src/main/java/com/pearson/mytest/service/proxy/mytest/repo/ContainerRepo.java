/**
 * 
 */
package com.pearson.mytest.proxy.mytest.repo;

import java.net.UnknownHostException;
import java.util.List;

import org.mongodb.morphia.query.Query;

import com.google.common.collect.ImmutableMap;
import com.pearson.mytest.bean.Container;
import com.pearson.mytest.dataaccess.DataAccessHelper;
import com.pearson.mytest.framework.exception.ConfigException;
import com.pearson.mytest.framework.exception.NotFoundException;
import com.pearson.mytest.proxy.ContainerDelegate;

/**
 * Implementation class which got implemented from ContainerDelegate.
 * 
 * @see com.pearson.mytest.proxy.ContainerDelegate
 *
 */
public class ContainerRepo implements ContainerDelegate {

	private DataAccessHelper<Container> accessor;	
	
	/**
	 * Constructor to access DataAccessHelper to perform Container operation.
	 * 
	 * @throws ConfigException 
	 * @throws UnknownHostException 
	 */
	public ContainerRepo(){
		accessor = new DataAccessHelper<Container>(Container.class);		
	}

	/**
	 * Get the list of Containers for the given bookid
	 * 
	 * @throws NotFoundException
	 * @throws BaseException
	 */
	@Override
	public List<Container> getRootLevelContainersByBookId(String bookID){
		List<Container> containers = null;

		Query<Container> query = accessor.getDataQuery();
		containers = query.filter(QueryFields.BOOKID, bookID)
				.filter(QueryFields.PARENTID, "")
				.order("sequence").asList();
		
		return containers;
	}	

	/**
	 * Get the Container for the given bookid and containerid
	 * 
	 * @throws NotFoundException
	 */
	@Override
	public Container getContainerById(String containerId){
		
		Container container = null;
		Query<Container> query = accessor.getDataQuery();
		container = query.filter(QueryFields.GUID, containerId).get();
		
		return container;
	}
	
	/**
	 *  This method will get the container by container id
	 * @param Container id
	 * @return Container
	 */
	@Override
	public Container getContainerByContainerId(String containerid){
		
		Container container = null;
		Query<Container> query = accessor.getDataQuery();
		container = query.filter(QueryFields.GUID, containerid).get();
		
		return container;
	}
	
	/**
	 * This method will fetch the containers for which the sent questions is binded
	 * @param list of questionid's
	 * @return list of Container
	 */
	@Override
	public List<Container> getContainerByQuestionids(String bookID, List<String> questionids){
		List<Container> containers = null;
		Query<Container> query = accessor.getDataQuery();
		containers = query.filter(QueryFields.BOOKID, bookID).filter("questionBindings in", questionids).asList();
		
		return containers;
	}

	/**
	 * Get the Container children for the given book id and container id
	 * 
	 * @throws NotFoundException
	 */
	@Override
	public List<Container> getContainerChildrenById(String containerId) {
		
		List<Container> containers = null;
		Query<Container> query = accessor.getDataQuery();
		containers = query.filter(QueryFields.PARENTID, containerId)
				.order(QueryFields.SEQUENCE).asList();
		
		return containers;
	}
	
	/**
	 * This method gets all the containers up to nth level for a given book
	 * @param bookID
	 * @return list of Container
	 */
	@Override
	public List<Container> getContainersFlatViewByBookId(String bookID) {
		
		List<Container> containers = null;
		Query<Container> query = accessor.getDataQuery();
		containers = query.filter(QueryFields.BOOKID, bookID)
				.order(QueryFields.SEQUENCE).asList();

		return containers;
	}	
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.pearson.mytest.proxy.ContainerDelegate#getTitle(String,String)
	 */
	@Override
	public String getTitle(String bookID, String containerID) {
		return accessor.getBaseFieldByCriteria(
				ImmutableMap.of(QueryFields.BOOKID, bookID, QueryFields.GUID, containerID), QueryFields.TITLE);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.pearson.mytest.proxy.ContainerDelegate#getQuestionBindings(String,String)
	 */
	@Override
	public List<String> getQuestionBindings(String bookID, String containerID){
		return accessor.getListFieldByCriteria(
				ImmutableMap.of(QueryFields.BOOKID, bookID, QueryFields.GUID, containerID), "questionBindings");
	}

	/**
	 * @see com.pearson.mytest.proxy.ContainerDelegate#save(List<Container>)
	 */
	@Override
	public  void save(List<Container> containers) {
		  accessor.save(containers);
	}

}
