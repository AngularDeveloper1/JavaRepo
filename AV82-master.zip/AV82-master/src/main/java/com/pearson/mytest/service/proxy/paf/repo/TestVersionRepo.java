package com.pearson.mytest.proxy.paf.repo;

import com.google.common.base.Strings;
import com.pearson.mytest.bean.*;
import com.pearson.mytest.framework.exception.*;
import com.pearson.mytest.proxy.TestVersionDelegate;
import com.pearson.mytest.proxy.paf.util.*;
import com.pearson.mytest.util.Common;
/**
 * This <code>TestVersionRepo</code> is responsible to access and mutate the test versions from PAF repository
 *
 */
public class TestVersionRepo implements TestVersionDelegate {
	private static final String TEST_ID_NULL = "Test id is set to null";

	/*
	 * @see
	 * com.pearson.mytest.proxy.TestVersionDelegate#createVersionTest(com.pearson
	 * .mytest.bean .TestEnvelop, com.pearson.mytest.bean.UserFolder)
	 */
	@Override
	public TestResult createVersionTest(TestEnvelop test, String testId) {
		String result = null;
		String payload = ActivityUtil.getTestPayload(test);

		try {

			result = (new Connector()).createVersionActivity(payload,
					Common.PAF_ACTIVITY_CREATION_CONTENT_TYPE, testId);

		} catch (NotFoundException e) {
			throw new BadDataException(e.getMessage(), e);
		}

		return ActivityUtil.getTestResultBean(result);
	}

	/**
	 * This method gets the versions of the given test.
	 * 
	 * @param testID
	 * @return list of URLs to get test details
	 */
	@Override
	public String getTestVersions(String testID) {
		if (Strings.isNullOrEmpty(testID)) {
			throw new InternalException(TEST_ID_NULL);
		}
		String activities = (new Connector()).getTestVersions(testID);

		if (activities.isEmpty()) {
			throw new NotFoundException("No versions for this test");
		}

		return activities;
	}

}
