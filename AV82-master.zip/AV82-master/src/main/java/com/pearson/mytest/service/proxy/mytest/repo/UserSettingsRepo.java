package com.pearson.mytest.proxy.mytest.repo;

import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.pearson.mytest.bean.PrintSettings;
import com.pearson.mytest.bean.UserSettings;

import com.pearson.mytest.dataaccess.DataAccessHelper;
import com.pearson.mytest.framework.CacheWrapper;
import com.pearson.mytest.framework.exception.BadDataException;
import com.pearson.mytest.framework.exception.ConfigException;
import com.pearson.mytest.framework.exception.NotFoundException;
import com.pearson.mytest.framework.exception.ServiceUnavailableException;
import com.pearson.mytest.proxy.BookDelegate;
import com.pearson.mytest.proxy.UserSettingsDelegate;
import com.pearson.mytest.util.UserHelper;

/**
 * Implementation class which got implemented from interface UserPrefDelegate
 * 
 * @see com.pearson.mytest.proxy.UserSettingsDelegate
 *
 */
public class UserSettingsRepo implements UserSettingsDelegate {

	@Autowired
	@Qualifier("books")
	private BookDelegate bookDelegate;

	private DataAccessHelper<UserSettings> accessor;

	private static CacheWrapper CACHE;
	/**
	 * Constructor to instantiate the DataAccessHelper with BookPref bean.
	 * @throws ConfigException 
	 * @throws UnknownHostException 
	 * @throws ServiceUnavailableException 
	 */
	public UserSettingsRepo() {
		accessor = new DataAccessHelper<UserSettings>(UserSettings.class);
		CACHE = CacheWrapper.getInstance();
	}

	@Override
	public UserSettings getUserSettings(String userid){

		UserSettings userSettings = null;

		userSettings = CACHE.get(userid);
		if (userSettings == null) {
			userSettings = accessor.getById(userid);
			if (userSettings == null) {

				//user logging in for the first time and hence create the user with default settings
				userSettings = UserHelper.getDefaultSettings(userid);				
				accessor.save(userSettings);
			}
			CACHE.set(userid, userSettings);
		}

		return userSettings;
	}	

	@Override
	public void saveUserSettings(UserSettings userSettings){	

		accessor.save(userSettings);

		CACHE.set(userSettings.getUserid(), userSettings);
	}

	@Override
	public List<String> getUserDisciplines(String userid) {	

		return getUserSettings(userid).getDisciplines(); 	
	}

	@Override
	public void saveUserDisciplines(String userid, List<String> disciplines){

		UserSettings userSettings = getUserSettings(userid);				
		userSettings.setDisciplines(disciplines);

		saveUserSettings(userSettings);	
	}

	@Override
	public List<String> getUserBooks(String userid){

		UserSettings userSettings = getUserSettings(userid);
		return userSettings.getBooks();		
	}

	private void validateBookIds(List<String> books){
		List<String> invalidBooks = new ArrayList<String>();
		for (String bookid : books) {
			try {
				bookDelegate.getBookByID(bookid);	
			} catch(NotFoundException ex) { // NOSONAR
				invalidBooks.add(bookid);
			}			
		}
		if (!invalidBooks.isEmpty()) {
			throw new BadDataException("Invalid book ids: " + invalidBooks.toString());
		}
	}

	@Override
	public void saveUserBooks(String userid, List<String> books) {

		validateBookIds(books);

		UserSettings userSettings = getUserSettings(userid);				
		userSettings.setBooks(books);

		saveUserSettings(userSettings);		
	}

	@Override
	public List<String> getQuestionMetadata(String userid){
		
		UserSettings userSettings = getUserSettings(userid);
		return userSettings.getQuestionMetadata(); 		
		
	}

	@Override
	public void saveQuestionMetadata(String userid,	List<String> questionMetadata){

		UserSettings userSettings = getUserSettings(userid);				
		userSettings.setQuestionMetadata(questionMetadata);

		saveUserSettings(userSettings);			
	}

	@Override
	public PrintSettings getPrintSettings(String userid){
		
		UserSettings userSettings = getUserSettings(userid);
		return userSettings.getPrintSettings();			
		
	}

	@Override
	public void savePrintSettings(String userid, PrintSettings printSettings){

		printSettings.validate();

		if (!printSettings.isMultipleVersions()) {
			printSettings.setNumberOfVersions(1);
			printSettings.setScrambleOrder("Scramble question order");
		}

		UserSettings userSettings = getUserSettings(userid);				
		userSettings.setPrintSettings(printSettings);

		saveUserSettings(userSettings);		
	}

}
