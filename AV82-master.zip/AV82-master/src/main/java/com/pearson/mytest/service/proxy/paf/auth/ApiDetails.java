package com.pearson.mytest.proxy.paf.auth;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.http.entity.ContentType;
import org.springframework.web.bind.annotation.RequestMethod;

import com.pearson.mytest.framework.ConfigurationManager;
import com.pearson.mytest.framework.exception.ConfigException;
import com.pearson.mytest.framework.exception.InternalException;
import com.pearson.mytest.util.HttpResponse;
import com.pearson.mytest.util.HttpUtility;

/**
 * This class represents PAF API details entity
 * 
 * @author nithinjain
 */
public class ApiDetails {

	/**
	 * Holds the http methods (GET,POST,PUT AND DELETE)
	 */
	private RequestMethod method;

	/**
	 * Holds the PAF APIs end point url
	 */
	private String url;

	private String serviceEndPoint;

	/**
	 * Holds the PAF API search parameters
	 */
	private Map<String, String> params;

	/**
	 * @param method
	 *            the http method
	 * @param serviceEndPoint
	 *            the restful service end point
	 */
	public ApiDetails(RequestMethod method, String serviceEndPoint) {
		super();
		this.method = method;
		this.serviceEndPoint = serviceEndPoint;
	}

	/**
	 * @param method
	 *            the http method
	 * @param serviceEndPoint
	 *            the restful service end point
	 * @param params
	 *            the query string parameters for service end point
	 */
	public ApiDetails(RequestMethod method, String serviceEndPoint,
			Map<String, String> params) {
		this(method, serviceEndPoint);

		this.params = params;
	}

	/**
	 * Returns the http method of the api
	 * 
	 * @return the method of the api
	 */
	/**
	 * @return
	 */
	public String getMethod() {
		return method.toString();
	}

	/**
	 * Sets the http method of the api
	 * 
	 * @param method
	 *            the http method to set
	 */
	public void setMethod(RequestMethod method) {
		this.method = method;
	}

	/**
	 * Returns the paf restful end point url of the api
	 * 
	 * @return the url of the api
	 * @throws InternalException
	 */
	public String getUrl(){
		try {
			this.url = ConfigurationManager.getInstance().getPAFBaseUrl()
					+ this.serviceEndPoint;
		} catch (ConfigException e) {
			throw new InternalException("Exception thrown from ApiDetails.getUrl method", e);
		}
		return this.url;
	}

	/**
	 * Sets the restful service end point of the api
	 * 
	 * @param serviceEndPoint
	 *            the restful service end point to set
	 */
	public void setServiceEndPoint(String serviceEndPoint) {
		this.serviceEndPoint = serviceEndPoint;
	}

	/**
	 * Returns the search parameters of the api
	 * 
	 * @return the params of the api
	 */
	public Map<String, String> getParams() {
		return params;
	}

	/**
	 * @param key
	 *            The http header key
	 * @param value
	 *            The http header value
	 * @return The current object, to add param in chain format
	 */
	public ApiDetails addParam(String key, String value) {
		// This method is called first time, system will create the object of
		// HashMap
		if (this.params == null){
			this.params = new HashMap<String, String>();
		}
		
		this.params.put(key, value);
		return this;
	}

	/**
	 * @param headers
	 *            The http header information
	 * @param contentType
	 *            The content type of request
	 * @return The HttpResponse object
	 * @throws InternalException
	 */
	public HttpResponse makeGet(Map<String, String> headers,
			ContentType contentType){
		try {
			HttpUtility util = new HttpUtility();

			return util.makeGet(this.getUrl(), headers, contentType,
					this.getParams());
		} catch (IOException e) {
			throw new InternalException(
					"Exception thrown from ApiDetails.makeGet method", e);
		}
	}
	
	/**
	 * Posting the data 
	 * @param headers, contains the OAuth token
	 * @param contentType, format of the content
	 * @param payload, content
	 * @return http response which contains response message
	 * @throws InternalException
	 */
	public HttpResponse makePost(Map<String, String> headers,
			ContentType contentType, String payload){
		HttpUtility util = new HttpUtility();
		return util.makePost(this.getUrl(), headers, contentType, this.getParams(), payload);
	}
	
	/**
	 * Updating the data 
	 * @param headers, contains the OAuth token
	 * @param contentType, format of the content
	 * @param payload, content
	 * @return http response which contains response message
	 * @throws InternalException
	 */
	public HttpResponse makePut(Map<String, String> headers,
			ContentType contentType, String payload){
		try {
			HttpUtility util = new HttpUtility();

			return util.makePut(this.getUrl(), headers, contentType, this.getParams(), payload);
		} catch (IOException e) {
			throw new InternalException(
					"Exception thrown from ApiDetails.makePost method", e);
		}
	}
	
	public HttpResponse makeDelete(Map<String, String> headers,
			ContentType contentType){
		try {
			HttpUtility util = new HttpUtility();

			return util.makeDelete(this.getUrl(), headers, contentType, this.getParams());
		} catch (IOException e) {
			throw new InternalException(
					"Exception thrown from ApiDetails.makePost method", e);
		}
	}

}
