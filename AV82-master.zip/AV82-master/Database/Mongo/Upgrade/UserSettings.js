test = db.getSiblingDB('evalu8_dev')
test.UserSettings.find().forEach(function(doc){
	test.UserSettings.update(
		{"_id": doc._id},
		{"$set": {"printSettings.includeWorkSpace":false}}
	)
})