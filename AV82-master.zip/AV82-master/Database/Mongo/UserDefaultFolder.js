/**
 * This file contains the default user folder master data
 */
evalu8DB = db.getSiblingDB('evalu8_dev')

evalu8DB.UserDefaultFolder.drop()

evalu8DB.createCollection("UserDefaultFolder")

evalu8DB.UserDefaultFolder.insert([
  {
    "_id": "DefaultNode1",
    "title": "Courses",
    "sequence": 1.00
  }
])

evalu8DB.UserDefaultFolder.insert([
  {
    "_id": "DefaultNode2",
    "title": "Imported Content",
    "sequence": 2.00
  }
])

evalu8DB.UserDefaultFolder.insert([
  {
    "_id": "DefaultNode3",
    "title": "Archive",
    "sequence": 3.00
  }
])


